package dev.latvian.mods.projectex.util;

import dev.latvian.mods.projectex.net.ColoredLightningPacket;
import dev.latvian.mods.projectex.net.ProjectEXNet;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

// Shared zap spawner: spawns a vanilla LightningBolt at the player's crosshair, broadcasts a
// color tag to nearby clients, and triggers a tier-sized explosion at the strike point.
public final class LightningZap {
	private LightningZap() {}

	public static void zap(ServerPlayer player, int argb, float explosionRadius) {
		HitResult hr = player.pick(120.0, 1.0F, false);
		if (hr.getType() != HitResult.Type.BLOCK || !(hr instanceof BlockHitResult bhr)) return;
		Level level = player.level();
		Vec3 hitPos = Vec3.atCenterOf(bhr.getBlockPos());
		LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
		if (bolt == null) return;
		bolt.moveTo(hitPos);
		bolt.setCause(player);
		level.addFreshEntity(bolt);

		// Sync color to clients within 256 blocks so the renderer mixin can tint the bolt.
		ColoredLightningPacket pkt = new ColoredLightningPacket(bolt.getUUID(), argb);
		ProjectEXNet.CHANNEL.send(
				PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(
						hitPos.x, hitPos.y, hitPos.z, 256.0, level.dimension())),
				pkt
		);

		// Mini explosion at the strike point — fires regardless of PE's offensiveAbilities config.
		if (explosionRadius > 0.0F) {
			level.explode(player, hitPos.x, hitPos.y, hitPos.z, explosionRadius, Level.ExplosionInteraction.BLOCK);
		}
	}
}
