package dev.latvian.mods.projectex.mixin;

import moze_intel.projecte.gameObjs.items.armor.GemChest;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.Constant;

@Mixin(GemChest.class)
public class GemChestExplosionMixin {
	@ModifyConstant(method = "doExplode", constant = @Constant(floatValue = 9.0F), remap = false)
	private float projectex$tntSize(float original) {
		return 4.0F;
	}
}
