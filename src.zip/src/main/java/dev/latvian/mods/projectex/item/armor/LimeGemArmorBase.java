package dev.latvian.mods.projectex.item.armor;

import moze_intel.projecte.gameObjs.items.armor.PEArmor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.crafting.Ingredient;
import org.jetbrains.annotations.NotNull;

public abstract class LimeGemArmorBase extends PEArmor {
	public LimeGemArmorBase(ArmorItem.Type type, Item.Properties props) { super(LimeGemArmorMaterial.INSTANCE, type, props); }
	@Override public float getFullSetBaseReduction() { return 1.0F; }
	@Override
	public float getMaxDamageAbsorb(ArmorItem.Type type, DamageSource source) {
		if (source.is(DamageTypeTags.IS_FIRE)) return 3100.0F;
		if (type == ArmorItem.Type.BOOTS && source.is(DamageTypeTags.IS_FALL)) return 60.0F / getPieceEffectiveness(type);
		if (type == ArmorItem.Type.HELMET && source.is(DamageTypeTags.DAMAGES_HELMET)) return 60.0F / getPieceEffectiveness(type);
		if (source.is(DamageTypeTags.BYPASSES_ARMOR)) return 0.0F;
		if (type == ArmorItem.Type.HELMET || type == ArmorItem.Type.BOOTS) return 1550.0F;
		return 2100.0F;
	}
	public static boolean hasAnyPiece(Player player) {
		return player.getInventory().armor.stream().anyMatch(i -> !i.isEmpty() && i.getItem() instanceof LimeGemArmorBase);
	}
	private static class LimeGemArmorMaterial implements ArmorMaterial {
		private static final LimeGemArmorMaterial INSTANCE = new LimeGemArmorMaterial();
		private static final String NAME = new ResourceLocation("projectex", "lime_gem_armor").toString();
		public int getDurabilityForType(@NotNull ArmorItem.Type type) { return 0; }
		public int getDefenseForType(@NotNull ArmorItem.Type type) { return switch (type) { case BOOTS, HELMET -> 3; case LEGGINGS -> 6; case CHESTPLATE -> 8; }; }
		public int getEnchantmentValue() { return 0; }
		@NotNull public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_NETHERITE; }
		@NotNull public Ingredient getRepairIngredient() { return Ingredient.EMPTY; }
		@NotNull public String getName() { return NAME; }
		public float getToughness() { return 11.0F; }
		public float getKnockbackResistance() { return 0.80F; }
	}
}
