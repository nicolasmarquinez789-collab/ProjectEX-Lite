package dev.latvian.mods.projectex.item;

import dev.latvian.mods.projectex.Matter;
import dev.latvian.mods.projectex.ProjectEX;
import dev.latvian.mods.projectex.Star;
import dev.latvian.mods.projectex.block.ProjectEXBlocks;
import dev.latvian.mods.projectex.item.armor.PinkArmor;
import dev.latvian.mods.projectex.item.weapon.PinkAxe;
import dev.latvian.mods.projectex.item.weapon.PinkHammer;
import dev.latvian.mods.projectex.item.weapon.PinkHoe;
import dev.latvian.mods.projectex.item.weapon.PinkKatar;
import dev.latvian.mods.projectex.item.weapon.PinkMorningStar;
import dev.latvian.mods.projectex.item.weapon.PinkPickaxe;
import dev.latvian.mods.projectex.item.weapon.PinkShears;
import dev.latvian.mods.projectex.item.weapon.PinkShovel;
import dev.latvian.mods.projectex.item.weapon.PinkSword;
import dev.latvian.mods.projectex.item.weapon.PurpleAxe;
import dev.latvian.mods.projectex.item.weapon.PurpleHammer;
import dev.latvian.mods.projectex.item.weapon.PurpleHoe;
import dev.latvian.mods.projectex.item.weapon.PurpleKatar;
import dev.latvian.mods.projectex.item.weapon.PurpleMorningStar;
import dev.latvian.mods.projectex.item.weapon.PurplePickaxe;
import dev.latvian.mods.projectex.item.weapon.PurpleShears;
import dev.latvian.mods.projectex.item.weapon.PurpleShovel;
import dev.latvian.mods.projectex.item.weapon.PurpleSword;
import dev.latvian.mods.projectex.item.weapon.BlueAxe;
import dev.latvian.mods.projectex.item.weapon.BlueHammer;
import dev.latvian.mods.projectex.item.weapon.BlueHoe;
import dev.latvian.mods.projectex.item.weapon.BlueKatar;
import dev.latvian.mods.projectex.item.weapon.BlueMorningStar;
import dev.latvian.mods.projectex.item.weapon.BluePickaxe;
import dev.latvian.mods.projectex.item.weapon.BlueShears;
import dev.latvian.mods.projectex.item.weapon.BlueShovel;
import dev.latvian.mods.projectex.item.weapon.BlueSword;
import dev.latvian.mods.projectex.item.weapon.CyanAxe;
import dev.latvian.mods.projectex.item.weapon.CyanHammer;
import dev.latvian.mods.projectex.item.weapon.CyanHoe;
import dev.latvian.mods.projectex.item.weapon.CyanKatar;
import dev.latvian.mods.projectex.item.weapon.CyanMorningStar;
import dev.latvian.mods.projectex.item.weapon.CyanPickaxe;
import dev.latvian.mods.projectex.item.weapon.CyanShears;
import dev.latvian.mods.projectex.item.weapon.CyanShovel;
import dev.latvian.mods.projectex.item.weapon.CyanSword;
import dev.latvian.mods.projectex.item.weapon.GreenAxe;
import dev.latvian.mods.projectex.item.weapon.GreenHammer;
import dev.latvian.mods.projectex.item.weapon.GreenHoe;
import dev.latvian.mods.projectex.item.weapon.GreenKatar;
import dev.latvian.mods.projectex.item.weapon.GreenMorningStar;
import dev.latvian.mods.projectex.item.weapon.GreenPickaxe;
import dev.latvian.mods.projectex.item.weapon.GreenShears;
import dev.latvian.mods.projectex.item.weapon.GreenShovel;
import dev.latvian.mods.projectex.item.weapon.GreenSword;
import dev.latvian.mods.projectex.item.weapon.LimeAxe;
import dev.latvian.mods.projectex.item.weapon.LimeHammer;
import dev.latvian.mods.projectex.item.weapon.LimeHoe;
import dev.latvian.mods.projectex.item.weapon.LimeKatar;
import dev.latvian.mods.projectex.item.weapon.LimeMorningStar;
import dev.latvian.mods.projectex.item.weapon.LimePickaxe;
import dev.latvian.mods.projectex.item.weapon.LimeShears;
import dev.latvian.mods.projectex.item.weapon.LimeShovel;
import dev.latvian.mods.projectex.item.weapon.LimeSword;
import dev.latvian.mods.projectex.item.weapon.YellowAxe;
import dev.latvian.mods.projectex.item.weapon.YellowHammer;
import dev.latvian.mods.projectex.item.weapon.YellowHoe;
import dev.latvian.mods.projectex.item.weapon.YellowKatar;
import dev.latvian.mods.projectex.item.weapon.YellowMorningStar;
import dev.latvian.mods.projectex.item.weapon.YellowPickaxe;
import dev.latvian.mods.projectex.item.weapon.YellowShears;
import dev.latvian.mods.projectex.item.weapon.YellowShovel;
import dev.latvian.mods.projectex.item.weapon.YellowSword;
import dev.latvian.mods.projectex.item.weapon.OrangeAxe;
import dev.latvian.mods.projectex.item.weapon.OrangeHammer;
import dev.latvian.mods.projectex.item.weapon.OrangeHoe;
import dev.latvian.mods.projectex.item.weapon.OrangeKatar;
import dev.latvian.mods.projectex.item.weapon.OrangeMorningStar;
import dev.latvian.mods.projectex.item.weapon.OrangePickaxe;
import dev.latvian.mods.projectex.item.weapon.OrangeShears;
import dev.latvian.mods.projectex.item.weapon.OrangeShovel;
import dev.latvian.mods.projectex.item.weapon.OrangeSword;
import dev.latvian.mods.projectex.item.weapon.WhiteAxe;
import dev.latvian.mods.projectex.item.weapon.WhiteHammer;
import dev.latvian.mods.projectex.item.weapon.WhiteHoe;
import dev.latvian.mods.projectex.item.weapon.WhiteKatar;
import dev.latvian.mods.projectex.item.weapon.WhiteMorningStar;
import dev.latvian.mods.projectex.item.weapon.WhitePickaxe;
import dev.latvian.mods.projectex.item.weapon.WhiteShears;
import dev.latvian.mods.projectex.item.weapon.WhiteShovel;
import dev.latvian.mods.projectex.item.weapon.WhiteSword;
import dev.latvian.mods.projectex.item.weapon.FadingAxe;
import dev.latvian.mods.projectex.item.weapon.FadingHammer;
import dev.latvian.mods.projectex.item.weapon.FadingHoe;
import dev.latvian.mods.projectex.item.weapon.FadingKatar;
import dev.latvian.mods.projectex.item.weapon.FadingMorningStar;
import dev.latvian.mods.projectex.item.weapon.FadingPickaxe;
import dev.latvian.mods.projectex.item.weapon.FadingShears;
import dev.latvian.mods.projectex.item.weapon.FadingShovel;
import dev.latvian.mods.projectex.item.weapon.FadingSword;
import dev.latvian.mods.projectex.item.armor.PinkGemBoots;
import dev.latvian.mods.projectex.item.armor.PinkGemChestplate;
import dev.latvian.mods.projectex.item.armor.PinkGemHelmet;
import dev.latvian.mods.projectex.item.armor.PinkGemLeggings;
import dev.latvian.mods.projectex.item.armor.PurpleArmor;
import dev.latvian.mods.projectex.item.armor.PurpleGemBoots;
import dev.latvian.mods.projectex.item.armor.PurpleGemChestplate;
import dev.latvian.mods.projectex.item.armor.PurpleGemHelmet;
import dev.latvian.mods.projectex.item.armor.PurpleGemLeggings;
import dev.latvian.mods.projectex.item.armor.BlueArmor;
import dev.latvian.mods.projectex.item.armor.BlueGemBoots;
import dev.latvian.mods.projectex.item.armor.BlueGemChestplate;
import dev.latvian.mods.projectex.item.armor.BlueGemHelmet;
import dev.latvian.mods.projectex.item.armor.BlueGemLeggings;
import dev.latvian.mods.projectex.item.armor.CyanArmor;
import dev.latvian.mods.projectex.item.armor.CyanGemBoots;
import dev.latvian.mods.projectex.item.armor.CyanGemChestplate;
import dev.latvian.mods.projectex.item.armor.CyanGemHelmet;
import dev.latvian.mods.projectex.item.armor.CyanGemLeggings;
import dev.latvian.mods.projectex.item.armor.GreenArmor;
import dev.latvian.mods.projectex.item.armor.GreenGemBoots;
import dev.latvian.mods.projectex.item.armor.GreenGemChestplate;
import dev.latvian.mods.projectex.item.armor.GreenGemHelmet;
import dev.latvian.mods.projectex.item.armor.GreenGemLeggings;
import dev.latvian.mods.projectex.item.armor.LimeArmor;
import dev.latvian.mods.projectex.item.armor.LimeGemBoots;
import dev.latvian.mods.projectex.item.armor.LimeGemChestplate;
import dev.latvian.mods.projectex.item.armor.LimeGemHelmet;
import dev.latvian.mods.projectex.item.armor.LimeGemLeggings;
import dev.latvian.mods.projectex.item.armor.YellowArmor;
import dev.latvian.mods.projectex.item.armor.YellowGemBoots;
import dev.latvian.mods.projectex.item.armor.YellowGemChestplate;
import dev.latvian.mods.projectex.item.armor.YellowGemHelmet;
import dev.latvian.mods.projectex.item.armor.YellowGemLeggings;
import dev.latvian.mods.projectex.item.armor.OrangeArmor;
import dev.latvian.mods.projectex.item.armor.OrangeGemBoots;
import dev.latvian.mods.projectex.item.armor.OrangeGemChestplate;
import dev.latvian.mods.projectex.item.armor.OrangeGemHelmet;
import dev.latvian.mods.projectex.item.armor.OrangeGemLeggings;
import dev.latvian.mods.projectex.item.armor.WhiteArmor;
import dev.latvian.mods.projectex.item.armor.WhiteGemBoots;
import dev.latvian.mods.projectex.item.armor.WhiteGemChestplate;
import dev.latvian.mods.projectex.item.armor.WhiteGemHelmet;
import dev.latvian.mods.projectex.item.armor.WhiteGemLeggings;
import dev.latvian.mods.projectex.item.armor.FadingArmorBase;
import dev.latvian.mods.projectex.item.armor.FadingBoots;
import dev.latvian.mods.projectex.item.armor.FadingChestplate;
import dev.latvian.mods.projectex.item.armor.FadingHelmet;
import dev.latvian.mods.projectex.item.armor.FadingLeggings;
import net.minecraft.Util;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

public interface ProjectEXItems {
	DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ProjectEX.MOD_ID);

	static RegistryObject<BlockItem> blockItem(String id, Supplier<Block> sup) {
		return REGISTRY.register(id, () -> new BlockItem(sup.get(), new Item.Properties()));
	}

	RegistryObject<BlockItem> ENERGY_LINK = blockItem("energy_link", ProjectEXBlocks.ENERGY_LINK);
	RegistryObject<BlockItem> PERSONAL_LINK = blockItem("personal_link", ProjectEXBlocks.PERSONAL_LINK);
	RegistryObject<BlockItem> REFINED_LINK = blockItem("refined_link", ProjectEXBlocks.REFINED_LINK);
	RegistryObject<BlockItem> COMPRESSED_REFINED_LINK = blockItem("compressed_refined_link", ProjectEXBlocks.COMPRESSED_REFINED_LINK);
	RegistryObject<BlockItem> STONE_TABLE = blockItem("stone_table", ProjectEXBlocks.STONE_TABLE);

	Map<Matter, RegistryObject<BlockItem>> COLLECTOR = Util.make(new LinkedHashMap<>(), map -> {
		for (Matter matter : Matter.VALUES) {
			map.put(matter, blockItem(matter.name + "_collector", ProjectEXBlocks.COLLECTOR.get(matter)));
		}
	});

	Map<Matter, RegistryObject<BlockItem>> RELAY = Util.make(new LinkedHashMap<>(), map -> {
		for (Matter matter : Matter.VALUES) {
			map.put(matter, blockItem(matter.name + "_relay", ProjectEXBlocks.RELAY.get(matter)));
		}
	});

	Map<Matter, RegistryObject<BlockItem>> POWER_FLOWER = Util.make(new LinkedHashMap<>(), map -> {
		for (Matter matter : Matter.VALUES) {
			map.put(matter, blockItem(matter.name + "_power_flower", ProjectEXBlocks.POWER_FLOWER.get(matter)));
		}
	});

	Map<Matter, RegistryObject<Item>> MATTER = Util.make(new LinkedHashMap<>(), map -> {
		for (Matter matter : Matter.VALUES) {
			if (matter.hasMatterItem) {
				map.put(matter, REGISTRY.register(matter.name + "_matter", BasicItem::new));
			}
		}
	});

	Map<Matter, RegistryObject<Item>> COMPRESSED_COLLECTOR = Util.make(new LinkedHashMap<>(), map -> {
		for (Matter matter : Matter.VALUES) {
			map.put(matter, REGISTRY.register(matter.name + "_compressed_collector", FoilItem::new));
		}
	});

	RegistryObject<Item> FINAL_STAR_SHARD = REGISTRY.register("final_star_shard", BasicItem::new);
	RegistryObject<Item> FINAL_STAR = REGISTRY.register("final_star", FinalStarItem::new);
	RegistryObject<Item> ARCANE_TABLET = REGISTRY.register("arcane_tablet", ArcaneTabletItem::new);

	Map<Star, RegistryObject<Item>> MAGNUM_STAR = Util.make(new LinkedHashMap<>(), map -> {
		for (Star star : Star.VALUES) {
			map.put(star, REGISTRY.register("magnum_star_" + star.name, () -> new StarItem(star.magnumCapacity, Rarity.RARE)));
		}
	});

	Map<Star, RegistryObject<Item>> COLOSSAL_STAR = Util.make(new LinkedHashMap<>(), map -> {
		for (Star star : Star.VALUES) {
			map.put(star, REGISTRY.register("colossal_star_" + star.name, () -> new StarItem(star.colossalCapacity, Rarity.EPIC)));
		}
	});

	RegistryObject<PinkArmor> PINK_HELMET = REGISTRY.register("pink_helmet", () -> new PinkArmor(ArmorItem.Type.HELMET, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PinkArmor> PINK_CHESTPLATE = REGISTRY.register("pink_chestplate", () -> new PinkArmor(ArmorItem.Type.CHESTPLATE, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PinkArmor> PINK_LEGGINGS = REGISTRY.register("pink_leggings", () -> new PinkArmor(ArmorItem.Type.LEGGINGS, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PinkArmor> PINK_BOOTS = REGISTRY.register("pink_boots", () -> new PinkArmor(ArmorItem.Type.BOOTS, new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<PinkGemHelmet> PINK_GEM_HELMET = REGISTRY.register("pink_gem_helmet", () -> new PinkGemHelmet(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PinkGemChestplate> PINK_GEM_CHESTPLATE = REGISTRY.register("pink_gem_chestplate", () -> new PinkGemChestplate(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PinkGemLeggings> PINK_GEM_LEGGINGS = REGISTRY.register("pink_gem_leggings", () -> new PinkGemLeggings(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PinkGemBoots> PINK_GEM_BOOTS = REGISTRY.register("pink_gem_boots", () -> new PinkGemBoots(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<PurpleArmor> PURPLE_HELMET = REGISTRY.register("purple_helmet", () -> new PurpleArmor(ArmorItem.Type.HELMET, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PurpleArmor> PURPLE_CHESTPLATE = REGISTRY.register("purple_chestplate", () -> new PurpleArmor(ArmorItem.Type.CHESTPLATE, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PurpleArmor> PURPLE_LEGGINGS = REGISTRY.register("purple_leggings", () -> new PurpleArmor(ArmorItem.Type.LEGGINGS, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PurpleArmor> PURPLE_BOOTS = REGISTRY.register("purple_boots", () -> new PurpleArmor(ArmorItem.Type.BOOTS, new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<PurpleGemHelmet> PURPLE_GEM_HELMET = REGISTRY.register("purple_gem_helmet", () -> new PurpleGemHelmet(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PurpleGemChestplate> PURPLE_GEM_CHESTPLATE = REGISTRY.register("purple_gem_chestplate", () -> new PurpleGemChestplate(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PurpleGemLeggings> PURPLE_GEM_LEGGINGS = REGISTRY.register("purple_gem_leggings", () -> new PurpleGemLeggings(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PurpleGemBoots> PURPLE_GEM_BOOTS = REGISTRY.register("purple_gem_boots", () -> new PurpleGemBoots(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<BlueArmor> BLUE_HELMET = REGISTRY.register("blue_helmet", () -> new BlueArmor(ArmorItem.Type.HELMET, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<BlueArmor> BLUE_CHESTPLATE = REGISTRY.register("blue_chestplate", () -> new BlueArmor(ArmorItem.Type.CHESTPLATE, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<BlueArmor> BLUE_LEGGINGS = REGISTRY.register("blue_leggings", () -> new BlueArmor(ArmorItem.Type.LEGGINGS, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<BlueArmor> BLUE_BOOTS = REGISTRY.register("blue_boots", () -> new BlueArmor(ArmorItem.Type.BOOTS, new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<BlueGemHelmet> BLUE_GEM_HELMET = REGISTRY.register("blue_gem_helmet", () -> new BlueGemHelmet(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<BlueGemChestplate> BLUE_GEM_CHESTPLATE = REGISTRY.register("blue_gem_chestplate", () -> new BlueGemChestplate(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<BlueGemLeggings> BLUE_GEM_LEGGINGS = REGISTRY.register("blue_gem_leggings", () -> new BlueGemLeggings(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<BlueGemBoots> BLUE_GEM_BOOTS = REGISTRY.register("blue_gem_boots", () -> new BlueGemBoots(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<CyanArmor> CYAN_HELMET = REGISTRY.register("cyan_helmet", () -> new CyanArmor(ArmorItem.Type.HELMET, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<CyanArmor> CYAN_CHESTPLATE = REGISTRY.register("cyan_chestplate", () -> new CyanArmor(ArmorItem.Type.CHESTPLATE, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<CyanArmor> CYAN_LEGGINGS = REGISTRY.register("cyan_leggings", () -> new CyanArmor(ArmorItem.Type.LEGGINGS, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<CyanArmor> CYAN_BOOTS = REGISTRY.register("cyan_boots", () -> new CyanArmor(ArmorItem.Type.BOOTS, new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<CyanGemHelmet> CYAN_GEM_HELMET = REGISTRY.register("cyan_gem_helmet", () -> new CyanGemHelmet(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<CyanGemChestplate> CYAN_GEM_CHESTPLATE = REGISTRY.register("cyan_gem_chestplate", () -> new CyanGemChestplate(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<CyanGemLeggings> CYAN_GEM_LEGGINGS = REGISTRY.register("cyan_gem_leggings", () -> new CyanGemLeggings(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<CyanGemBoots> CYAN_GEM_BOOTS = REGISTRY.register("cyan_gem_boots", () -> new CyanGemBoots(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<GreenArmor> GREEN_HELMET = REGISTRY.register("green_helmet", () -> new GreenArmor(ArmorItem.Type.HELMET, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<GreenArmor> GREEN_CHESTPLATE = REGISTRY.register("green_chestplate", () -> new GreenArmor(ArmorItem.Type.CHESTPLATE, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<GreenArmor> GREEN_LEGGINGS = REGISTRY.register("green_leggings", () -> new GreenArmor(ArmorItem.Type.LEGGINGS, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<GreenArmor> GREEN_BOOTS = REGISTRY.register("green_boots", () -> new GreenArmor(ArmorItem.Type.BOOTS, new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<GreenGemHelmet> GREEN_GEM_HELMET = REGISTRY.register("green_gem_helmet", () -> new GreenGemHelmet(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<GreenGemChestplate> GREEN_GEM_CHESTPLATE = REGISTRY.register("green_gem_chestplate", () -> new GreenGemChestplate(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<GreenGemLeggings> GREEN_GEM_LEGGINGS = REGISTRY.register("green_gem_leggings", () -> new GreenGemLeggings(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<GreenGemBoots> GREEN_GEM_BOOTS = REGISTRY.register("green_gem_boots", () -> new GreenGemBoots(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<LimeArmor> LIME_HELMET = REGISTRY.register("lime_helmet", () -> new LimeArmor(ArmorItem.Type.HELMET, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<LimeArmor> LIME_CHESTPLATE = REGISTRY.register("lime_chestplate", () -> new LimeArmor(ArmorItem.Type.CHESTPLATE, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<LimeArmor> LIME_LEGGINGS = REGISTRY.register("lime_leggings", () -> new LimeArmor(ArmorItem.Type.LEGGINGS, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<LimeArmor> LIME_BOOTS = REGISTRY.register("lime_boots", () -> new LimeArmor(ArmorItem.Type.BOOTS, new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<LimeGemHelmet> LIME_GEM_HELMET = REGISTRY.register("lime_gem_helmet", () -> new LimeGemHelmet(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<LimeGemChestplate> LIME_GEM_CHESTPLATE = REGISTRY.register("lime_gem_chestplate", () -> new LimeGemChestplate(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<LimeGemLeggings> LIME_GEM_LEGGINGS = REGISTRY.register("lime_gem_leggings", () -> new LimeGemLeggings(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<LimeGemBoots> LIME_GEM_BOOTS = REGISTRY.register("lime_gem_boots", () -> new LimeGemBoots(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<YellowArmor> YELLOW_HELMET = REGISTRY.register("yellow_helmet", () -> new YellowArmor(ArmorItem.Type.HELMET, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<YellowArmor> YELLOW_CHESTPLATE = REGISTRY.register("yellow_chestplate", () -> new YellowArmor(ArmorItem.Type.CHESTPLATE, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<YellowArmor> YELLOW_LEGGINGS = REGISTRY.register("yellow_leggings", () -> new YellowArmor(ArmorItem.Type.LEGGINGS, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<YellowArmor> YELLOW_BOOTS = REGISTRY.register("yellow_boots", () -> new YellowArmor(ArmorItem.Type.BOOTS, new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<YellowGemHelmet> YELLOW_GEM_HELMET = REGISTRY.register("yellow_gem_helmet", () -> new YellowGemHelmet(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<YellowGemChestplate> YELLOW_GEM_CHESTPLATE = REGISTRY.register("yellow_gem_chestplate", () -> new YellowGemChestplate(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<YellowGemLeggings> YELLOW_GEM_LEGGINGS = REGISTRY.register("yellow_gem_leggings", () -> new YellowGemLeggings(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<YellowGemBoots> YELLOW_GEM_BOOTS = REGISTRY.register("yellow_gem_boots", () -> new YellowGemBoots(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<OrangeArmor> ORANGE_HELMET = REGISTRY.register("orange_helmet", () -> new OrangeArmor(ArmorItem.Type.HELMET, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<OrangeArmor> ORANGE_CHESTPLATE = REGISTRY.register("orange_chestplate", () -> new OrangeArmor(ArmorItem.Type.CHESTPLATE, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<OrangeArmor> ORANGE_LEGGINGS = REGISTRY.register("orange_leggings", () -> new OrangeArmor(ArmorItem.Type.LEGGINGS, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<OrangeArmor> ORANGE_BOOTS = REGISTRY.register("orange_boots", () -> new OrangeArmor(ArmorItem.Type.BOOTS, new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<OrangeGemHelmet> ORANGE_GEM_HELMET = REGISTRY.register("orange_gem_helmet", () -> new OrangeGemHelmet(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<OrangeGemChestplate> ORANGE_GEM_CHESTPLATE = REGISTRY.register("orange_gem_chestplate", () -> new OrangeGemChestplate(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<OrangeGemLeggings> ORANGE_GEM_LEGGINGS = REGISTRY.register("orange_gem_leggings", () -> new OrangeGemLeggings(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<OrangeGemBoots> ORANGE_GEM_BOOTS = REGISTRY.register("orange_gem_boots", () -> new OrangeGemBoots(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<WhiteArmor> WHITE_HELMET = REGISTRY.register("white_helmet", () -> new WhiteArmor(ArmorItem.Type.HELMET, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<WhiteArmor> WHITE_CHESTPLATE = REGISTRY.register("white_chestplate", () -> new WhiteArmor(ArmorItem.Type.CHESTPLATE, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<WhiteArmor> WHITE_LEGGINGS = REGISTRY.register("white_leggings", () -> new WhiteArmor(ArmorItem.Type.LEGGINGS, new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<WhiteArmor> WHITE_BOOTS = REGISTRY.register("white_boots", () -> new WhiteArmor(ArmorItem.Type.BOOTS, new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<WhiteGemHelmet> WHITE_GEM_HELMET = REGISTRY.register("white_gem_helmet", () -> new WhiteGemHelmet(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<WhiteGemChestplate> WHITE_GEM_CHESTPLATE = REGISTRY.register("white_gem_chestplate", () -> new WhiteGemChestplate(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<WhiteGemLeggings> WHITE_GEM_LEGGINGS = REGISTRY.register("white_gem_leggings", () -> new WhiteGemLeggings(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<WhiteGemBoots> WHITE_GEM_BOOTS = REGISTRY.register("white_gem_boots", () -> new WhiteGemBoots(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<FadingHelmet> FADING_HELMET = REGISTRY.register("fading_helmet", () -> new FadingHelmet(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<FadingChestplate> FADING_CHESTPLATE = REGISTRY.register("fading_chestplate", () -> new FadingChestplate(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<FadingLeggings> FADING_LEGGINGS = REGISTRY.register("fading_leggings", () -> new FadingLeggings(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<FadingBoots> FADING_BOOTS = REGISTRY.register("fading_boots", () -> new FadingBoots(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<PinkSword> PINK_SWORD = REGISTRY.register("pink_sword", () -> new PinkSword(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PinkPickaxe> PINK_PICKAXE = REGISTRY.register("pink_pickaxe", () -> new PinkPickaxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PinkAxe> PINK_AXE = REGISTRY.register("pink_axe", () -> new PinkAxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PinkShovel> PINK_SHOVEL = REGISTRY.register("pink_shovel", () -> new PinkShovel(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PinkHoe> PINK_HOE = REGISTRY.register("pink_hoe", () -> new PinkHoe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PinkShears> PINK_SHEARS = REGISTRY.register("pink_shears", () -> new PinkShears(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PinkHammer> PINK_HAMMER = REGISTRY.register("pink_hammer", () -> new PinkHammer(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PinkKatar> PINK_KATAR = REGISTRY.register("pink_katar", () -> new PinkKatar(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PinkMorningStar> PINK_MORNING_STAR = REGISTRY.register("pink_morning_star", () -> new PinkMorningStar(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<PurpleSword> PURPLE_SWORD = REGISTRY.register("purple_sword", () -> new PurpleSword(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PurplePickaxe> PURPLE_PICKAXE = REGISTRY.register("purple_pickaxe", () -> new PurplePickaxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PurpleAxe> PURPLE_AXE = REGISTRY.register("purple_axe", () -> new PurpleAxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PurpleShovel> PURPLE_SHOVEL = REGISTRY.register("purple_shovel", () -> new PurpleShovel(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PurpleHoe> PURPLE_HOE = REGISTRY.register("purple_hoe", () -> new PurpleHoe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PurpleShears> PURPLE_SHEARS = REGISTRY.register("purple_shears", () -> new PurpleShears(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PurpleHammer> PURPLE_HAMMER = REGISTRY.register("purple_hammer", () -> new PurpleHammer(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PurpleKatar> PURPLE_KATAR = REGISTRY.register("purple_katar", () -> new PurpleKatar(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<PurpleMorningStar> PURPLE_MORNING_STAR = REGISTRY.register("purple_morning_star", () -> new PurpleMorningStar(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<BlueSword> BLUE_SWORD = REGISTRY.register("blue_sword", () -> new BlueSword(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<BluePickaxe> BLUE_PICKAXE = REGISTRY.register("blue_pickaxe", () -> new BluePickaxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<BlueAxe> BLUE_AXE = REGISTRY.register("blue_axe", () -> new BlueAxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<BlueShovel> BLUE_SHOVEL = REGISTRY.register("blue_shovel", () -> new BlueShovel(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<BlueHoe> BLUE_HOE = REGISTRY.register("blue_hoe", () -> new BlueHoe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<BlueShears> BLUE_SHEARS = REGISTRY.register("blue_shears", () -> new BlueShears(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<BlueHammer> BLUE_HAMMER = REGISTRY.register("blue_hammer", () -> new BlueHammer(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<BlueKatar> BLUE_KATAR = REGISTRY.register("blue_katar", () -> new BlueKatar(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<BlueMorningStar> BLUE_MORNING_STAR = REGISTRY.register("blue_morning_star", () -> new BlueMorningStar(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<CyanSword> CYAN_SWORD = REGISTRY.register("cyan_sword", () -> new CyanSword(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<CyanPickaxe> CYAN_PICKAXE = REGISTRY.register("cyan_pickaxe", () -> new CyanPickaxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<CyanAxe> CYAN_AXE = REGISTRY.register("cyan_axe", () -> new CyanAxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<CyanShovel> CYAN_SHOVEL = REGISTRY.register("cyan_shovel", () -> new CyanShovel(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<CyanHoe> CYAN_HOE = REGISTRY.register("cyan_hoe", () -> new CyanHoe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<CyanShears> CYAN_SHEARS = REGISTRY.register("cyan_shears", () -> new CyanShears(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<CyanHammer> CYAN_HAMMER = REGISTRY.register("cyan_hammer", () -> new CyanHammer(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<CyanKatar> CYAN_KATAR = REGISTRY.register("cyan_katar", () -> new CyanKatar(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<CyanMorningStar> CYAN_MORNING_STAR = REGISTRY.register("cyan_morning_star", () -> new CyanMorningStar(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<GreenSword> GREEN_SWORD = REGISTRY.register("green_sword", () -> new GreenSword(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<GreenPickaxe> GREEN_PICKAXE = REGISTRY.register("green_pickaxe", () -> new GreenPickaxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<GreenAxe> GREEN_AXE = REGISTRY.register("green_axe", () -> new GreenAxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<GreenShovel> GREEN_SHOVEL = REGISTRY.register("green_shovel", () -> new GreenShovel(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<GreenHoe> GREEN_HOE = REGISTRY.register("green_hoe", () -> new GreenHoe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<GreenShears> GREEN_SHEARS = REGISTRY.register("green_shears", () -> new GreenShears(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<GreenHammer> GREEN_HAMMER = REGISTRY.register("green_hammer", () -> new GreenHammer(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<GreenKatar> GREEN_KATAR = REGISTRY.register("green_katar", () -> new GreenKatar(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<GreenMorningStar> GREEN_MORNING_STAR = REGISTRY.register("green_morning_star", () -> new GreenMorningStar(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<LimeSword> LIME_SWORD = REGISTRY.register("lime_sword", () -> new LimeSword(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<LimePickaxe> LIME_PICKAXE = REGISTRY.register("lime_pickaxe", () -> new LimePickaxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<LimeAxe> LIME_AXE = REGISTRY.register("lime_axe", () -> new LimeAxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<LimeShovel> LIME_SHOVEL = REGISTRY.register("lime_shovel", () -> new LimeShovel(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<LimeHoe> LIME_HOE = REGISTRY.register("lime_hoe", () -> new LimeHoe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<LimeShears> LIME_SHEARS = REGISTRY.register("lime_shears", () -> new LimeShears(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<LimeHammer> LIME_HAMMER = REGISTRY.register("lime_hammer", () -> new LimeHammer(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<LimeKatar> LIME_KATAR = REGISTRY.register("lime_katar", () -> new LimeKatar(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<LimeMorningStar> LIME_MORNING_STAR = REGISTRY.register("lime_morning_star", () -> new LimeMorningStar(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<YellowSword> YELLOW_SWORD = REGISTRY.register("yellow_sword", () -> new YellowSword(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<YellowPickaxe> YELLOW_PICKAXE = REGISTRY.register("yellow_pickaxe", () -> new YellowPickaxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<YellowAxe> YELLOW_AXE = REGISTRY.register("yellow_axe", () -> new YellowAxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<YellowShovel> YELLOW_SHOVEL = REGISTRY.register("yellow_shovel", () -> new YellowShovel(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<YellowHoe> YELLOW_HOE = REGISTRY.register("yellow_hoe", () -> new YellowHoe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<YellowShears> YELLOW_SHEARS = REGISTRY.register("yellow_shears", () -> new YellowShears(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<YellowHammer> YELLOW_HAMMER = REGISTRY.register("yellow_hammer", () -> new YellowHammer(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<YellowKatar> YELLOW_KATAR = REGISTRY.register("yellow_katar", () -> new YellowKatar(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<YellowMorningStar> YELLOW_MORNING_STAR = REGISTRY.register("yellow_morning_star", () -> new YellowMorningStar(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<OrangeSword> ORANGE_SWORD = REGISTRY.register("orange_sword", () -> new OrangeSword(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<OrangePickaxe> ORANGE_PICKAXE = REGISTRY.register("orange_pickaxe", () -> new OrangePickaxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<OrangeAxe> ORANGE_AXE = REGISTRY.register("orange_axe", () -> new OrangeAxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<OrangeShovel> ORANGE_SHOVEL = REGISTRY.register("orange_shovel", () -> new OrangeShovel(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<OrangeHoe> ORANGE_HOE = REGISTRY.register("orange_hoe", () -> new OrangeHoe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<OrangeShears> ORANGE_SHEARS = REGISTRY.register("orange_shears", () -> new OrangeShears(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<OrangeHammer> ORANGE_HAMMER = REGISTRY.register("orange_hammer", () -> new OrangeHammer(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<OrangeKatar> ORANGE_KATAR = REGISTRY.register("orange_katar", () -> new OrangeKatar(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<OrangeMorningStar> ORANGE_MORNING_STAR = REGISTRY.register("orange_morning_star", () -> new OrangeMorningStar(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<WhiteSword> WHITE_SWORD = REGISTRY.register("white_sword", () -> new WhiteSword(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<WhitePickaxe> WHITE_PICKAXE = REGISTRY.register("white_pickaxe", () -> new WhitePickaxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<WhiteAxe> WHITE_AXE = REGISTRY.register("white_axe", () -> new WhiteAxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<WhiteShovel> WHITE_SHOVEL = REGISTRY.register("white_shovel", () -> new WhiteShovel(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<WhiteHoe> WHITE_HOE = REGISTRY.register("white_hoe", () -> new WhiteHoe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<WhiteShears> WHITE_SHEARS = REGISTRY.register("white_shears", () -> new WhiteShears(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<WhiteHammer> WHITE_HAMMER = REGISTRY.register("white_hammer", () -> new WhiteHammer(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<WhiteKatar> WHITE_KATAR = REGISTRY.register("white_katar", () -> new WhiteKatar(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<WhiteMorningStar> WHITE_MORNING_STAR = REGISTRY.register("white_morning_star", () -> new WhiteMorningStar(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<FadingSword> FADING_SWORD = REGISTRY.register("fading_sword", () -> new FadingSword(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<FadingPickaxe> FADING_PICKAXE = REGISTRY.register("fading_pickaxe", () -> new FadingPickaxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<FadingAxe> FADING_AXE = REGISTRY.register("fading_axe", () -> new FadingAxe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<FadingShovel> FADING_SHOVEL = REGISTRY.register("fading_shovel", () -> new FadingShovel(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<FadingHoe> FADING_HOE = REGISTRY.register("fading_hoe", () -> new FadingHoe(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<FadingShears> FADING_SHEARS = REGISTRY.register("fading_shears", () -> new FadingShears(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<FadingHammer> FADING_HAMMER = REGISTRY.register("fading_hammer", () -> new FadingHammer(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<FadingKatar> FADING_KATAR = REGISTRY.register("fading_katar", () -> new FadingKatar(new Item.Properties().rarity(Rarity.EPIC)));
	RegistryObject<FadingMorningStar> FADING_MORNING_STAR = REGISTRY.register("fading_morning_star", () -> new FadingMorningStar(new Item.Properties().rarity(Rarity.EPIC)));

	RegistryObject<Item> HELMET_CONGLOMERATE = REGISTRY.register("helmet_conglomerate", BasicItem::new);
	RegistryObject<Item> CHESTPLATE_CONGLOMERATE = REGISTRY.register("chestplate_conglomerate", BasicItem::new);
	RegistryObject<Item> LEGGINGS_CONGLOMERATE = REGISTRY.register("leggings_conglomerate", BasicItem::new);
	RegistryObject<Item> BOOTS_CONGLOMERATE = REGISTRY.register("boots_conglomerate", BasicItem::new);
}
