package dev.latvian.mods.projectex.net;

import dev.latvian.mods.projectex.menu.ArcaneTabletMenu;
import moze_intel.projecte.api.ItemInfo;
import moze_intel.projecte.api.ProjectEAPI;
import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.proxy.IEMCProxy;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.network.NetworkEvent;

import java.math.BigInteger;
import java.util.function.Supplier;

public class ArcaneTabletTransferPacket {
	private static final int MAX_ALTS_PER_CELL = 64;
	private static final int MAIN_INV_SIZE = 36;

	public final ItemStack[][] cells;

	public ArcaneTabletTransferPacket(ItemStack[][] cells) {
		this.cells = cells;
	}

	public static void encode(ArcaneTabletTransferPacket pkt, FriendlyByteBuf buf) {
		for (int i = 0; i < 9; i++) {
			ItemStack[] alts = (i < pkt.cells.length && pkt.cells[i] != null) ? pkt.cells[i] : new ItemStack[0];
			int n = Math.min(alts.length, MAX_ALTS_PER_CELL);
			buf.writeByte(n);
			for (int j = 0; j < n; j++) {
				buf.writeItem(alts[j] == null ? ItemStack.EMPTY : alts[j]);
			}
		}
	}

	public static ArcaneTabletTransferPacket decode(FriendlyByteBuf buf) {
		ItemStack[][] cells = new ItemStack[9][];
		for (int i = 0; i < 9; i++) {
			int n = Math.min(buf.readByte() & 0xFF, MAX_ALTS_PER_CELL);
			cells[i] = new ItemStack[n];
			for (int j = 0; j < n; j++) {
				cells[i][j] = buf.readItem();
			}
		}
		return new ArcaneTabletTransferPacket(cells);
	}

	public static void handle(ArcaneTabletTransferPacket pkt, Supplier<NetworkEvent.Context> ctxSup) {
		NetworkEvent.Context ctx = ctxSup.get();
		ctx.enqueueWork(() -> {
			ServerPlayer sp = ctx.getSender();
			if (sp == null) return;
			if (!(sp.containerMenu instanceof ArcaneTabletMenu menu)) return;
			apply(sp, menu, pkt.cells);
		});
		ctx.setPacketHandled(true);
	}

	private static void apply(ServerPlayer sp, ArcaneTabletMenu menu, ItemStack[][] cells) {
		// Empty current matrix back to player inventory
		for (int i = 0; i < 9; i++) {
			ItemStack stack = menu.craftMatrix.removeItemNoUpdate(i);
			if (!stack.isEmpty()) {
				ItemHandlerHelper.giveItemToPlayer(sp, stack);
			}
		}

		IKnowledgeProvider provider = menu.provider;
		IEMCProxy emc = ProjectEAPI.getEMCProxy();
		Inventory inv = sp.getInventory();
		BigInteger emcAvailable = provider.getEmc();
		boolean emcChanged = false;

		for (int i = 0; i < 9; i++) {
			ItemStack[] alts = cells[i];
			if (alts == null || alts.length == 0) continue;

			ItemStack chosen = ItemStack.EMPTY;

			// inventory pass
			for (ItemStack alt : alts) {
				if (alt == null || alt.isEmpty()) continue;
				int idx = findInInventory(inv, alt);
				if (idx >= 0) {
					ItemStack stack = inv.getItem(idx);
					chosen = stack.split(1);
					if (stack.isEmpty()) inv.setItem(idx, ItemStack.EMPTY);
					break;
				}
			}

			// EMC fallback: drain EMC for items the player has knowledge of
			if (chosen.isEmpty()) {
				for (ItemStack alt : alts) {
					if (alt == null || alt.isEmpty()) continue;
					long perItem = emc.getValue(alt);
					if (perItem <= 0L) continue;
					ItemInfo info = emc.getPersistentInfo(ItemInfo.fromStack(alt));
					if (!provider.hasKnowledge(info)) continue;
					BigInteger cost = BigInteger.valueOf(perItem);
					if (emcAvailable.compareTo(cost) < 0) continue;
					emcAvailable = emcAvailable.subtract(cost);
					emcChanged = true;
					ItemStack copy = alt.copy();
					copy.setCount(1);
					chosen = copy;
					break;
				}
			}

			if (!chosen.isEmpty()) {
				menu.craftMatrix.setItem(i, chosen);
			}
		}

		if (emcChanged) {
			provider.setEmc(emcAvailable);
			provider.syncEmc(sp);
		}
		menu.slotsChanged(menu.craftMatrix);
	}

	private static int findInInventory(Inventory inv, ItemStack template) {
		int max = Math.min(inv.getContainerSize(), MAIN_INV_SIZE);
		for (int i = 0; i < max; i++) {
			ItemStack stack = inv.getItem(i);
			if (stack.isEmpty()) continue;
			if (ItemStack.isSameItemSameTags(stack, template)) {
				return i;
			}
		}
		return -1;
	}
}
