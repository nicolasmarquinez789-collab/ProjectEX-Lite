package dev.latvian.mods.projectex.mixin;

import dev.latvian.mods.projectex.util.EmcAbbrev;
import moze_intel.projecte.utils.TransmutationEMCFormatter;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(TransmutationEMCFormatter.class)
public class TransmutationEMCFormatterMixin {
	@Inject(method = "formatEMC", at = @At("HEAD"), cancellable = true, remap = false)
	private static void projectex$override(Number number, CallbackInfoReturnable<Component> cir) {
		if (Screen.hasShiftDown()) {
			cir.setReturnValue(Component.literal(String.format("%,d", number)));
		} else {
			cir.setReturnValue(Component.literal(EmcAbbrev.format(number)));
		}
	}
}
