package dev.latvian.mods.projectex.item.armor;

import moze_intel.projecte.gameObjs.items.armor.PEArmor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.crafting.Ingredient;
import org.jetbrains.annotations.NotNull;

public class GreenArmor extends PEArmor {
	public GreenArmor(ArmorItem.Type type, Item.Properties props) { super(GreenArmorMaterial.INSTANCE, type, props); }

	@Override public float getFullSetBaseReduction() { return 0.997F; }

	@Override
	public float getMaxDamageAbsorb(ArmorItem.Type type, DamageSource source) {
		if (source.is(DamageTypeTags.IS_FIRE)) return 1600.0F;
		if (type == ArmorItem.Type.BOOTS && source.is(DamageTypeTags.IS_FALL)) return 36.0F / getPieceEffectiveness(type);
		if (type == ArmorItem.Type.HELMET && source.is(DamageTypeTags.DAMAGES_HELMET)) return 36.0F / getPieceEffectiveness(type);
		if (source.is(DamageTypeTags.BYPASSES_ARMOR)) return 0.0F;
		if (type == ArmorItem.Type.HELMET || type == ArmorItem.Type.BOOTS) return 800.0F;
		return 1100.0F;
	}

	private static class GreenArmorMaterial implements ArmorMaterial {
		private static final GreenArmorMaterial INSTANCE = new GreenArmorMaterial();
		private static final String NAME = new ResourceLocation("projectex", "green_matter").toString();
		public int getDurabilityForType(@NotNull ArmorItem.Type type) { return 0; }
		public int getDefenseForType(@NotNull ArmorItem.Type type) { return switch (type) { case BOOTS, HELMET -> 3; case LEGGINGS -> 6; case CHESTPLATE -> 8; }; }
		public int getEnchantmentValue() { return 0; }
		@NotNull public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_DIAMOND; }
		@NotNull public Ingredient getRepairIngredient() { return Ingredient.EMPTY; }
		@NotNull public String getName() { return NAME; }
		public float getToughness() { return 6.0F; }
		public float getKnockbackResistance() { return 0.60F; }
	}
}
