package dev.latvian.mods.projectex.block;

import dev.latvian.mods.projectex.Matter;
import dev.latvian.mods.projectex.ProjectEX;
import net.minecraft.Util;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.Map;

public interface ProjectEXBlocks {
	DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ProjectEX.MOD_ID);

	RegistryObject<Block> ENERGY_LINK = REGISTRY.register("energy_link", EnergyLinkBlock::new);
	RegistryObject<Block> PERSONAL_LINK = REGISTRY.register("personal_link", PersonalLinkBlock::new);
	RegistryObject<Block> REFINED_LINK = REGISTRY.register("refined_link", RefinedLinkBlock::new);
	RegistryObject<Block> COMPRESSED_REFINED_LINK = REGISTRY.register("compressed_refined_link", CompressedRefinedLinkBlock::new);
	RegistryObject<Block> STONE_TABLE = REGISTRY.register("stone_table", StoneTableBlock::new);

	Map<Matter, RegistryObject<Block>> COLLECTOR = Util.make(new LinkedHashMap<>(), map -> {
		for (Matter matter : Matter.VALUES) {
			map.put(matter, REGISTRY.register(matter.name + "_collector", () -> new CollectorBlock(matter)));
		}
	});

	Map<Matter, RegistryObject<Block>> RELAY = Util.make(new LinkedHashMap<>(), map -> {
		for (Matter matter : Matter.VALUES) {
			map.put(matter, REGISTRY.register(matter.name + "_relay", () -> new RelayBlock(matter)));
		}
	});

	Map<Matter, RegistryObject<Block>> POWER_FLOWER = Util.make(new LinkedHashMap<>(), map -> {
		for (Matter matter : Matter.VALUES) {
			map.put(matter, REGISTRY.register(matter.name + "_power_flower", () -> new PowerFlowerBlock(matter)));
		}
	});
}
