package dev.latvian.mods.projectex.client;

import dev.latvian.mods.projectex.ProjectEX;
import dev.latvian.mods.projectex.item.armor.PinkGemArmorBase;
import dev.latvian.mods.projectex.item.armor.PinkGemBoots;
import dev.latvian.mods.projectex.item.armor.PinkGemChestplate;
import dev.latvian.mods.projectex.item.armor.PinkGemHelmet;
import dev.latvian.mods.projectex.item.armor.PurpleGemArmorBase;
import dev.latvian.mods.projectex.item.armor.PurpleGemBoots;
import dev.latvian.mods.projectex.item.armor.PurpleGemChestplate;
import dev.latvian.mods.projectex.item.armor.PurpleGemHelmet;
import dev.latvian.mods.projectex.item.armor.BlueGemArmorBase;
import dev.latvian.mods.projectex.item.armor.BlueGemBoots;
import dev.latvian.mods.projectex.item.armor.BlueGemChestplate;
import dev.latvian.mods.projectex.item.armor.BlueGemHelmet;
import dev.latvian.mods.projectex.item.armor.CyanGemArmorBase;
import dev.latvian.mods.projectex.item.armor.CyanGemBoots;
import dev.latvian.mods.projectex.item.armor.CyanGemChestplate;
import dev.latvian.mods.projectex.item.armor.CyanGemHelmet;
import dev.latvian.mods.projectex.item.armor.GreenGemArmorBase;
import dev.latvian.mods.projectex.item.armor.GreenGemBoots;
import dev.latvian.mods.projectex.item.armor.GreenGemChestplate;
import dev.latvian.mods.projectex.item.armor.GreenGemHelmet;
import dev.latvian.mods.projectex.item.armor.LimeGemArmorBase;
import dev.latvian.mods.projectex.item.armor.LimeGemBoots;
import dev.latvian.mods.projectex.item.armor.LimeGemChestplate;
import dev.latvian.mods.projectex.item.armor.LimeGemHelmet;
import dev.latvian.mods.projectex.item.armor.YellowGemArmorBase;
import dev.latvian.mods.projectex.item.armor.YellowGemBoots;
import dev.latvian.mods.projectex.item.armor.YellowGemChestplate;
import dev.latvian.mods.projectex.item.armor.YellowGemHelmet;
import dev.latvian.mods.projectex.item.armor.OrangeGemArmorBase;
import dev.latvian.mods.projectex.item.armor.OrangeGemBoots;
import dev.latvian.mods.projectex.item.armor.OrangeGemChestplate;
import dev.latvian.mods.projectex.item.armor.OrangeGemHelmet;
import dev.latvian.mods.projectex.item.armor.WhiteGemArmorBase;
import dev.latvian.mods.projectex.item.armor.WhiteGemBoots;
import dev.latvian.mods.projectex.item.armor.WhiteGemChestplate;
import dev.latvian.mods.projectex.item.armor.WhiteGemHelmet;
import dev.latvian.mods.projectex.item.armor.FadingArmorBase;
import dev.latvian.mods.projectex.item.armor.FadingBoots;
import dev.latvian.mods.projectex.item.armor.FadingChestplate;
import dev.latvian.mods.projectex.item.armor.FadingHelmet;
import dev.latvian.mods.projectex.net.MagentaArmorTogglePacket;
import dev.latvian.mods.projectex.net.MagentaGemAbilityPacket;
import dev.latvian.mods.projectex.net.ProjectEXNet;
import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.capabilities.PECapabilities;
import moze_intel.projecte.gameObjs.items.armor.GemArmorBase;
import moze_intel.projecte.gameObjs.items.armor.GemFeet;
import moze_intel.projecte.gameObjs.items.armor.GemHelmet;
import moze_intel.projecte.utils.TransmutationEMCFormatter;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.Item;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.network.chat.contents.TranslatableContents;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.ComputeFovModifierEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.lang.reflect.Field;
import java.util.Map;

import java.math.BigInteger;

public final class ProjectEXClient {
	private static final BigInteger TICKS_PER_SEC = BigInteger.valueOf(20L);
	private static final int SAMPLE_WINDOW_TICKS = 20;

	private static BigInteger displayedEmc = BigInteger.ZERO;
	private static BigInteger emcPerSec = BigInteger.ZERO;
	private static BigInteger lastSampleEmc = BigInteger.ZERO;
	private static long lastSampleTime = -1L;
	private static boolean hasData = false;

	// Self-destruct cooldown HUD state. Set when the player presses Z while wearing any gem chestplate.
	// Both startTick and durationTicks come from the chest worn at trigger time so the bar exactly
	// mirrors the server-side per-tier cooldown.
	private static final long SELF_DESTRUCT_BAR_FADE_TICKS = 8L;
	private static long selfDestructCooldownStartTick = -1L;
	private static long selfDestructCooldownDurationTicks = 40L;
	// Same shape for the lightning zap.
	private static long lightningCooldownStartTick = -1L;
	private static long lightningCooldownDurationTicks = 40L;

	private ProjectEXClient() {
	}

	// Two dedicated keybinds registered under ProjectE's controls category so they live
	// next to ProjectE's own keybinds. Default keys: B for katar, Z for self-destruct.
	// The category translation key matches PELang.PROJECTE — "misc.projecte.mod_name".
	private static final String PE_CATEGORY = "misc.projecte.mod_name";
	public static final KeyMapping KATAR_KEY = new KeyMapping(
			"key.projectex.katar_ability", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM,
			InputConstants.KEY_B, PE_CATEGORY);
	public static final KeyMapping SELF_DESTRUCT_KEY = new KeyMapping(
			"key.projectex.self_destruct", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM,
			InputConstants.KEY_Z, PE_CATEGORY);

	@Mod.EventBusSubscriber(modid = ProjectEX.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
	public static final class ModBus {
		@SubscribeEvent
		public static void onRegisterOverlays(RegisterGuiOverlaysEvent event) {
			event.registerAboveAll("emc_overlay", ProjectEXClient::renderOverlay);
			event.registerAboveAll("self_destruct_cooldown", ProjectEXClient::renderSelfDestructBar);
			event.registerAboveAll("lightning_cooldown", ProjectEXClient::renderLightningBar);
		}

		@SubscribeEvent
		public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
			event.register(KATAR_KEY);
			event.register(SELF_DESTRUCT_KEY);
		}

		@SubscribeEvent
		public static void onAddLayers(net.minecraftforge.client.event.EntityRenderersEvent.AddLayers event) {
			for (String skin : event.getSkins()) {
				net.minecraft.client.renderer.entity.player.PlayerRenderer pr = event.getSkin(skin);
				if (pr != null) {
					pr.addLayer(new dev.latvian.mods.projectex.client.render.HaloLayer(pr));
				}
			}
		}

		@SubscribeEvent
		public static void onClientStartup(net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent event) {
			event.enqueueWork(() -> {
				removeKeyMappingByName("key.projecte.extra_function");
				// Rewrite PE's keybind translation keys to ones in our namespace so our lang entries
				// always win the merge (no cross-mod resource pack ordering ambiguity).
				renameKeyMapping("key.projecte.helmet_toggle", "key.projectex.renamed.night_vision");
				renameKeyMapping("key.projecte.boots_toggle", "key.projectex.renamed.step_assist");
				renameKeyMapping("key.projecte.fire_projectile", "key.projectex.renamed.lightning_strike");
			});
		}

		private static void renameKeyMapping(String oldKey, String newKey) {
			org.slf4j.Logger log = com.mojang.logging.LogUtils.getLogger();
			try {
				net.minecraft.client.Options options = Minecraft.getInstance().options;
				for (java.lang.reflect.Field f : net.minecraft.client.Options.class.getDeclaredFields()) {
					if (!KeyMapping[].class.equals(f.getType())) continue;
					f.setAccessible(true);
					KeyMapping[] arr = (KeyMapping[]) f.get(options);
					if (arr == null) continue;
					for (KeyMapping km : arr) {
						if (!oldKey.equals(km.getName())) continue;
						// Found it — flip the `name` field directly.
						for (java.lang.reflect.Field nf : KeyMapping.class.getDeclaredFields()) {
							if (!String.class.equals(nf.getType())) continue;
							nf.setAccessible(true);
							if (oldKey.equals(nf.get(km))) {
								nf.set(km, newKey);
								log.info("[ProjectEX] Renamed keymapping {} -> {}", oldKey, newKey);
								return;
							}
						}
					}
				}
				log.warn("[ProjectEX] No keymapping with name '{}' found to rename", oldKey);
			} catch (Throwable t) {
				log.error("[ProjectEX] Failed to rename keymapping {}", oldKey, t);
			}
		}

		/** Strip a single KeyMapping out of {@code Options.keyMappings} so it doesn't appear in the
		 *  Controls menu. Used to hide ProjectE's Extra Function key since we replaced it with our
		 *  own Katar Ability and Self-Destruct keybinds. */
		private static void removeKeyMappingByName(String name) {
			org.slf4j.Logger log = com.mojang.logging.LogUtils.getLogger();
			log.info("[ProjectEX] Removing keymapping {}", name);
			try {
				net.minecraft.client.Options options = Minecraft.getInstance().options;
				// Try every declared field on Options — the SRG-named runtime field will be one of them.
				for (java.lang.reflect.Field f : net.minecraft.client.Options.class.getDeclaredFields()) {
					if (!KeyMapping[].class.equals(f.getType())) continue;
					f.setAccessible(true);
					KeyMapping[] current = (KeyMapping[]) f.get(options);
					if (current == null) continue;
					log.info("[ProjectEX] field {} has {} keymappings", f.getName(), current.length);
					int found = 0;
					java.util.List<KeyMapping> kept = new java.util.ArrayList<>(current.length);
					for (KeyMapping km : current) {
						if (name.equals(km.getName())) {
							found++;
						} else {
							kept.add(km);
						}
					}
					if (found > 0) {
						log.info("[ProjectEX] Removing {} entries from {}; writing back", found, f.getName());
						f.set(options, kept.toArray(new KeyMapping[0]));
						return;
					}
				}
				log.warn("[ProjectEX] No matching KeyMapping[] field with name '{}' found", name);
			} catch (Throwable t) {
				log.error("[ProjectEX] Failed to remove keymapping", t);
			}
		}

		@SubscribeEvent
		public static void onClientSetup(net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent event) {
			event.enqueueWork(() -> {
				net.minecraft.client.gui.screens.MenuScreens.register(
						dev.latvian.mods.projectex.menu.ProjectEXMenus.STONE_TABLE.get(),
						dev.latvian.mods.projectex.client.screen.StoneTableScreen::new);
				net.minecraft.client.gui.screens.MenuScreens.register(
						dev.latvian.mods.projectex.menu.ProjectEXMenus.ARCANE_TABLET.get(),
						dev.latvian.mods.projectex.client.screen.ArcaneTabletScreen::new);
			});
		}
	}

	@Mod.EventBusSubscriber(modid = ProjectEX.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
	public static final class ForgeBus {
		private static KeyMapping peHelmetToggle;
		private static KeyMapping peBootsToggle;
		private static KeyMapping peFireProjectile;
		private static boolean peKeysResolved = false;
		private static boolean prevHelmetDown = false;
		private static boolean prevBootsDown = false;
		private static boolean prevFireDown = false;
		private static boolean prevKatarDown = false;
		private static boolean prevSelfDestructDown = false;

		private static void resolvePEKeys() {
			if (peKeysResolved) return;
			peKeysResolved = true;
			try {
				Class<?> ckhClass = Class.forName("moze_intel.projecte.utils.ClientKeyHelper");
				Field peToMcField = ckhClass.getDeclaredField("peToMc");
				peToMcField.setAccessible(true);
				Object peToMc = peToMcField.get(null);
				if (!(peToMc instanceof Map<?, ?> map)) return;

				Class<?> peKeybindClass = Class.forName("moze_intel.projecte.utils.PEKeybind");
				peHelmetToggle = (KeyMapping) map.get(peKeybindFor(peKeybindClass, "HELMET_TOGGLE"));
				peBootsToggle = (KeyMapping) map.get(peKeybindFor(peKeybindClass, "BOOTS_TOGGLE"));
				peFireProjectile = (KeyMapping) map.get(peKeybindFor(peKeybindClass, "FIRE_PROJECTILE"));
			} catch (ReflectiveOperationException ignored) {
				// ProjectE's internals shifted or it's missing — no toggles available.
			}
		}

		@SuppressWarnings({"rawtypes", "unchecked"})
		private static Object peKeybindFor(Class<?> peKeybindClass, String name) {
			return Enum.valueOf((Class<? extends Enum>) peKeybindClass, name);
		}

		@SubscribeEvent
		public static void onClientTick(TickEvent.ClientTickEvent event) {
			if (event.phase == TickEvent.Phase.END) {
				updateEmc();
				pollArmorKeys();
				tickGemBootsLiquidWalk();
			}
		}

		// Inject liquid-walking onto ProjectE's Gem (Red Matter Gem) boots, gated by their existing
		// step-assist NBT toggle. Sneak lets the player descend; creative flight bypasses.
		private static void tickGemBootsLiquidWalk() {
			Minecraft mc = Minecraft.getInstance();
			if (mc.player == null || mc.level == null) return;
			Player player = mc.player;
			if (player.isShiftKeyDown() || player.getAbilities().flying) return;

			ItemStack boots = player.getItemBySlot(EquipmentSlot.FEET);
			if (!(boots.getItem() instanceof GemFeet)) return;
			// Match ProjectE's isStepAssistEnabled semantics: enabled when no NBT, no key, or key=true.
			if (boots.hasTag() && boots.getTag().contains("StepAssist") && !boots.getTag().getBoolean("StepAssist")) {
				return;
			}

			Level level = player.level();
			BlockPos feetPos = BlockPos.containing(player.getX(), player.getY() - 0.05, player.getZ());
			BlockState belowState = level.getBlockState(feetPos);
			FluidState fluid = belowState.getFluidState();
			if (fluid.isEmpty()) return;

			double surfaceY = feetPos.getY() + fluid.getHeight(level, feetPos);
			if (player.getY() < surfaceY) {
				player.setPos(player.getX(), surfaceY, player.getZ());
			}
			if (player.getDeltaMovement().y < 0.0) {
				player.setDeltaMovement(player.getDeltaMovement().x, 0.0, player.getDeltaMovement().z);
			}
			player.setOnGround(true);
			player.fallDistance = 0.0F;
		}

		private static void pollArmorKeys() {
			Minecraft mc = Minecraft.getInstance();
			if (mc.player == null || mc.screen != null) return;
			resolvePEKeys();

			if (peHelmetToggle != null) {
				boolean down = peHelmetToggle.isDown();
				if (down && !prevHelmetDown) {
					ItemStack helm = mc.player.getItemBySlot(EquipmentSlot.HEAD);
					Item item = helm.getItem();
					if (item instanceof PinkGemHelmet || item instanceof PurpleGemHelmet || item instanceof BlueGemHelmet || item instanceof CyanGemHelmet || item instanceof GreenGemHelmet || item instanceof LimeGemHelmet || item instanceof YellowGemHelmet || item instanceof OrangeGemHelmet || item instanceof WhiteGemHelmet || item instanceof FadingHelmet) {
						ProjectEXNet.sendToServer(new MagentaArmorTogglePacket(MagentaArmorTogglePacket.KIND_HELMET));
					} else if (item instanceof GemHelmet) {
						// ProjectE handles the toggle server-side; we mirror the new state in the action bar.
						showActionBar(mc.player, "Night Vision", predictNbtToggle(helm, "NightVision", false));
					}
				}
				prevHelmetDown = down;
			}

			if (peBootsToggle != null) {
				boolean down = peBootsToggle.isDown();
				if (down && !prevBootsDown) {
					ItemStack boots = mc.player.getItemBySlot(EquipmentSlot.FEET);
					Item item = boots.getItem();
					if (item instanceof PinkGemBoots || item instanceof PurpleGemBoots || item instanceof BlueGemBoots || item instanceof CyanGemBoots || item instanceof GreenGemBoots || item instanceof LimeGemBoots || item instanceof YellowGemBoots || item instanceof OrangeGemBoots || item instanceof WhiteGemBoots || item instanceof FadingBoots) {
						ProjectEXNet.sendToServer(new MagentaArmorTogglePacket(MagentaArmorTogglePacket.KIND_BOOTS));
					} else if (item instanceof GemFeet) {
						showActionBar(mc.player, "Step Assist", predictNbtToggle(boots, "StepAssist", false));
					}
				}
				prevBootsDown = down;
			}

			// FIRE_PROJECTILE — lightning zap for ANY recognised gem helmet (PE's or ours), no gem-mode
			// arming required. Auto-repeats while held using the per-tier cooldown (same shape as self-destruct).
			if (peFireProjectile != null) {
				boolean down = peFireProjectile.isDown();
				if (down) {
					Item h = mc.player.getItemBySlot(EquipmentSlot.HEAD).getItem();
					long ticks = dev.latvian.mods.projectex.util.LightningCooldown.ticksFor(h);
					if (ticks > 0L && mc.level != null) {
						long now = mc.level.getGameTime();
						boolean ready = lightningCooldownStartTick < 0L
								|| now - lightningCooldownStartTick >= lightningCooldownDurationTicks;
						if (ready) {
							ProjectEXNet.sendToServer(new MagentaGemAbilityPacket(MagentaGemAbilityPacket.KIND_ZAP));
							lightningCooldownStartTick = now;
							lightningCooldownDurationTicks = ticks;
						}
					}
				}
				prevFireDown = down;
			}

			// Dedicated Katar Ability key — sends to server which invokes the held item's
			// EXTRA_FUNCTION_ITEM_CAPABILITY (Red Matter Katar's swing).
			{
				boolean down = KATAR_KEY.isDown();
				if (down && !prevKatarDown) {
					ProjectEXNet.sendToServer(new MagentaGemAbilityPacket(MagentaGemAbilityPacket.KIND_KATAR));
				}
				prevKatarDown = down;
			}

			// Dedicated Self-Destruct key — fires the chest nova regardless of gem-mode arm state.
			// Auto-repeats while held: every time the per-tier cooldown elapses, fire again.
			{
				boolean down = SELF_DESTRUCT_KEY.isDown();
				if (down) {
					Minecraft mcInst = Minecraft.getInstance();
					if (mcInst.player != null && mcInst.level != null) {
						Item chestItem = mcInst.player.getItemBySlot(EquipmentSlot.CHEST).getItem();
						long ticks = dev.latvian.mods.projectex.util.SelfDestructCooldown.ticksFor(chestItem);
						if (ticks > 0L) {
							long now = mcInst.level.getGameTime();
							boolean ready = selfDestructCooldownStartTick < 0L
									|| now - selfDestructCooldownStartTick >= selfDestructCooldownDurationTicks;
							if (ready) {
								ProjectEXNet.sendToServer(new MagentaGemAbilityPacket(MagentaGemAbilityPacket.KIND_SELF_DESTRUCT));
								selfDestructCooldownStartTick = now;
								selfDestructCooldownDurationTicks = ticks;
							}
						}
					}
				}
				prevSelfDestructDown = down;
			}
		}

		// Mirrors ProjectE's GemHelmet/GemFeet toggle math: if the tag exists, flip; otherwise the first press sets it true.
		private static boolean predictNbtToggle(ItemStack stack, String key, boolean defaultIfMissing) {
			if (!stack.hasTag()) return true;
			CompoundTag tag = stack.getTag();
			if (!tag.contains(key)) return true;
			return !tag.getBoolean(key);
		}

		private static void showActionBar(Player player, String label, boolean enabled) {
			ChatFormatting color = enabled ? ChatFormatting.GREEN : ChatFormatting.RED;
			String state = enabled ? "ON" : "OFF";
			player.displayClientMessage(
					Component.literal(label + ": ").append(Component.literal(state).withStyle(color)),
					true
			);
		}

		// Suppress ProjectE's chat-line confirmation ("Night Vision Enabled" etc.) since we already
		// surface the same info in the action bar.
		@SubscribeEvent
		public static void onChat(ClientChatReceivedEvent event) {
			if (event.getMessage().getContents() instanceof TranslatableContents tc) {
				String key = tc.getKey();
				if ("gem.projecte.night_vision".equals(key)
						|| "gem.projecte.step_assist".equals(key)
						|| "gem.projecte.activate".equals(key)
						|| "gem.projecte.deactivate".equals(key)) {
					event.setCanceled(true);
				}
			}
		}

		@SubscribeEvent
		public static void onComputeFov(ComputeFovModifierEvent event) {
			Player player = event.getPlayer();
			Item boots = player.getItemBySlot(EquipmentSlot.FEET).getItem();
			if (boots instanceof PinkGemBoots || boots instanceof PurpleGemBoots || boots instanceof BlueGemBoots || boots instanceof CyanGemBoots || boots instanceof GreenGemBoots || boots instanceof LimeGemBoots || boots instanceof YellowGemBoots || boots instanceof OrangeGemBoots || boots instanceof WhiteGemBoots || boots instanceof FadingBoots) {
				// Replace vanilla's speed-driven FOV math (which would also count the boots' boost).
				// Walking stays at 1.0; sprint produces a visible zoom; flying nudges slightly.
				float f = 1.0F;
				if (player.getAbilities().flying) f *= 1.1F;
				if (player.isSprinting()) f *= 1.40F;
				event.setNewFovModifier(f);
			}
		}
	}

	private static void updateEmc() {
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null || mc.player == null) {
			hasData = false;
			lastSampleTime = -1L;
			lastSampleEmc = BigInteger.ZERO;
			displayedEmc = BigInteger.ZERO;
			emcPerSec = BigInteger.ZERO;
			return;
		}

		IKnowledgeProvider provider = mc.player.getCapability(PECapabilities.KNOWLEDGE_CAPABILITY).orElse(null);
		if (provider == null) {
			hasData = false;
			return;
		}

		displayedEmc = provider.getEmc();
		hasData = true;

		long now = mc.level.getGameTime();
		if (lastSampleTime < 0L) {
			lastSampleEmc = displayedEmc;
			lastSampleTime = now;
		} else if (now - lastSampleTime >= SAMPLE_WINDOW_TICKS) {
			long ticks = now - lastSampleTime;
			BigInteger delta = displayedEmc.subtract(lastSampleEmc);
			emcPerSec = delta.multiply(TICKS_PER_SEC).divide(BigInteger.valueOf(ticks));
			lastSampleEmc = displayedEmc;
			lastSampleTime = now;
		}
	}

	private static void renderOverlay(ForgeGui gui, GuiGraphics graphics, float partialTick, int screenWidth, int screenHeight) {
		if (!hasData) {
			return;
		}
		if (displayedEmc.signum() == 0 && emcPerSec.signum() == 0) {
			return;
		}

		Minecraft mc = Minecraft.getInstance();
		if (mc.options.hideGui) {
			return;
		}

		Font font = mc.font;
		int x = 2;
		int y = 2;
		boolean full = Screen.hasShiftDown();

		Component emcLine = Component.literal("EMC: ").append(formatEmc(displayedEmc, full));
		graphics.drawString(font, emcLine, x, y, 0xFFFFFFFF);

		if (emcPerSec.signum() != 0) {
			y += 10;
			int color = emcPerSec.signum() > 0 ? 0xFF55FF55 : 0xFFFF5555;
			String prefix = emcPerSec.signum() > 0 ? "+" : "";
			Component rateLine = Component.literal(prefix).append(formatEmc(emcPerSec, full)).append("/s");
			graphics.drawString(font, rateLine, x, y, color);
		}
	}

	private static Component formatEmc(BigInteger emc, boolean full) {
		if (full) {
			return Component.literal(String.format("%,d", emc));
		}
		return TransmutationEMCFormatter.formatEMC(emc);
	}

	private static void renderSelfDestructBar(ForgeGui gui, GuiGraphics graphics, float partialTick, int screenWidth, int screenHeight) {
		if (selfDestructCooldownStartTick < 0L) return;
		Minecraft mc = Minecraft.getInstance();
		if (mc.options.hideGui || mc.level == null || mc.player == null) return;

		float now = mc.level.getGameTime() + partialTick;
		float elapsed = now - selfDestructCooldownStartTick;
		float total = selfDestructCooldownDurationTicks;

		float alpha;
		float fillFrac;
		if (elapsed < total) {
			alpha = 1.0F;
			fillFrac = 1.0F - (elapsed / total);
		} else if (elapsed < total + SELF_DESTRUCT_BAR_FADE_TICKS) {
			// Ready flash + fade out
			alpha = 1.0F - ((elapsed - total) / SELF_DESTRUCT_BAR_FADE_TICKS);
			fillFrac = 0.0F;
		} else {
			selfDestructCooldownStartTick = -1L;
			return;
		}

		int barWidth = 80;
		int barHeight = 3;
		int x = (screenWidth - barWidth) / 2;
		// Hotbar top edge sits at screenHeight - 22; place the bar 5px above it so it clears the
		// XP bar (screenHeight - 30..-26 region) when XP is showing, and clears the hotbar otherwise.
		int y = screenHeight - 50;

		int a = Math.max(0, Math.min(255, (int) (alpha * 255)));
		int bgColor = (a << 24) | 0x000000;
		int outlineColor = (a << 24) | 0x202020;
		int fillColor;
		if (fillFrac > 0F) {
			// Cooling: red ramping to yellow as it nears ready.
			float t = 1.0F - fillFrac; // 0 at start, 1 at end
			int r = 255;
			int g = (int) (t * 220);
			int b = 0;
			fillColor = (a << 24) | (r << 16) | (g << 8) | b;
		} else {
			// Ready flash: bright green that fades.
			fillColor = (a << 24) | 0x55FF55;
		}

		// outline + bg
		graphics.fill(x - 1, y - 1, x + barWidth + 1, y + barHeight + 1, outlineColor);
		graphics.fill(x, y, x + barWidth, y + barHeight, bgColor);

		// fill
		int fillWidth = fillFrac > 0F ? Math.max(1, (int) (barWidth * fillFrac)) : barWidth;
		int fillX = fillFrac > 0F ? x + (barWidth - fillWidth) / 2 : x;
		graphics.fill(fillX, y, fillX + fillWidth, y + barHeight, fillColor);
	}

	private static void renderLightningBar(ForgeGui gui, GuiGraphics graphics, float partialTick, int screenWidth, int screenHeight) {
		if (lightningCooldownStartTick < 0L) return;
		Minecraft mc = Minecraft.getInstance();
		if (mc.options.hideGui || mc.level == null || mc.player == null) return;

		float now = mc.level.getGameTime() + partialTick;
		float elapsed = now - lightningCooldownStartTick;
		float total = lightningCooldownDurationTicks;

		float alpha;
		float fillFrac;
		if (elapsed < total) {
			alpha = 1.0F;
			fillFrac = 1.0F - (elapsed / total);
		} else if (elapsed < total + SELF_DESTRUCT_BAR_FADE_TICKS) {
			alpha = 1.0F - ((elapsed - total) / SELF_DESTRUCT_BAR_FADE_TICKS);
			fillFrac = 0.0F;
		} else {
			lightningCooldownStartTick = -1L;
			return;
		}

		int barWidth = 80;
		int barHeight = 3;
		int x = (screenWidth - barWidth) / 2;
		// Stack just above the self-destruct bar (which sits at -50). 6px gap = 3px bar + 3px outline/gap.
		int y = screenHeight - 56;

		int a = Math.max(0, Math.min(255, (int) (alpha * 255)));
		int bgColor = (a << 24) | 0x000000;
		int outlineColor = (a << 24) | 0x202020;
		int fillColor;
		if (fillFrac > 0F) {
			// Cooling: deep blue → bright cyan as it nears ready.
			float t = 1.0F - fillFrac;
			int r = (int) (t * 80);
			int g = (int) (120 + t * 135);
			int b = 255;
			fillColor = (a << 24) | (r << 16) | (g << 8) | b;
		} else {
			// Ready flash: bright white that fades.
			fillColor = (a << 24) | 0xFFFFFF;
		}

		graphics.fill(x - 1, y - 1, x + barWidth + 1, y + barHeight + 1, outlineColor);
		graphics.fill(x, y, x + barWidth, y + barHeight, bgColor);

		int fillWidth = fillFrac > 0F ? Math.max(1, (int) (barWidth * fillFrac)) : barWidth;
		int fillX = fillFrac > 0F ? x + (barWidth - fillWidth) / 2 : x;
		graphics.fill(fillX, y, fillX + fillWidth, y + barHeight, fillColor);
	}
}
