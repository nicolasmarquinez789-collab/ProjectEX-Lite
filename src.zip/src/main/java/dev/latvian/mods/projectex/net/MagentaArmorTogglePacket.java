package dev.latvian.mods.projectex.net;

import dev.latvian.mods.projectex.item.armor.PinkGemBoots;
import dev.latvian.mods.projectex.item.armor.PinkGemHelmet;
import dev.latvian.mods.projectex.item.armor.PurpleGemBoots;
import dev.latvian.mods.projectex.item.armor.PurpleGemHelmet;
import dev.latvian.mods.projectex.item.armor.BlueGemBoots;
import dev.latvian.mods.projectex.item.armor.BlueGemHelmet;
import dev.latvian.mods.projectex.item.armor.CyanGemBoots;
import dev.latvian.mods.projectex.item.armor.CyanGemHelmet;
import dev.latvian.mods.projectex.item.armor.GreenGemBoots;
import dev.latvian.mods.projectex.item.armor.GreenGemHelmet;
import dev.latvian.mods.projectex.item.armor.LimeGemBoots;
import dev.latvian.mods.projectex.item.armor.LimeGemHelmet;
import dev.latvian.mods.projectex.item.armor.YellowGemBoots;
import dev.latvian.mods.projectex.item.armor.YellowGemHelmet;
import dev.latvian.mods.projectex.item.armor.OrangeGemBoots;
import dev.latvian.mods.projectex.item.armor.OrangeGemHelmet;
import dev.latvian.mods.projectex.item.armor.WhiteGemBoots;
import dev.latvian.mods.projectex.item.armor.WhiteGemHelmet;
import dev.latvian.mods.projectex.item.armor.FadingBoots;
import dev.latvian.mods.projectex.item.armor.FadingHelmet;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public record MagentaArmorTogglePacket(int kind) {
	public static final int KIND_HELMET = 0;
	public static final int KIND_BOOTS = 1;

	public static void encode(MagentaArmorTogglePacket pkt, FriendlyByteBuf buf) {
		buf.writeVarInt(pkt.kind);
	}

	public static MagentaArmorTogglePacket decode(FriendlyByteBuf buf) {
		return new MagentaArmorTogglePacket(buf.readVarInt());
	}

	public static void handle(MagentaArmorTogglePacket pkt, Supplier<NetworkEvent.Context> ctxSup) {
		NetworkEvent.Context ctx = ctxSup.get();
		ctx.enqueueWork(() -> {
			ServerPlayer sp = ctx.getSender();
			if (sp == null) return;
			if (pkt.kind == KIND_HELMET) {
				ItemStack helm = sp.getItemBySlot(EquipmentSlot.HEAD);
				if (helm.getItem() instanceof PinkGemHelmet) {
					PinkGemHelmet.toggleNightVision(helm, sp);
				} else if (helm.getItem() instanceof PurpleGemHelmet) {
					PurpleGemHelmet.toggleNightVision(helm, sp);
				} else if (helm.getItem() instanceof BlueGemHelmet) {
					BlueGemHelmet.toggleNightVision(helm, sp);
				} else if (helm.getItem() instanceof CyanGemHelmet) {
					CyanGemHelmet.toggleNightVision(helm, sp);
				} else if (helm.getItem() instanceof GreenGemHelmet) {
					GreenGemHelmet.toggleNightVision(helm, sp);
				} else if (helm.getItem() instanceof LimeGemHelmet) {
					LimeGemHelmet.toggleNightVision(helm, sp);
				} else if (helm.getItem() instanceof YellowGemHelmet) {
					YellowGemHelmet.toggleNightVision(helm, sp);
				} else if (helm.getItem() instanceof OrangeGemHelmet) {
					OrangeGemHelmet.toggleNightVision(helm, sp);
				} else if (helm.getItem() instanceof WhiteGemHelmet) {
					WhiteGemHelmet.toggleNightVision(helm, sp);
				} else if (helm.getItem() instanceof FadingHelmet) {
					FadingHelmet.toggleNightVision(helm, sp);
				}
			} else if (pkt.kind == KIND_BOOTS) {
				ItemStack boots = sp.getItemBySlot(EquipmentSlot.FEET);
				if (boots.getItem() instanceof PinkGemBoots) {
					PinkGemBoots.toggleStepAssist(boots, sp);
				} else if (boots.getItem() instanceof PurpleGemBoots) {
					PurpleGemBoots.toggleStepAssist(boots, sp);
				} else if (boots.getItem() instanceof BlueGemBoots) {
					BlueGemBoots.toggleStepAssist(boots, sp);
				} else if (boots.getItem() instanceof CyanGemBoots) {
					CyanGemBoots.toggleStepAssist(boots, sp);
				} else if (boots.getItem() instanceof GreenGemBoots) {
					GreenGemBoots.toggleStepAssist(boots, sp);
				} else if (boots.getItem() instanceof LimeGemBoots) {
					LimeGemBoots.toggleStepAssist(boots, sp);
				} else if (boots.getItem() instanceof YellowGemBoots) {
					YellowGemBoots.toggleStepAssist(boots, sp);
				} else if (boots.getItem() instanceof OrangeGemBoots) {
					OrangeGemBoots.toggleStepAssist(boots, sp);
				} else if (boots.getItem() instanceof WhiteGemBoots) {
					WhiteGemBoots.toggleStepAssist(boots, sp);
				} else if (boots.getItem() instanceof FadingBoots) {
					FadingBoots.toggleStepAssist(boots, sp);
				}
			}
		});
		ctx.setPacketHandled(true);
	}
}
