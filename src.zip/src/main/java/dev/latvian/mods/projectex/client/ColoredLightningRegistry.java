package dev.latvian.mods.projectex.client;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

// Client-side map of bolt UUID → ARGB color, populated by ColoredLightningPacket.
// LightningBoltRendererMixin reads from here to tint the bolt.
// Bounded so it can't grow unbounded if the player never sees the bolt expire.
public final class ColoredLightningRegistry {
	private static final int MAX_ENTRIES = 64;
	private static final ConcurrentHashMap<UUID, Integer> COLORS = new ConcurrentHashMap<>();

	private ColoredLightningRegistry() {}

	public static void set(UUID uuid, int color) {
		if (COLORS.size() >= MAX_ENTRIES) COLORS.clear();
		COLORS.put(uuid, color);
	}

	public static int get(UUID uuid) {
		Integer c = COLORS.get(uuid);
		return c == null ? 0 : c;
	}
}
