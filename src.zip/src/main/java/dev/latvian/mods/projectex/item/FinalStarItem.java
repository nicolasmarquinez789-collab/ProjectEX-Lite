package dev.latvian.mods.projectex.item;

import dev.latvian.mods.projectex.ProjectEX;
import moze_intel.projecte.api.block_entity.IDMPedestal;
import moze_intel.projecte.api.capabilities.PECapabilities;
import moze_intel.projecte.api.capabilities.item.IPedestalItem;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemHandlerHelper;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class FinalStarItem extends Item implements IPedestalItem {
	private static final int UPDATE_INTERVAL = 20;

	public FinalStarItem() {
		super(new Properties().rarity(Rarity.EPIC).stacksTo(1));
	}

	@Override
	public <PEDESTAL extends BlockEntity & IDMPedestal> boolean updateInPedestal(@NotNull ItemStack stack, @NotNull Level level, @NotNull BlockPos pos, @NotNull PEDESTAL pedestal) {
		if (level.isClientSide()) {
			return false;
		}
		if (level.getGameTime() % UPDATE_INTERVAL != Math.floorMod(pos.hashCode(), UPDATE_INTERVAL)) {
			return false;
		}

		AABB aabb = new AABB(pos).inflate(0.5D, 1.0D, 0.5D);
		List<ItemEntity> entities = level.getEntitiesOfClass(ItemEntity.class, aabb);
		if (entities.isEmpty()) {
			return false;
		}

		boolean acted = false;
		for (Direction dir : ProjectEX.DIRECTIONS) {
			BlockEntity be = level.getBlockEntity(pos.relative(dir));
			if (be == null) {
				continue;
			}
			IItemHandler handler = be.getCapability(ForgeCapabilities.ITEM_HANDLER, dir.getOpposite()).orElse(null);
			if (handler == null) {
				continue;
			}

			ItemStack source = entities.get(level.random.nextInt(entities.size())).getItem();
			if (source.isEmpty()) {
				continue;
			}

			ItemStack copy = source.copy();
			copy.setCount(copy.getMaxStackSize());
			if (copy.isDamageableItem()) {
				copy.setDamageValue(0);
			}
			copy.setTag(null);

			ItemHandlerHelper.insertItemStacked(handler, copy, false);
			acted = true;
		}
		return acted;
	}

	@Override
	@NotNull
	public List<Component> getPedestalDescription() {
		return List.of(Component.translatable("item.projectex.final_star.tooltip").withStyle(ChatFormatting.GRAY));
	}

	@Nullable
	@Override
	public ICapabilityProvider initCapabilities(ItemStack stack, @Nullable CompoundTag nbt) {
		return new PedestalCapProvider(this);
	}

	private static final class PedestalCapProvider implements ICapabilityProvider {
		private final LazyOptional<IPedestalItem> opt;

		PedestalCapProvider(IPedestalItem item) {
			this.opt = LazyOptional.of(() -> item);
		}

		@NotNull
		@Override
		public <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
			return cap == PECapabilities.PEDESTAL_ITEM_CAPABILITY ? opt.cast() : LazyOptional.empty();
		}
	}
}
