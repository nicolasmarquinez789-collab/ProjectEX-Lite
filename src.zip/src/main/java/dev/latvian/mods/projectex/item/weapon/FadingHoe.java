package dev.latvian.mods.projectex.item.weapon;
import com.google.common.collect.Multimap;
import dev.latvian.mods.projectex.util.TierDamage;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.item.ItemStack;
import moze_intel.projecte.gameObjs.EnumMatterType;
import moze_intel.projecte.gameObjs.items.tools.PEHoe;
import net.minecraft.world.item.Item;
// Fading tier — slightly stronger than others via numCharges=4 instead of 3.
public class FadingHoe extends PEHoe {
	public FadingHoe(Item.Properties props) { super(EnumMatterType.RED_MATTER, 4, props); }

	@Override
	public Multimap<Attribute, AttributeModifier> getAttributeModifiers(EquipmentSlot slot, ItemStack stack) {
		return TierDamage.boost(super.getAttributeModifiers(slot, stack), slot, 15.0F);
	}
}
