package dev.latvian.mods.projectex.util;

import dev.latvian.mods.projectex.item.armor.BlueGemChestplate;
import dev.latvian.mods.projectex.item.armor.CyanGemChestplate;
import dev.latvian.mods.projectex.item.armor.FadingChestplate;
import dev.latvian.mods.projectex.item.armor.GreenGemChestplate;
import dev.latvian.mods.projectex.item.armor.LimeGemChestplate;
import dev.latvian.mods.projectex.item.armor.OrangeGemChestplate;
import dev.latvian.mods.projectex.item.armor.PinkGemChestplate;
import dev.latvian.mods.projectex.item.armor.PurpleGemChestplate;
import dev.latvian.mods.projectex.item.armor.WhiteGemChestplate;
import dev.latvian.mods.projectex.item.armor.YellowGemChestplate;
import moze_intel.projecte.gameObjs.items.armor.GemChest;
import net.minecraft.world.item.Item;

// Per-tier self-destruct cooldown in ticks. Cooldown shrinks as tiers increase: bigger nova, faster
// firing rate — fully a power-fantasy ramp. Returns 0 for a non-gem-chest item.
public final class SelfDestructCooldown {
	private SelfDestructCooldown() {}

	public static long ticksFor(Item chest) {
		if (chest instanceof FadingChestplate)        return 4L;   // 0.20s
		if (chest instanceof WhiteGemChestplate)      return 10L;  // 0.50s
		if (chest instanceof OrangeGemChestplate)     return 13L;  // 0.65s
		if (chest instanceof YellowGemChestplate)     return 17L;  // 0.85s
		if (chest instanceof LimeGemChestplate)       return 20L;  // 1.00s
		if (chest instanceof GreenGemChestplate)      return 23L;  // 1.15s
		if (chest instanceof CyanGemChestplate)       return 27L;  // 1.35s
		if (chest instanceof BlueGemChestplate)       return 30L;  // 1.50s
		if (chest instanceof PurpleGemChestplate)     return 33L;  // 1.65s
		if (chest instanceof PinkGemChestplate)       return 37L;  // 1.85s
		if (chest instanceof GemChest)                return 40L;  // 2.00s (Red Matter / PE base)
		return 0L;
	}
}
