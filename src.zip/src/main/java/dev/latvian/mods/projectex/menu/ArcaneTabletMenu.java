package dev.latvian.mods.projectex.menu;

import moze_intel.projecte.api.ItemInfo;
import moze_intel.projecte.api.ProjectEAPI;
import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.capabilities.PECapabilities;
import moze_intel.projecte.api.capabilities.block_entity.IEmcStorage;
import moze_intel.projecte.api.capabilities.item.IItemEmcHolder;
import moze_intel.projecte.api.proxy.IEMCProxy;
import net.minecraft.core.NonNullList;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.inventory.ResultContainer;
import net.minecraft.world.inventory.ResultSlot;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.TransientCraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraftforge.items.ItemHandlerHelper;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ArcaneTabletMenu extends AbstractContainerMenu {
	public static final int ACTION_TAKE_ONE = 1;
	public static final int ACTION_TAKE_STACK = 2;
	public static final int ACTION_TAKE_STACK_TO_INV = 6;
	public static final int ACTION_BURN = 5;
	public static final int ACTION_BURN_ALL = 7;
	public static final int ACTION_CLEAR_MATRIX = 40;
	public static final int ACTION_ROTATE_CW = 41;
	public static final int ACTION_ROTATE_CCW = 42;
	public static final int ACTION_BALANCE = 43;
	public static final int ACTION_SPREAD = 44;
	public static final int ACTION_CRAFT_MAX = 45;

	// 8 perimeter slots clockwise: TL, T, TR, R, BR, B, BL, L (center=4 unchanged).
	private static final int[] ROTATION_SLOTS = {0, 1, 2, 5, 8, 7, 6, 3};

	public final Player player;
	public final IKnowledgeProvider provider;
	public final TransientCraftingContainer craftMatrix;
	public final ResultContainer craftResult = new ResultContainer();
	public final SimpleContainer learnInv;
	public final SimpleContainer unlearnInv;

	private ItemStack lastLearnSeen = ItemStack.EMPTY;
	private ItemStack lastUnlearnSeen = ItemStack.EMPTY;
	private long lastResultQuickMoveAt = 0L;

	public ArcaneTabletMenu(int containerId, Inventory playerInv) {
		this(containerId, playerInv, playerInv.player);
	}

	public ArcaneTabletMenu(int containerId, Inventory playerInv, Player player) {
		super(ProjectEXMenus.ARCANE_TABLET.get(), containerId);
		this.player = player;
		this.provider = player.getCapability(PECapabilities.KNOWLEDGE_CAPABILITY).orElseThrow(() -> new IllegalStateException("Player has no knowledge capability"));
		this.craftMatrix = new TransientCraftingContainer(this, 3, 3);

		this.learnInv = new SimpleContainer(1) {
			@Override
			public void setChanged() {
				super.setChanged();
				onLearnSlotChanged();
			}
		};
		this.unlearnInv = new SimpleContainer(1) {
			@Override
			public void setChanged() {
				super.setChanged();
				onUnlearnSlotChanged();
			}
		};

		// slot 0: crafting result with auto-refill from inventory + EMC
		addSlot(new ResultSlot(player, craftMatrix, craftResult, 0, -24, 84) {
			@Override
			public void onTake(Player p, ItemStack stack) {
				ItemStack[] templates = new ItemStack[9];
				for (int i = 0; i < 9; i++) {
					ItemStack s = craftMatrix.getItem(i);
					templates[i] = s.isEmpty() ? ItemStack.EMPTY : s.copy();
					if (!templates[i].isEmpty()) {
						templates[i].setCount(1);
					}
				}
				super.onTake(p, stack);
				if (p instanceof ServerPlayer sp) {
					refillMatrix(sp, templates);
				}
			}
		});

		// slots 1-9: 3x3 crafting matrix (side panel, negative x)
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 3; col++) {
				addSlot(new Slot(craftMatrix, col + row * 3, -60 + col * 18, 26 + row * 18));
			}
		}

		// slot 10: learn (main body, standard pos)
		addSlot(new Slot(learnInv, 0, 8, 115));
		// slot 11: unlearn
		addSlot(new Slot(unlearnInv, 0, 152, 115));

		// slots 12-38: player inventory (main body, standard pos)
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				addSlot(new Slot(playerInv, col + row * 9 + 9, 8 + col * 18, 135 + row * 18));
			}
		}
		for (int col = 0; col < 9; col++) {
			addSlot(new Slot(playerInv, col, 8 + col * 18, 193));
		}
	}

	public static ArcaneTabletMenu fromNetwork(int containerId, Inventory playerInv, FriendlyByteBuf buf) {
		return new ArcaneTabletMenu(containerId, playerInv);
	}

	@Override
	public boolean stillValid(Player player) {
		return true;
	}

	@Override
	public void slotsChanged(Container container) {
		super.slotsChanged(container);
		if (player instanceof ServerPlayer sp) {
			if (container == craftMatrix) {
				updateCraftingResult(sp);
			} else if (container == learnInv) {
				ItemStack now = learnInv.getItem(0);
				if (!ItemStack.matches(now, lastLearnSeen)) {
					lastLearnSeen = now.copy();
					if (!now.isEmpty()) {
						applyLearn(sp, now);
					}
				}
			} else if (container == unlearnInv) {
				ItemStack now = unlearnInv.getItem(0);
				if (!ItemStack.matches(now, lastUnlearnSeen)) {
					lastUnlearnSeen = now.copy();
					if (!now.isEmpty()) {
						applyUnlearn(sp, now);
					}
				}
			}
		}
	}

	private void refillMatrix(ServerPlayer sp, ItemStack[] templates) {
		boolean changed = false;
		for (int i = 0; i < 9; i++) {
			if (templates[i].isEmpty()) continue;
			if (!craftMatrix.getItem(i).isEmpty()) continue;

			ItemStack refill = takeFromPlayerInv(sp.getInventory(), templates[i]);
			if (refill.isEmpty()) {
				refill = takeFromEMC(sp, templates[i]);
			}
			if (!refill.isEmpty()) {
				craftMatrix.setItem(i, refill);
				changed = true;
			}
		}
		if (changed) {
			updateCraftingResult(sp);
		}
	}

	private static ItemStack takeFromPlayerInv(Inventory inv, ItemStack template) {
		for (int i = 0; i < inv.getContainerSize(); i++) {
			ItemStack stack = inv.getItem(i);
			if (stack.isEmpty()) continue;
			if (ItemStack.isSameItemSameTags(stack, template)) {
				ItemStack out = stack.split(1);
				inv.setItem(i, stack);
				return out;
			}
		}
		return ItemStack.EMPTY;
	}

	private ItemStack takeFromEMC(ServerPlayer sp, ItemStack template) {
		IEMCProxy emc = ProjectEAPI.getEMCProxy();
		long cost = emc.getValue(template);
		if (cost <= 0L) return ItemStack.EMPTY;

		ItemInfo info = emc.getPersistentInfo(ItemInfo.fromStack(template));
		if (!provider.hasKnowledge(info)) return ItemStack.EMPTY;

		BigInteger available = provider.getEmc();
		BigInteger costPer = BigInteger.valueOf(cost);
		if (available.compareTo(costPer) < 0) return ItemStack.EMPTY;

		provider.setEmc(available.subtract(costPer));
		provider.syncEmc(sp);

		ItemStack result = template.copy();
		result.setCount(1);
		return result;
	}

	private void updateCraftingResult(ServerPlayer sp) {
		ServerLevel level = sp.serverLevel();
		ItemStack result = ItemStack.EMPTY;
		Optional<CraftingRecipe> opt = level.getServer().getRecipeManager().getRecipeFor(RecipeType.CRAFTING, craftMatrix, level);
		if (opt.isPresent()) {
			CraftingRecipe r = opt.get();
			if (craftResult.setRecipeUsed(level, sp, r)) {
				ItemStack out = r.assemble(craftMatrix, level.registryAccess());
				if (out.isItemEnabled(level.enabledFeatures())) {
					result = out;
				}
			}
		}
		craftResult.setItem(0, result);
		setRemoteSlot(0, result);
		sp.connection.send(new ClientboundContainerSetSlotPacket(containerId, incrementStateId(), 0, result));
	}

	private void onLearnSlotChanged() {
		if (!(player instanceof ServerPlayer sp)) return;
		ItemStack now = learnInv.getItem(0);
		if (ItemStack.matches(now, lastLearnSeen)) return;
		lastLearnSeen = now.copy();
		if (!now.isEmpty()) {
			applyLearn(sp, now);
		}
	}

	private void onUnlearnSlotChanged() {
		if (!(player instanceof ServerPlayer sp)) return;
		ItemStack now = unlearnInv.getItem(0);
		if (ItemStack.matches(now, lastUnlearnSeen)) return;
		lastUnlearnSeen = now.copy();
		if (!now.isEmpty()) {
			applyUnlearn(sp, now);
		}
	}

	private void applyLearn(ServerPlayer sp, ItemStack stack) {
		IEMCProxy emc = ProjectEAPI.getEMCProxy();
		if (emc.getValue(stack) <= 0L) return;
		ItemInfo info = emc.getPersistentInfo(ItemInfo.fromStack(stack));
		if (provider.addKnowledge(info)) {
			provider.syncKnowledgeChange(sp, info, true);
			provider.sync(sp);
		}
	}

	private void applyUnlearn(ServerPlayer sp, ItemStack stack) {
		IEMCProxy emc = ProjectEAPI.getEMCProxy();
		ItemInfo info = emc.getPersistentInfo(ItemInfo.fromStack(stack));
		if (provider.removeKnowledge(info)) {
			provider.syncKnowledgeChange(sp, info, false);
			provider.sync(sp);
		}
	}

	@Override
	public void removed(Player player) {
		super.removed(player);
		if (!player.level().isClientSide()) {
			// dump matrix
			for (int i = 0; i < 9; i++) {
				ItemStack s = craftMatrix.removeItemNoUpdate(i);
				if (!s.isEmpty()) ItemHandlerHelper.giveItemToPlayer(player, s);
			}
			ItemStack a = learnInv.removeItemNoUpdate(0);
			if (!a.isEmpty()) ItemHandlerHelper.giveItemToPlayer(player, a);
			ItemStack b = unlearnInv.removeItemNoUpdate(0);
			if (!b.isEmpty()) ItemHandlerHelper.giveItemToPlayer(player, b);
		}
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		// vanilla calls quickMoveStack(0) in a tight loop for shift-click bulk-craft. With auto-refill the matrix
		// stays full so the loop never terminates. Detect the back-to-back loop calls and break after the first.
		if (index == 0) {
			long now = System.currentTimeMillis();
			long since = now - lastResultQuickMoveAt;
			lastResultQuickMoveAt = now;
			if (since < 50L) {
				return ItemStack.EMPTY;
			}
		}

		Slot slot = slots.get(index);
		if (!slot.hasItem()) return ItemStack.EMPTY;
		ItemStack source = slot.getItem();
		ItemStack copy = source.copy();

		// 0=result, 1-9=matrix, 10=learn, 11=unlearn, 12-47=player inv
		if (index == 0) {
			// result → player inv
			if (!moveItemStackTo(source, 12, 48, true)) return ItemStack.EMPTY;
			slot.onQuickCraft(source, copy);
		} else if (index >= 1 && index <= 11) {
			// matrix or learn/unlearn slot → player inv
			if (!moveItemStackTo(source, 12, 48, true)) return ItemStack.EMPTY;
		} else {
			// player inv → burn the stack for EMC
			if (player instanceof ServerPlayer sp) {
				burnStackInPlace(sp, slot);
			}
			return ItemStack.EMPTY;
		}

		if (source.isEmpty()) {
			slot.set(ItemStack.EMPTY);
		} else {
			slot.setChanged();
		}

		if (source.getCount() == copy.getCount()) {
			return ItemStack.EMPTY;
		}

		// trigger crafting consumption (for the result slot) or normal slot-take logic
		slot.onTake(player, source);
		return copy;
	}

	private void burnStackInPlace(ServerPlayer sp, Slot slot) {
		ItemStack stack = slot.getItem();
		if (stack.isEmpty()) return;
		IEMCProxy emc = ProjectEAPI.getEMCProxy();
		long perItem = emc.getValue(stack);
		if (perItem <= 0L) return;

		ItemInfo info = emc.getPersistentInfo(ItemInfo.fromStack(stack));
		boolean wasNew = !provider.hasKnowledge(info);
		if (wasNew) provider.addKnowledge(info);

		boolean isHolder = stack.getCapability(PECapabilities.EMC_HOLDER_ITEM_CAPABILITY).isPresent();
		if (isHolder) {
			IItemEmcHolder holder = stack.getCapability(PECapabilities.EMC_HOLDER_ITEM_CAPABILITY).orElseThrow(() -> new IllegalStateException("missing holder"));
			long stored = holder.getStoredEmc(stack);
			if (stored > 0L) {
				holder.extractEmc(stack, stored, IEmcStorage.EmcAction.EXECUTE);
				provider.setEmc(provider.getEmc().add(BigInteger.valueOf(stored)));
				slot.setChanged();
			} else {
				int count = stack.getCount();
				BigInteger total = BigInteger.valueOf(perItem).multiply(BigInteger.valueOf(count));
				provider.setEmc(provider.getEmc().add(total));
				slot.set(ItemStack.EMPTY);
			}
		} else {
			int count = stack.getCount();
			BigInteger total = BigInteger.valueOf(perItem).multiply(BigInteger.valueOf(count));
			provider.setEmc(provider.getEmc().add(total));
			slot.set(ItemStack.EMPTY);
		}

		provider.syncEmc(sp);
		if (wasNew) {
			provider.syncKnowledgeChange(sp, info, true);
			provider.sync(sp);
		}
	}

	public void handleAction(int action, ItemStack target) {
		if (!(player instanceof ServerPlayer sp)) return;
		switch (action) {
			case ACTION_TAKE_ONE -> takeFromKnowledge(target, 1, false);
			case ACTION_TAKE_STACK -> takeFromKnowledge(target, target.getMaxStackSize(), false);
			case ACTION_TAKE_STACK_TO_INV -> takeFromKnowledge(target, target.getMaxStackSize(), true);
			case ACTION_BURN -> burnCarried(sp, false);
			case ACTION_BURN_ALL -> burnCarried(sp, true);
			case ACTION_CLEAR_MATRIX -> clearMatrix(sp);
			case ACTION_ROTATE_CW -> rotateMatrix(true);
			case ACTION_ROTATE_CCW -> rotateMatrix(false);
			case ACTION_BALANCE -> balanceMatrix();
			case ACTION_SPREAD -> spreadMatrix();
			case ACTION_CRAFT_MAX -> craftMax(sp);
		}
	}

	private void craftMax(ServerPlayer sp) {
		ServerLevel level = sp.serverLevel();
		final int safetyCap = 4096;

		for (int iter = 0; iter < safetyCap; iter++) {
			ItemStack result = craftResult.getItem(0);
			if (result.isEmpty()) break;

			// Stop if entire output stack wouldn't fit in main inventory
			if (countFreeSpaceForStack(sp, result) < result.getCount()) break;

			Optional<CraftingRecipe> opt = level.getServer().getRecipeManager().getRecipeFor(RecipeType.CRAFTING, craftMatrix, level);
			if (opt.isEmpty()) break;
			CraftingRecipe recipe = opt.get();

			// Templates from current matrix (1 each) so refillMatrix can top up after consumption
			ItemStack[] templates = new ItemStack[9];
			for (int i = 0; i < 9; i++) {
				ItemStack s = craftMatrix.getItem(i);
				templates[i] = s.isEmpty() ? ItemStack.EMPTY : ItemHandlerHelper.copyStackWithSize(s, 1);
			}

			// Recipe remainders (e.g. empty buckets) are computed against the pre-consumption matrix
			NonNullList<ItemStack> remainders = recipe.getRemainingItems(craftMatrix);

			// Consume one of each ingredient
			for (int i = 0; i < 9; i++) {
				ItemStack s = craftMatrix.getItem(i);
				if (!s.isEmpty()) s.shrink(1);
			}

			// Place remainders back; if the slot is occupied, dump them in inventory
			for (int i = 0; i < remainders.size() && i < 9; i++) {
				ItemStack rem = remainders.get(i);
				if (rem.isEmpty()) continue;
				if (craftMatrix.getItem(i).isEmpty()) {
					craftMatrix.setItem(i, rem);
				} else {
					sp.getInventory().add(rem);
				}
			}

			// Add the crafted output to inventory (precheck guarantees it fits)
			sp.getInventory().add(result.copy());

			// Refill matrix from inv → EMC, then recompute the result
			refillMatrix(sp, templates);
			updateCraftingResult(sp);
		}
	}

	private static int countFreeSpaceForStack(ServerPlayer sp, ItemStack template) {
		if (template.isEmpty()) return 0;
		int free = 0;
		int max = template.getMaxStackSize();
		int size = Math.min(sp.getInventory().getContainerSize(), 36);
		for (int i = 0; i < size; i++) {
			ItemStack s = sp.getInventory().getItem(i);
			if (s.isEmpty()) {
				free += max;
			} else if (ItemStack.isSameItemSameTags(s, template)) {
				free += Math.max(0, s.getMaxStackSize() - s.getCount());
			}
		}
		return free;
	}

	private void clearMatrix(ServerPlayer sp) {
		IEMCProxy emc = ProjectEAPI.getEMCProxy();
		BigInteger emcAvailable = provider.getEmc();
		boolean emcChanged = false;

		for (int i = 0; i < 9; i++) {
			ItemStack stack = craftMatrix.removeItemNoUpdate(i);
			if (stack.isEmpty()) continue;

			long perItem = emc.getValue(stack);
			ItemInfo info = emc.getPersistentInfo(ItemInfo.fromStack(stack));
			if (perItem > 0L && provider.hasKnowledge(info)) {
				BigInteger total = BigInteger.valueOf(perItem).multiply(BigInteger.valueOf(stack.getCount()));
				emcAvailable = emcAvailable.add(total);
				emcChanged = true;
			} else {
				ItemHandlerHelper.giveItemToPlayer(sp, stack);
			}
		}

		if (emcChanged) {
			provider.setEmc(emcAvailable);
			provider.syncEmc(sp);
		}
		slotsChanged(craftMatrix);
	}

	private void rotateMatrix(boolean cw) {
		ItemStack[] perim = new ItemStack[ROTATION_SLOTS.length];
		for (int i = 0; i < ROTATION_SLOTS.length; i++) {
			perim[i] = craftMatrix.getItem(ROTATION_SLOTS[i]);
		}
		ItemStack[] rotated = new ItemStack[ROTATION_SLOTS.length];
		for (int i = 0; i < ROTATION_SLOTS.length; i++) {
			int src = cw
					? (i - 1 + ROTATION_SLOTS.length) % ROTATION_SLOTS.length
					: (i + 1) % ROTATION_SLOTS.length;
			rotated[i] = perim[src];
		}
		for (int i = 0; i < ROTATION_SLOTS.length; i++) {
			craftMatrix.setItem(ROTATION_SLOTS[i], rotated[i]);
		}
		slotsChanged(craftMatrix);
	}

	private void balanceMatrix() {
		List<List<Integer>> groups = new ArrayList<>();
		List<ItemStack> reps = new ArrayList<>();
		List<Integer> totals = new ArrayList<>();

		for (int i = 0; i < 9; i++) {
			ItemStack stack = craftMatrix.getItem(i);
			if (stack.isEmpty() || stack.getMaxStackSize() <= 1) continue;
			int gi = -1;
			for (int g = 0; g < reps.size(); g++) {
				if (ItemStack.isSameItemSameTags(stack, reps.get(g))) {
					gi = g;
					break;
				}
			}
			if (gi < 0) {
				gi = reps.size();
				reps.add(stack);
				groups.add(new ArrayList<>());
				totals.add(0);
			}
			groups.get(gi).add(i);
			totals.set(gi, totals.get(gi) + stack.getCount());
		}

		for (int g = 0; g < groups.size(); g++) {
			List<Integer> slots = groups.get(g);
			int total = totals.get(g);
			int per = total / slots.size();
			int rem = total % slots.size();
			for (int k = 0; k < slots.size(); k++) {
				ItemStack stack = craftMatrix.getItem(slots.get(k));
				stack.setCount(per + (k < rem ? 1 : 0));
			}
		}
		slotsChanged(craftMatrix);
	}

	private void spreadMatrix() {
		boolean keepGoing;
		do {
			ItemStack biggest = null;
			int biggestCount = 1;
			for (int i = 0; i < 9; i++) {
				ItemStack s = craftMatrix.getItem(i);
				if (s.isEmpty() || s.getCount() <= biggestCount) continue;
				biggest = s;
				biggestCount = s.getCount();
			}
			if (biggest == null) break;

			keepGoing = false;
			for (int i = 0; i < 9; i++) {
				ItemStack s = craftMatrix.getItem(i);
				if (!s.isEmpty()) continue;
				if (biggest.getCount() > 1) {
					craftMatrix.setItem(i, biggest.split(1));
				} else {
					keepGoing = true;
				}
			}
		} while (keepGoing);
		balanceMatrix();
	}

	private void syncCarriedNow(ServerPlayer sp) {
		sp.connection.send(new ClientboundContainerSetSlotPacket(-1, -1, 0, getCarried()));
	}

	private void takeFromKnowledge(ItemStack template, int desiredCount, boolean toInventory) {
		if (template.isEmpty() || desiredCount <= 0) return;
		IEMCProxy emc = ProjectEAPI.getEMCProxy();
		long perItem = emc.getValue(template);
		if (perItem <= 0L) return;
		ItemInfo info = ItemInfo.fromStack(template);
		if (!provider.hasKnowledge(info)) return;

		BigInteger available = provider.getEmc();
		BigInteger costPer = BigInteger.valueOf(perItem);
		int maxStack = Math.min(desiredCount, template.getMaxStackSize());
		int affordable = (int) available.divide(costPer).min(BigInteger.valueOf(maxStack)).longValueExact();
		if (affordable <= 0) return;

		ItemStack out = template.copy();
		out.setCount(affordable);
		int actuallyTake = affordable;

		if (toInventory) {
			ItemHandlerHelper.giveItemToPlayer(player, out);
		} else {
			ItemStack carried = getCarried();
			if (!carried.isEmpty() && ItemStack.isSameItemSameTags(carried, out)) {
				int room = carried.getMaxStackSize() - carried.getCount();
				actuallyTake = Math.min(affordable, room);
				if (actuallyTake <= 0) return;
				carried.grow(actuallyTake);
				setCarried(carried);
			} else if (carried.isEmpty()) {
				setCarried(out);
			} else {
				ItemHandlerHelper.giveItemToPlayer(player, out);
			}
			syncCarriedNow((ServerPlayer) player);
		}

		BigInteger totalCost = costPer.multiply(BigInteger.valueOf(actuallyTake));
		provider.setEmc(available.subtract(totalCost));
		provider.syncEmc((ServerPlayer) player);
	}

	private void burnCarried(ServerPlayer sp, boolean entireStack) {
		ItemStack carried = getCarried();
		if (carried.isEmpty()) return;
		IEMCProxy emc = ProjectEAPI.getEMCProxy();
		long value = emc.getValue(carried);
		if (value <= 0L) return;

		ItemInfo info = emc.getPersistentInfo(ItemInfo.fromStack(carried));
		boolean wasNew = !provider.hasKnowledge(info);
		if (wasNew) provider.addKnowledge(info);

		boolean isHolder = carried.getCapability(PECapabilities.EMC_HOLDER_ITEM_CAPABILITY).isPresent();
		if (isHolder) {
			IItemEmcHolder holder = carried.getCapability(PECapabilities.EMC_HOLDER_ITEM_CAPABILITY).orElseThrow(() -> new IllegalStateException("missing holder"));
			long stored = holder.getStoredEmc(carried);
			if (stored > 0L) {
				// charged EMC holder: drain stored EMC, leave the item
				holder.extractEmc(carried, stored, IEmcStorage.EmcAction.EXECUTE);
				provider.setEmc(provider.getEmc().add(BigInteger.valueOf(stored)));
				setCarried(carried);
			} else {
				// empty EMC holder: consume the item for its base EMC value
				int consume = entireStack ? carried.getCount() : 1;
				BigInteger total = BigInteger.valueOf(value).multiply(BigInteger.valueOf(consume));
				provider.setEmc(provider.getEmc().add(total));
				carried.shrink(consume);
				setCarried(carried);
			}
		} else {
			int consume = entireStack ? carried.getCount() : 1;
			BigInteger total = BigInteger.valueOf(value).multiply(BigInteger.valueOf(consume));
			provider.setEmc(provider.getEmc().add(total));
			carried.shrink(consume);
			setCarried(carried);
		}

		provider.syncEmc(sp);
		if (wasNew) {
			provider.syncKnowledgeChange(sp, info, true);
			provider.sync(sp);
		}
		syncCarriedNow(sp);
	}
}
