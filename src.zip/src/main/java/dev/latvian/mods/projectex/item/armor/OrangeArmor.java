package dev.latvian.mods.projectex.item.armor;

import moze_intel.projecte.gameObjs.items.armor.PEArmor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.crafting.Ingredient;
import org.jetbrains.annotations.NotNull;

public class OrangeArmor extends PEArmor {
	public OrangeArmor(ArmorItem.Type type, Item.Properties props) { super(OrangeArmorMaterial.INSTANCE, type, props); }
	@Override public float getFullSetBaseReduction() { return 0.9995F; }
	@Override
	public float getMaxDamageAbsorb(ArmorItem.Type type, DamageSource source) {
		if (source.is(DamageTypeTags.IS_FIRE)) return 2050.0F;
		if (type == ArmorItem.Type.BOOTS && source.is(DamageTypeTags.IS_FALL)) return 45.0F / getPieceEffectiveness(type);
		if (type == ArmorItem.Type.HELMET && source.is(DamageTypeTags.DAMAGES_HELMET)) return 45.0F / getPieceEffectiveness(type);
		if (source.is(DamageTypeTags.BYPASSES_ARMOR)) return 0.0F;
		if (type == ArmorItem.Type.HELMET || type == ArmorItem.Type.BOOTS) return 1025.0F;
		return 1400.0F;
	}
	private static class OrangeArmorMaterial implements ArmorMaterial {
		private static final OrangeArmorMaterial INSTANCE = new OrangeArmorMaterial();
		private static final String NAME = new ResourceLocation("projectex", "orange_matter").toString();
		public int getDurabilityForType(@NotNull ArmorItem.Type type) { return 0; }
		public int getDefenseForType(@NotNull ArmorItem.Type type) { return switch (type) { case BOOTS, HELMET -> 3; case LEGGINGS -> 6; case CHESTPLATE -> 8; }; }
		public int getEnchantmentValue() { return 0; }
		@NotNull public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_DIAMOND; }
		@NotNull public Ingredient getRepairIngredient() { return Ingredient.EMPTY; }
		@NotNull public String getName() { return NAME; }
		public float getToughness() { return 7.5F; }
		public float getKnockbackResistance() { return 0.75F; }
	}
}
