package dev.latvian.mods.projectex.item.armor;

import moze_intel.projecte.gameObjs.items.armor.PEArmor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class FadingArmorBase extends PEArmor {
	// Same 20-step strobe pattern as the fading_matter item icon (frametime 1).
	private static final int[] FRAME_CYCLE = {2, 1, 0, 2, 1, 0, 1, 0, 3, 0, 0, 1, 1, 2, 3, 1, 0, 3, 0, 0};

	public FadingArmorBase(ArmorItem.Type type, Item.Properties props) {
		super(FadingArmorMaterial.INSTANCE, type, props);
	}

	@Override
	public @Nullable String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
		if (type != null) return null;
		int layer = (slot == EquipmentSlot.LEGS) ? 2 : 1;
		long tick = entity != null && entity.level() != null ? entity.level().getGameTime() : 0L;
		int frame = FRAME_CYCLE[(int) Math.floorMod(tick, FRAME_CYCLE.length)];
		return "projectex:textures/models/armor/fading_armor_layer_" + layer + "_f" + frame + ".png";
	}

	@Override
	public float getFullSetBaseReduction() {
		return 1.0F;
	}

	@Override
	public float getMaxDamageAbsorb(ArmorItem.Type type, DamageSource source) {
		if (source.is(DamageTypeTags.IS_FIRE)) return 4150.0F;
		if (type == ArmorItem.Type.BOOTS && source.is(DamageTypeTags.IS_FALL)) return 80.0F / getPieceEffectiveness(type);
		if (type == ArmorItem.Type.HELMET && source.is(DamageTypeTags.DAMAGES_HELMET)) return 80.0F / getPieceEffectiveness(type);
		if (source.is(DamageTypeTags.BYPASSES_ARMOR)) return 0.0F;
		if (type == ArmorItem.Type.HELMET || type == ArmorItem.Type.BOOTS) return 2075.0F;
		return 2800.0F;
	}

	public static boolean hasAnyPiece(Player player) {
		return player.getInventory().armor.stream().anyMatch(i -> !i.isEmpty() && i.getItem() instanceof FadingArmorBase);
	}

	private static class FadingArmorMaterial implements ArmorMaterial {
		private static final FadingArmorMaterial INSTANCE = new FadingArmorMaterial();
		private static final String NAME = new ResourceLocation("projectex", "fading_armor").toString();
		public int getDurabilityForType(@NotNull ArmorItem.Type type) { return 0; }
		public int getDefenseForType(@NotNull ArmorItem.Type type) {
			return switch (type) { case BOOTS, HELMET -> 3; case LEGGINGS -> 6; case CHESTPLATE -> 8; };
		}
		public int getEnchantmentValue() { return 0; }
		@NotNull public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_NETHERITE; }
		@NotNull public Ingredient getRepairIngredient() { return Ingredient.EMPTY; }
		@NotNull public String getName() { return NAME; }
		public float getToughness() { return 14.5F; }
		public float getKnockbackResistance() { return 1.0F; }
	}
}
