package dev.latvian.mods.projectex.util;

import dev.latvian.mods.projectex.item.armor.BlueGemHelmet;
import dev.latvian.mods.projectex.item.armor.CyanGemHelmet;
import dev.latvian.mods.projectex.item.armor.FadingHelmet;
import dev.latvian.mods.projectex.item.armor.GreenGemHelmet;
import dev.latvian.mods.projectex.item.armor.LimeGemHelmet;
import dev.latvian.mods.projectex.item.armor.OrangeGemHelmet;
import dev.latvian.mods.projectex.item.armor.PinkGemHelmet;
import dev.latvian.mods.projectex.item.armor.PurpleGemHelmet;
import dev.latvian.mods.projectex.item.armor.WhiteGemHelmet;
import dev.latvian.mods.projectex.item.armor.YellowGemHelmet;
import moze_intel.projecte.gameObjs.items.armor.GemHelmet;
import net.minecraft.world.item.Item;

// Per-tier lightning-zap cooldown in ticks. Same shrink curve as SelfDestructCooldown so the two
// abilities feel rhythmically paired. Returns 0 for a non-gem-helmet item.
public final class LightningCooldown {
	private LightningCooldown() {}

	public static long ticksFor(Item helm) {
		if (helm instanceof FadingHelmet)        return 4L;   // 0.20s
		if (helm instanceof WhiteGemHelmet)      return 10L;  // 0.50s
		if (helm instanceof OrangeGemHelmet)     return 13L;  // 0.65s
		if (helm instanceof YellowGemHelmet)     return 17L;  // 0.85s
		if (helm instanceof LimeGemHelmet)       return 20L;  // 1.00s
		if (helm instanceof GreenGemHelmet)      return 23L;  // 1.15s
		if (helm instanceof CyanGemHelmet)       return 27L;  // 1.35s
		if (helm instanceof BlueGemHelmet)       return 30L;  // 1.50s
		if (helm instanceof PurpleGemHelmet)     return 33L;  // 1.65s
		if (helm instanceof PinkGemHelmet)       return 37L;  // 1.85s
		if (helm instanceof GemHelmet)           return 40L;  // 2.00s (Red Matter / PE base)
		return 0L;
	}
}
