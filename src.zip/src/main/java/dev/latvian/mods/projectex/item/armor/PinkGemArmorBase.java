package dev.latvian.mods.projectex.item.armor;

import moze_intel.projecte.gameObjs.items.armor.PEArmor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.crafting.Ingredient;
import org.jetbrains.annotations.NotNull;

public abstract class PinkGemArmorBase extends PEArmor {
	public PinkGemArmorBase(ArmorItem.Type type, Item.Properties props) {
		super(PinkGemArmorMaterial.INSTANCE, type, props);
	}

	@Override
	public float getFullSetBaseReduction() {
		return 0.98F;
	}

	@Override
	public float getMaxDamageAbsorb(ArmorItem.Type type, DamageSource source) {
		if (source.is(DamageTypeTags.IS_FIRE)) {
			return 1300.0F;
		}
		if (type == ArmorItem.Type.BOOTS && source.is(DamageTypeTags.IS_FALL)) {
			return 30.0F / getPieceEffectiveness(type);
		}
		if (type == ArmorItem.Type.HELMET && source.is(DamageTypeTags.DAMAGES_HELMET)) {
			return 30.0F / getPieceEffectiveness(type);
		}
		if (source.is(DamageTypeTags.BYPASSES_ARMOR)) {
			return 0.0F;
		}
		if (type == ArmorItem.Type.HELMET || type == ArmorItem.Type.BOOTS) {
			return 650.0F;
		}
		return 900.0F;
	}

	public static boolean hasAnyPiece(Player player) {
		return player.getInventory().armor.stream().anyMatch(i -> !i.isEmpty() && i.getItem() instanceof PinkGemArmorBase);
	}

	private static class PinkGemArmorMaterial implements ArmorMaterial {
		private static final PinkGemArmorMaterial INSTANCE = new PinkGemArmorMaterial();
		private static final String NAME = new ResourceLocation("projectex", "pink_gem_armor").toString();

		@Override
		public int getDurabilityForType(@NotNull ArmorItem.Type type) {
			return 0;
		}

		@Override
		public int getDefenseForType(@NotNull ArmorItem.Type type) {
			return switch (type) {
				case BOOTS, HELMET -> 3;
				case LEGGINGS -> 6;
				case CHESTPLATE -> 8;
			};
		}

		@Override
		public int getEnchantmentValue() {
			return 0;
		}

		@NotNull
		@Override
		public SoundEvent getEquipSound() {
			return SoundEvents.ARMOR_EQUIP_NETHERITE;
		}

		@NotNull
		@Override
		public Ingredient getRepairIngredient() {
			return Ingredient.EMPTY;
		}

		@NotNull
		@Override
		public String getName() {
			return NAME;
		}

		@Override
		public float getToughness() {
			return 5.0F;
		}

		@Override
		public float getKnockbackResistance() {
			return 0.5F;
		}
	}
}
