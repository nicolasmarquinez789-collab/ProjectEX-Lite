package dev.latvian.mods.projectex.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.latvian.mods.projectex.item.armor.WhiteArmor;
import dev.latvian.mods.projectex.item.armor.WhiteGemHelmet;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix4f;

public class HaloLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
	private static final ResourceLocation TEXTURE = new ResourceLocation("projectex", "textures/effects/halo.png");

	public HaloLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
		super(parent);
	}

	@Override
	public void render(PoseStack pose, MultiBufferSource buffer, int packedLight, AbstractClientPlayer player,
	                   float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks,
	                   float netHeadYaw, float headPitch) {
		ItemStack helm = player.getItemBySlot(EquipmentSlot.HEAD);
		Item h = helm.getItem();
		boolean isWhiteHelmet = h instanceof WhiteGemHelmet
				|| (h instanceof WhiteArmor && ((ArmorItem) h).getEquipmentSlot() == EquipmentSlot.HEAD);
		if (!isWhiteHelmet) return;

		// Skip the local player in first-person camera mode so it doesn't fill their view.
		Minecraft mc = Minecraft.getInstance();
		if (player == mc.player && mc.options.getCameraType().isFirstPerson()) return;

		VertexConsumer vc = buffer.getBuffer(RenderType.entityTranslucent(TEXTURE));
		int overlay = OverlayTexture.NO_OVERLAY;
		var camera = mc.getEntityRenderDispatcher().cameraOrientation();

		// Outer ring — sits centered above the head, camera-billboarded.
		pose.pushPose();
		pose.translate(0.0F, -0.95F, 0.0F);
		pose.mulPose(camera);
		drawHaloQuad(vc, pose.last().pose(), 0.35F, packedLight, overlay);
		pose.popPose();

		// Inner ring — orbits the head in a HORIZONTAL world-space circle, then billboards.
		// Because the offset is applied before cameraOrientation, the orbit position is anchored
		// in entity space (not screen space) so turning the camera doesn't carry it along.
		float orbit = ageInTicks * 0.05F;
		float orbitRadius = 0.45F;
		float dx = (float) Math.cos(orbit) * orbitRadius;
		float dz = (float) Math.sin(orbit) * orbitRadius;

		pose.pushPose();
		pose.translate(dx, -0.95F, dz);
		pose.mulPose(camera);
		drawHaloQuad(vc, pose.last().pose(), 0.12F, packedLight, overlay);
		pose.popPose();
	}

	private static void drawHaloQuad(VertexConsumer vc, Matrix4f matrix, float size, int packedLight, int overlay) {
		vc.vertex(matrix, -size, -size, 0.0F).color(1.0F, 1.0F, 1.0F, 1.0F).uv(0.0F, 1.0F).overlayCoords(overlay).uv2(packedLight).normal(0.0F, 0.0F, 1.0F).endVertex();
		vc.vertex(matrix,  size, -size, 0.0F).color(1.0F, 1.0F, 1.0F, 1.0F).uv(1.0F, 1.0F).overlayCoords(overlay).uv2(packedLight).normal(0.0F, 0.0F, 1.0F).endVertex();
		vc.vertex(matrix,  size,  size, 0.0F).color(1.0F, 1.0F, 1.0F, 1.0F).uv(1.0F, 0.0F).overlayCoords(overlay).uv2(packedLight).normal(0.0F, 0.0F, 1.0F).endVertex();
		vc.vertex(matrix, -size,  size, 0.0F).color(1.0F, 1.0F, 1.0F, 1.0F).uv(0.0F, 0.0F).overlayCoords(overlay).uv2(packedLight).normal(0.0F, 0.0F, 1.0F).endVertex();
	}
}
