package dev.latvian.mods.projectex.item.armor;

import moze_intel.projecte.gameObjs.items.armor.PEArmor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.crafting.Ingredient;
import org.jetbrains.annotations.NotNull;

public class PinkArmor extends PEArmor {
	public PinkArmor(ArmorItem.Type type, Item.Properties props) {
		super(PinkArmorMaterial.INSTANCE, type, props);
	}

	@Override
	public float getFullSetBaseReduction() {
		return 0.96F;
	}

	@Override
	public float getMaxDamageAbsorb(ArmorItem.Type type, DamageSource source) {
		if (source.is(DamageTypeTags.IS_FIRE)) {
			return 850.0F;
		}
		if (type == ArmorItem.Type.BOOTS && source.is(DamageTypeTags.IS_FALL)) {
			return 22.0F / getPieceEffectiveness(type);
		}
		if (type == ArmorItem.Type.HELMET && source.is(DamageTypeTags.DAMAGES_HELMET)) {
			return 22.0F / getPieceEffectiveness(type);
		}
		if (source.is(DamageTypeTags.BYPASSES_ARMOR)) {
			return 0.0F;
		}
		if (type == ArmorItem.Type.HELMET || type == ArmorItem.Type.BOOTS) {
			return 425.0F;
		}
		return 600.0F;
	}

	private static class PinkArmorMaterial implements ArmorMaterial {
		private static final PinkArmorMaterial INSTANCE = new PinkArmorMaterial();
		private static final String NAME = new ResourceLocation("projectex", "pink_matter").toString();

		@Override
		public int getDurabilityForType(@NotNull ArmorItem.Type type) {
			return 0;
		}

		@Override
		public int getDefenseForType(@NotNull ArmorItem.Type type) {
			return switch (type) {
				case BOOTS, HELMET -> 3;
				case LEGGINGS -> 6;
				case CHESTPLATE -> 8;
			};
		}

		@Override
		public int getEnchantmentValue() {
			return 0;
		}

		@NotNull
		@Override
		public SoundEvent getEquipSound() {
			return SoundEvents.ARMOR_EQUIP_DIAMOND;
		}

		@NotNull
		@Override
		public Ingredient getRepairIngredient() {
			return Ingredient.EMPTY;
		}

		@NotNull
		@Override
		public String getName() {
			return NAME;
		}

		@Override
		public float getToughness() {
			return 3.5F;
		}

		@Override
		public float getKnockbackResistance() {
			return 0.35F;
		}
	}
}
