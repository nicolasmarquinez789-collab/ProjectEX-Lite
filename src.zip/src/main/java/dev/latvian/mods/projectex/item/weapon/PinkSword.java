package dev.latvian.mods.projectex.item.weapon;

import com.google.common.collect.Multimap;
import dev.latvian.mods.projectex.util.TierDamage;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.item.ItemStack;
import moze_intel.projecte.gameObjs.items.tools.RedMatterSword;
import net.minecraft.world.item.Item;

// Extends Red Matter sword so it inherits every behavior PE gives it: chargeable
// (IItemCharge), mode switching (slay-all toggle), the extra-function homing/aoe
// swing, infinite durability cap, repair, EMC.
public class PinkSword extends RedMatterSword {
	public PinkSword(Item.Properties props) {
		super(props);
	}

	@Override
	public Multimap<Attribute, AttributeModifier> getAttributeModifiers(EquipmentSlot slot, ItemStack stack) {
		return TierDamage.boost(super.getAttributeModifiers(slot, stack), slot, 1.5F);
	}
}
