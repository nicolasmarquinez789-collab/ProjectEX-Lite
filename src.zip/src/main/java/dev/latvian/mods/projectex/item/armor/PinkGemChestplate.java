package dev.latvian.mods.projectex.item.armor;

import moze_intel.projecte.gameObjs.items.IFireProtector;
import moze_intel.projecte.handlers.InternalTimers;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class PinkGemChestplate extends PinkGemArmorBase implements IFireProtector {
	public PinkGemChestplate(Item.Properties props) {
		super(ArmorItem.Type.CHESTPLATE, props);
	}

	@Override
	public void onArmorTick(ItemStack stack, Level level, Player player) {
		if (level.isClientSide()) return;

		player.getCapability(InternalTimers.CAPABILITY).ifPresent(timers -> {
			timers.activateFeed();
			if (player.getFoodData().needsFood() && timers.canFeed()) {
				player.getFoodData().eat(2, 10.0F);
			}
		});
	}

	@Override
	public boolean canProtectAgainstFire(ItemStack stack, ServerPlayer player) {
		return player.getItemBySlot(EquipmentSlot.CHEST) == stack;
	}

	public static void doExplode(ServerPlayer player) {
		Level level = player.level();
		level.explode(player, player.getX(), player.getY(), player.getZ(), 5.0F, Level.ExplosionInteraction.BLOCK);
	}
}
