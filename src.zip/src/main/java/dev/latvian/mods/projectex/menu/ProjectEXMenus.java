package dev.latvian.mods.projectex.menu;

import dev.latvian.mods.projectex.ProjectEX;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public interface ProjectEXMenus {
	DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, ProjectEX.MOD_ID);

	RegistryObject<MenuType<StoneTableMenu>> STONE_TABLE = REGISTRY.register("stone_table",
			() -> IForgeMenuType.create(StoneTableMenu::fromNetwork));

	RegistryObject<MenuType<ArcaneTabletMenu>> ARCANE_TABLET = REGISTRY.register("arcane_tablet",
			() -> IForgeMenuType.create(ArcaneTabletMenu::fromNetwork));
}
