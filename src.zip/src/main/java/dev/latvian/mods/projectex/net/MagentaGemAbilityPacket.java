package dev.latvian.mods.projectex.net;

import dev.latvian.mods.projectex.item.armor.PinkGemChestplate;
import dev.latvian.mods.projectex.item.armor.PinkGemHelmet;
import dev.latvian.mods.projectex.item.armor.PurpleGemChestplate;
import dev.latvian.mods.projectex.item.armor.PurpleGemHelmet;
import dev.latvian.mods.projectex.item.armor.BlueGemChestplate;
import dev.latvian.mods.projectex.item.armor.BlueGemHelmet;
import dev.latvian.mods.projectex.item.armor.CyanGemChestplate;
import dev.latvian.mods.projectex.item.armor.CyanGemHelmet;
import dev.latvian.mods.projectex.item.armor.GreenGemChestplate;
import dev.latvian.mods.projectex.item.armor.GreenGemHelmet;
import dev.latvian.mods.projectex.item.armor.LimeGemChestplate;
import dev.latvian.mods.projectex.item.armor.LimeGemHelmet;
import dev.latvian.mods.projectex.item.armor.YellowGemChestplate;
import dev.latvian.mods.projectex.item.armor.YellowGemHelmet;
import dev.latvian.mods.projectex.item.armor.OrangeGemChestplate;
import dev.latvian.mods.projectex.item.armor.OrangeGemHelmet;
import dev.latvian.mods.projectex.item.armor.WhiteGemChestplate;
import dev.latvian.mods.projectex.item.armor.WhiteGemHelmet;
import dev.latvian.mods.projectex.item.armor.FadingChestplate;
import dev.latvian.mods.projectex.item.armor.FadingHelmet;
import moze_intel.projecte.api.capabilities.PECapabilities;
import moze_intel.projecte.gameObjs.items.armor.GemChest;
import moze_intel.projecte.gameObjs.items.armor.GemHelmet;
import moze_intel.projecte.handlers.InternalAbilities;
import net.minecraft.world.InteractionHand;
import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

public record MagentaGemAbilityPacket(int kind) {
	public static final int KIND_TOGGLE_GEM = 0;
	public static final int KIND_ZAP = 1;
	public static final int KIND_NOVA = 2;
	public static final int KIND_KATAR = 3;
	public static final int KIND_SELF_DESTRUCT = 4;

	// Per-tier self-destruct cooldown lookup lives in SelfDestructCooldown. Per-player last-fire tick
	// is kept here on the server; the check uses the cooldown of whatever chest is equipped *now*.
	private static final ConcurrentHashMap<UUID, Long> SELF_DESTRUCT_LAST_TICK = new ConcurrentHashMap<>();
	// Same shape as above, but for the lightning zap (LightningCooldown / current helmet).
	private static final ConcurrentHashMap<UUID, Long> ZAP_LAST_TICK = new ConcurrentHashMap<>();

	public static void encode(MagentaGemAbilityPacket pkt, FriendlyByteBuf buf) {
		buf.writeVarInt(pkt.kind);
	}

	public static MagentaGemAbilityPacket decode(FriendlyByteBuf buf) {
		return new MagentaGemAbilityPacket(buf.readVarInt());
	}

	public static void handle(MagentaGemAbilityPacket pkt, Supplier<NetworkEvent.Context> ctxSup) {
		NetworkEvent.Context ctx = ctxSup.get();
		ctx.enqueueWork(() -> {
			ServerPlayer sp = ctx.getSender();
			if (sp == null) return;
			InternalAbilities abilities = sp.getCapability(InternalAbilities.CAPABILITY).orElse(null);
			if (abilities == null) return;

			switch (pkt.kind) {
				case KIND_TOGGLE_GEM -> {
					boolean newState = !abilities.getGemState();
					abilities.setGemState(newState);
					ChatFormatting color = newState ? ChatFormatting.GREEN : ChatFormatting.RED;
					String label = newState ? "ACTIVE" : "INACTIVE";
					sp.displayClientMessage(
							Component.literal("Gem Mode: ").append(Component.literal(label).withStyle(color)),
							true
					);
				}
				case KIND_ZAP -> {
					// Lightning zap — per-tier cooldown from LightningCooldown, mirroring self-destruct.
					ItemStack helm = sp.getItemBySlot(EquipmentSlot.HEAD);
					long zapCooldown = dev.latvian.mods.projectex.util.LightningCooldown.ticksFor(helm.getItem());
					if (zapCooldown == 0L) return; // not wearing any gem helmet
					UUID zapUuid = sp.getUUID();
					long zapNow = sp.level().getGameTime();
					Long zapLast = ZAP_LAST_TICK.get(zapUuid);
					if (zapLast != null && zapNow - zapLast < zapCooldown) return;
					boolean zapFired = false;
					if (helm.getItem() instanceof PinkGemHelmet) { PinkGemHelmet.doZap(sp); zapFired = true; }
					else if (helm.getItem() instanceof PurpleGemHelmet) { PurpleGemHelmet.doZap(sp); zapFired = true; }
					else if (helm.getItem() instanceof BlueGemHelmet) { BlueGemHelmet.doZap(sp); zapFired = true; }
					else if (helm.getItem() instanceof CyanGemHelmet) { CyanGemHelmet.doZap(sp); zapFired = true; }
					else if (helm.getItem() instanceof GreenGemHelmet) { GreenGemHelmet.doZap(sp); zapFired = true; }
					else if (helm.getItem() instanceof LimeGemHelmet) { LimeGemHelmet.doZap(sp); zapFired = true; }
					else if (helm.getItem() instanceof YellowGemHelmet) { YellowGemHelmet.doZap(sp); zapFired = true; }
					else if (helm.getItem() instanceof OrangeGemHelmet) { OrangeGemHelmet.doZap(sp); zapFired = true; }
					else if (helm.getItem() instanceof WhiteGemHelmet) { WhiteGemHelmet.doZap(sp); zapFired = true; }
					else if (helm.getItem() instanceof FadingHelmet) { FadingHelmet.doZap(sp); zapFired = true; }
					else if (helm.getItem() instanceof GemHelmet) {
						// PE's red-matter helmet: bypass the offensiveAbilities gate, fire red lightning.
						dev.latvian.mods.projectex.util.LightningZap.zap(sp, 0xFFCC2222, 2.0F);
						zapFired = true;
					}
					if (zapFired) ZAP_LAST_TICK.put(zapUuid, zapNow);
				}
				case KIND_NOVA -> {
					if (abilities.getGemCooldown() != 0) return;
					ItemStack chest = sp.getItemBySlot(EquipmentSlot.CHEST);
					if (chest.getItem() instanceof PinkGemChestplate) {
						PinkGemChestplate.doExplode(sp);
						abilities.resetGemCooldown();
					} else if (chest.getItem() instanceof PurpleGemChestplate) {
						PurpleGemChestplate.doExplode(sp);
						abilities.resetGemCooldown();
					} else if (chest.getItem() instanceof BlueGemChestplate) {
						BlueGemChestplate.doExplode(sp);
						abilities.resetGemCooldown();
					} else if (chest.getItem() instanceof CyanGemChestplate) {
						CyanGemChestplate.doExplode(sp);
						abilities.resetGemCooldown();
					} else if (chest.getItem() instanceof GreenGemChestplate) {
						GreenGemChestplate.doExplode(sp);
						abilities.resetGemCooldown();
					} else if (chest.getItem() instanceof LimeGemChestplate) {
						LimeGemChestplate.doExplode(sp);
						abilities.resetGemCooldown();
					} else if (chest.getItem() instanceof YellowGemChestplate) {
						YellowGemChestplate.doExplode(sp);
						abilities.resetGemCooldown();
					} else if (chest.getItem() instanceof OrangeGemChestplate) {
						OrangeGemChestplate.doExplode(sp);
						abilities.resetGemCooldown();
					} else if (chest.getItem() instanceof WhiteGemChestplate) {
						WhiteGemChestplate.doExplode(sp);
						abilities.resetGemCooldown();
					} else if (chest.getItem() instanceof FadingChestplate) {
						FadingChestplate.doExplode(sp);
						abilities.resetGemCooldown();
					}
				}
				case KIND_KATAR -> {
					// If the held item is a Katar (PE's or any tier), run our per-tier AoE swing with
					// scaled damage and range. For any other extra-function-capable item, fall back to
					// PE's stock capability.
					for (InteractionHand hand : InteractionHand.values()) {
						ItemStack stack = sp.getItemInHand(hand);
						if (stack.isEmpty()) continue;
						if (stack.getItem() instanceof moze_intel.projecte.gameObjs.items.tools.PEKatar) {
							if (dev.latvian.mods.projectex.util.KatarAbility.swing(sp, stack, hand)) return;
							continue;
						}
						if (stack.getCapability(PECapabilities.EXTRA_FUNCTION_ITEM_CAPABILITY)
								.filter(cap -> cap.doExtraFunction(stack, sp, hand)).isPresent()) {
							return;
						}
					}
				}
				case KIND_SELF_DESTRUCT -> {
					// Self-destruct nova — fires any gem chest's explosion without needing gem mode armed.
					// Per-tier cooldown from SelfDestructCooldown — higher tiers fire faster.
					ItemStack chest = sp.getItemBySlot(EquipmentSlot.CHEST);
					long cooldown = dev.latvian.mods.projectex.util.SelfDestructCooldown.ticksFor(chest.getItem());
					if (cooldown == 0L) return; // not wearing any gem chestplate
					UUID uuid = sp.getUUID();
					long now = sp.level().getGameTime();
					Long last = SELF_DESTRUCT_LAST_TICK.get(uuid);
					if (last != null && now - last < cooldown) return;
					boolean fired = false;
					if (chest.getItem() instanceof GemChest) {
						// PE's GemChest.doExplode is gated by ProjectEConfig.offensiveAbilities; fire directly so it
						// bypasses that gate. Red Gem armor uses vanilla TNT size (4.0F) — base of the tier ramp.
						Level lvl = sp.level();
						lvl.explode(sp, sp.getX(), sp.getY(), sp.getZ(), 4.0F, Level.ExplosionInteraction.BLOCK);
						fired = true;
					}
					else if (chest.getItem() instanceof PinkGemChestplate) { PinkGemChestplate.doExplode(sp); fired = true; }
					else if (chest.getItem() instanceof PurpleGemChestplate) { PurpleGemChestplate.doExplode(sp); fired = true; }
					else if (chest.getItem() instanceof BlueGemChestplate) { BlueGemChestplate.doExplode(sp); fired = true; }
					else if (chest.getItem() instanceof CyanGemChestplate) { CyanGemChestplate.doExplode(sp); fired = true; }
					else if (chest.getItem() instanceof GreenGemChestplate) { GreenGemChestplate.doExplode(sp); fired = true; }
					else if (chest.getItem() instanceof LimeGemChestplate) { LimeGemChestplate.doExplode(sp); fired = true; }
					else if (chest.getItem() instanceof YellowGemChestplate) { YellowGemChestplate.doExplode(sp); fired = true; }
					else if (chest.getItem() instanceof OrangeGemChestplate) { OrangeGemChestplate.doExplode(sp); fired = true; }
					else if (chest.getItem() instanceof WhiteGemChestplate) { WhiteGemChestplate.doExplode(sp); fired = true; }
					else if (chest.getItem() instanceof FadingChestplate) { FadingChestplate.doExplode(sp); fired = true; }
					if (fired) SELF_DESTRUCT_LAST_TICK.put(uuid, now);
				}
			}
		});
		ctx.setPacketHandled(true);
	}
}
