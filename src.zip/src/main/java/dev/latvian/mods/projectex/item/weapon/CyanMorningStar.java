package dev.latvian.mods.projectex.item.weapon;
import com.google.common.collect.Multimap;
import dev.latvian.mods.projectex.util.TierDamage;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.item.ItemStack;
import moze_intel.projecte.gameObjs.EnumMatterType;
import moze_intel.projecte.gameObjs.items.tools.PEMorningStar;
import net.minecraft.world.item.Item;
public class CyanMorningStar extends PEMorningStar {
	public CyanMorningStar(Item.Properties props) { super(EnumMatterType.RED_MATTER, 3, props); }

	@Override
	public Multimap<Attribute, AttributeModifier> getAttributeModifiers(EquipmentSlot slot, ItemStack stack) {
		return TierDamage.boost(super.getAttributeModifiers(slot, stack), slot, 6.0F);
	}
}
