package dev.latvian.mods.projectex.util;

import java.math.BigInteger;

public final class EmcAbbrev {
	private static final String[] SUFFIXES = {"M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc"};

	private EmcAbbrev() {}

	public static String format(BigInteger v) {
		if (v.signum() < 0) return "-" + format(v.negate());
		String s = v.toString();
		int len = s.length();
		if (len <= 6) return String.format("%,d", v);
		int idx = (len - 1) / 3 - 2;
		if (idx >= SUFFIXES.length) idx = SUFFIXES.length - 1;
		int exp = (idx + 2) * 3;
		BigInteger divisor = BigInteger.TEN.pow(exp);
		BigInteger[] qr = v.divideAndRemainder(divisor);
		BigInteger whole = qr[0];
		BigInteger decimal = qr[1].multiply(BigInteger.valueOf(100)).divide(divisor);
		int d = decimal.intValue();
		if (d == 0) {
			return whole.toString() + SUFFIXES[idx];
		}
		String decStr = String.format("%02d", d);
		if (decStr.endsWith("0")) decStr = decStr.substring(0, 1);
		return whole.toString() + "." + decStr + SUFFIXES[idx];
	}

	public static String format(Number n) {
		if (n instanceof BigInteger bi) return format(bi);
		return format(new BigInteger(n.toString()));
	}
}
