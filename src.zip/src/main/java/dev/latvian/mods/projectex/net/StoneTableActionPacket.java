package dev.latvian.mods.projectex.net;

import dev.latvian.mods.projectex.menu.ArcaneTabletMenu;
import dev.latvian.mods.projectex.menu.StoneTableMenu;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public record StoneTableActionPacket(int action, ItemStack target) {
	public static void encode(StoneTableActionPacket pkt, FriendlyByteBuf buf) {
		buf.writeVarInt(pkt.action);
		buf.writeItem(pkt.target);
	}

	public static StoneTableActionPacket decode(FriendlyByteBuf buf) {
		return new StoneTableActionPacket(buf.readVarInt(), buf.readItem());
	}

	public static void handle(StoneTableActionPacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
		NetworkEvent.Context ctx = ctxSupplier.get();
		ctx.enqueueWork(() -> {
			ServerPlayer sender = ctx.getSender();
			if (sender == null) {
				return;
			}
			if (sender.containerMenu instanceof StoneTableMenu menu) {
				menu.handleAction(pkt.action, pkt.target);
			} else if (sender.containerMenu instanceof ArcaneTabletMenu am) {
				am.handleAction(pkt.action, pkt.target);
			}
		});
		ctx.setPacketHandled(true);
	}
}
