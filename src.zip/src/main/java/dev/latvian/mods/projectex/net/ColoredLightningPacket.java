package dev.latvian.mods.projectex.net;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

// S2C: tells client "bolt with this UUID should render in this ARGB color".
// Forge's getPersistentData() doesn't sync across the entity spawn packet, so we sync via a custom
// packet sent to all clients tracking the bolt's chunk.
public record ColoredLightningPacket(UUID boltUuid, int color) {
	public static void encode(ColoredLightningPacket p, FriendlyByteBuf buf) {
		buf.writeUUID(p.boltUuid);
		buf.writeInt(p.color);
	}

	public static ColoredLightningPacket decode(FriendlyByteBuf buf) {
		return new ColoredLightningPacket(buf.readUUID(), buf.readInt());
	}

	public static void handle(ColoredLightningPacket pkt, Supplier<NetworkEvent.Context> ctxSup) {
		NetworkEvent.Context ctx = ctxSup.get();
		ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
				() -> () -> dev.latvian.mods.projectex.client.ColoredLightningRegistry.set(pkt.boltUuid, pkt.color)));
		ctx.setPacketHandled(true);
	}
}
