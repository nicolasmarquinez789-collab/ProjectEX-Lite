package dev.latvian.mods.projectex.net;

import dev.latvian.mods.projectex.ProjectEX;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ProjectEXNet {
	private static final String VERSION = "1";

	public static final SimpleChannel CHANNEL = NetworkRegistry.ChannelBuilder
			.named(new ResourceLocation(ProjectEX.MOD_ID, "main"))
			.networkProtocolVersion(() -> VERSION)
			.clientAcceptedVersions(VERSION::equals)
			.serverAcceptedVersions(VERSION::equals)
			.simpleChannel();

	private ProjectEXNet() {
	}

	public static void init() {
		int id = 0;
		CHANNEL.registerMessage(id++,
				StoneTableActionPacket.class,
				StoneTableActionPacket::encode,
				StoneTableActionPacket::decode,
				StoneTableActionPacket::handle);
		CHANNEL.registerMessage(id++,
				ArcaneTabletTransferPacket.class,
				ArcaneTabletTransferPacket::encode,
				ArcaneTabletTransferPacket::decode,
				ArcaneTabletTransferPacket::handle);
		CHANNEL.registerMessage(id++,
				MagentaArmorTogglePacket.class,
				MagentaArmorTogglePacket::encode,
				MagentaArmorTogglePacket::decode,
				MagentaArmorTogglePacket::handle);
		CHANNEL.registerMessage(id++,
				MagentaGemAbilityPacket.class,
				MagentaGemAbilityPacket::encode,
				MagentaGemAbilityPacket::decode,
				MagentaGemAbilityPacket::handle);
		CHANNEL.registerMessage(id++,
				ColoredLightningPacket.class,
				ColoredLightningPacket::encode,
				ColoredLightningPacket::decode,
				ColoredLightningPacket::handle);
	}

	public static void sendToServer(StoneTableActionPacket pkt) {
		CHANNEL.send(PacketDistributor.SERVER.noArg(), pkt);
	}

	public static void sendToServer(ArcaneTabletTransferPacket pkt) {
		CHANNEL.send(PacketDistributor.SERVER.noArg(), pkt);
	}

	public static void sendToServer(MagentaArmorTogglePacket pkt) {
		CHANNEL.send(PacketDistributor.SERVER.noArg(), pkt);
	}

	public static void sendToServer(MagentaGemAbilityPacket pkt) {
		CHANNEL.send(PacketDistributor.SERVER.noArg(), pkt);
	}
}
