package dev.latvian.mods.projectex.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.latvian.mods.projectex.client.ColoredLightningRegistry;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LightningBoltRenderer;
import net.minecraft.world.entity.LightningBolt;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

// Tint vanilla LightningBolt rendering to the color stored on the bolt by LightningZap. Uses SRG
// names with remap = false since the build has no refmap generator.
//
//  - m_7392_  = EntityRenderer.render (instance method) — sets/clears the color ThreadLocal
//  - m_115272_ = LightningBoltRenderer's private static segment-draw helper — does the actual
//                VertexConsumer.color (m_85950_) calls. Redirect lives here and is static
//                because the enclosing target is static.
@Mixin(LightningBoltRenderer.class)
public class LightningBoltRendererMixin {
	private static final ThreadLocal<Integer> projectex$activeColor = ThreadLocal.withInitial(() -> 0);

	@Inject(method = "m_7392_(Lnet/minecraft/world/entity/LightningBolt;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
			at = @At("HEAD"), remap = false)
	private void projectex$capture(LightningBolt entity, float yaw, float partialTick, PoseStack pose, MultiBufferSource buffer, int packedLight, CallbackInfo ci) {
		int c = ColoredLightningRegistry.get(entity.getUUID());
		projectex$activeColor.set(c);
	}

	@Inject(method = "m_7392_(Lnet/minecraft/world/entity/LightningBolt;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
			at = @At("RETURN"), remap = false)
	private void projectex$clear(LightningBolt entity, float yaw, float partialTick, PoseStack pose, MultiBufferSource buffer, int packedLight, CallbackInfo ci) {
		projectex$activeColor.set(0);
	}

	@Redirect(method = "m_115272_(Lorg/joml/Matrix4f;Lcom/mojang/blaze3d/vertex/VertexConsumer;FFIFFFFFFFZZZZ)V",
			at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/VertexConsumer;m_85950_(FFFF)Lcom/mojang/blaze3d/vertex/VertexConsumer;"),
			remap = false)
	private static VertexConsumer projectex$tint(VertexConsumer vc, float r, float g, float b, float a) {
		int color = projectex$activeColor.get();
		if (color == 0) return vc.color(r, g, b, a);
		float tr = ((color >> 16) & 0xFF) / 255.0F;
		float tg = ((color >> 8) & 0xFF) / 255.0F;
		float tb = (color & 0xFF) / 255.0F;
		return vc.color(tr, tg, tb, a);
	}
}
