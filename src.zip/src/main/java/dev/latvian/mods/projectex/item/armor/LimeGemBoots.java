package dev.latvian.mods.projectex.item.armor;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import moze_intel.projecte.gameObjs.items.IFlightProvider;
import moze_intel.projecte.gameObjs.items.IStepAssister;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraftforge.fml.DistExecutor;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

public class LimeGemBoots extends LimeGemArmorBase implements IFlightProvider, IStepAssister {
	private static final UUID SPEED_MODIFIER = UUID.fromString("F2C7B85A-9D43-4E11-8C20-1A2B3D4E5F61");
	private static final String STEP_TAG = "StepAssist";
	private final Multimap<Attribute, AttributeModifier> attributes;
	public static boolean isStepAssistEnabled(ItemStack boots) {
		if (!boots.hasTag()) return true;
		CompoundTag tag = boots.getTag();
		return !tag.contains(STEP_TAG) || tag.getBoolean(STEP_TAG);
	}
	public static void toggleStepAssist(ItemStack boots, Player player) {
		CompoundTag tag = boots.getOrCreateTag();
		boolean current = !tag.contains(STEP_TAG) || tag.getBoolean(STEP_TAG);
		boolean newValue = !current;
		tag.putBoolean(STEP_TAG, newValue);
		ChatFormatting color = newValue ? ChatFormatting.GREEN : ChatFormatting.RED;
		player.displayClientMessage(Component.literal("Step Assist: ").append(Component.literal(newValue ? "ON" : "OFF").withStyle(color)), true);
	}
	public LimeGemBoots(Item.Properties props) {
		super(ArmorItem.Type.BOOTS, props);
		ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = ImmutableMultimap.builder();
		builder.putAll(getDefaultAttributeModifiers(EquipmentSlot.FEET));
		builder.put(Attributes.MOVEMENT_SPEED, new AttributeModifier(SPEED_MODIFIER, "Lime Gem speed", 5.0, AttributeModifier.Operation.MULTIPLY_TOTAL));
		attributes = builder.build();
	}
	@NotNull @Override
	public Multimap<Attribute, AttributeModifier> getAttributeModifiers(@NotNull EquipmentSlot slot, ItemStack stack) {
		return slot == EquipmentSlot.FEET ? attributes : super.getAttributeModifiers(slot, stack);
	}
	@Override
	public void onArmorTick(ItemStack stack, Level level, Player player) {
		if (!level.isClientSide()) {
			if (player instanceof ServerPlayer sp) sp.fallDistance = 0.0F;
			return;
		}
		if (isStepAssistEnabled(stack) && !player.isShiftKeyDown() && !player.getAbilities().flying) tryWalkOnLiquid(player, level);
		if (!player.getAbilities().flying && isJumpHeld()) player.setDeltaMovement(player.getDeltaMovement().add(0.0, 0.1, 0.0));
		if (!player.onGround() && !player.getAbilities().flying) {
			if (player.getDeltaMovement().y <= 0.0) player.setDeltaMovement(player.getDeltaMovement().multiply(1.0, 0.9, 1.0));
			float forward = player.zza;
			if (forward < 0.0F) player.setDeltaMovement(player.getDeltaMovement().multiply(0.9, 1.0, 0.9));
			else if (forward > 0.0F && player.getDeltaMovement().lengthSqr() < 3.0) player.setDeltaMovement(player.getDeltaMovement().multiply(1.1, 1.0, 1.1));
		}
	}
	private static void tryWalkOnLiquid(Player player, Level level) {
		BlockPos feetPos = BlockPos.containing(player.getX(), player.getY() - 0.05, player.getZ());
		BlockState belowState = level.getBlockState(feetPos);
		FluidState fluid = belowState.getFluidState();
		if (fluid.isEmpty()) return;
		double surfaceY = feetPos.getY() + fluid.getHeight(level, feetPos);
		if (player.getY() < surfaceY) player.setPos(player.getX(), surfaceY, player.getZ());
		if (player.getDeltaMovement().y < 0.0) player.setDeltaMovement(player.getDeltaMovement().x, 0.0, player.getDeltaMovement().z);
		player.setOnGround(true);
		player.fallDistance = 0.0F;
	}
	private static boolean isJumpHeld() {
		return DistExecutor.unsafeRunForDist(() -> () -> Minecraft.getInstance().options.keyJump.isDown(), () -> () -> Boolean.FALSE);
	}
	@Override
	public boolean canProvideFlight(ItemStack stack, ServerPlayer player) {
		return player.getItemBySlot(EquipmentSlot.FEET) == stack;
	}
	@Override
	public boolean canAssistStep(ItemStack stack, ServerPlayer player) {
		return player.getItemBySlot(EquipmentSlot.FEET) == stack && isStepAssistEnabled(stack);
	}
}
