package dev.latvian.mods.projectex.item.armor;

import moze_intel.projecte.handlers.InternalTimers;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class GreenGemHelmet extends GreenGemArmorBase {
	private static final String NV_TAG = "NightVision";
	public GreenGemHelmet(Item.Properties props) { super(ArmorItem.Type.HELMET, props); }

	public static boolean isNightVisionEnabled(ItemStack helm) { return helm.hasTag() && helm.getTag().getBoolean(NV_TAG); }

	public static void toggleNightVision(ItemStack helm, Player player) {
		CompoundTag tag = helm.getOrCreateTag();
		boolean newValue = !tag.getBoolean(NV_TAG);
		tag.putBoolean(NV_TAG, newValue);
		ChatFormatting color = newValue ? ChatFormatting.GREEN : ChatFormatting.RED;
		player.displayClientMessage(Component.literal("Night Vision: ").append(Component.literal(newValue ? "ON" : "OFF").withStyle(color)), true);
	}

	@Override
	public void onArmorTick(ItemStack stack, Level level, Player player) {
		if (level.isClientSide()) return;
		player.getCapability(InternalTimers.CAPABILITY).ifPresent(timers -> {
			timers.activateHeal();
			if (player.getHealth() < player.getMaxHealth() && timers.canHeal()) player.heal(2.0F);
		});
		if (isNightVisionEnabled(stack)) {
			player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 220, 0, true, false));
		} else {
			player.removeEffect(MobEffects.NIGHT_VISION);
		}
	}

	public static void doZap(ServerPlayer player) {
		dev.latvian.mods.projectex.util.LightningZap.zap(player, 0xFF22AA22, 4.5F);
	}
}
