package dev.latvian.mods.projectex.client.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.latvian.mods.projectex.ProjectEX;
import dev.latvian.mods.projectex.menu.StoneTableMenu;
import dev.latvian.mods.projectex.net.ProjectEXNet;
import dev.latvian.mods.projectex.net.StoneTableActionPacket;
import moze_intel.projecte.api.ItemInfo;
import moze_intel.projecte.api.ProjectEAPI;
import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.proxy.IEMCProxy;
import moze_intel.projecte.utils.TransmutationEMCFormatter;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class StoneTableScreen extends AbstractContainerScreen<StoneTableMenu> {
	private static final ResourceLocation TEXTURE = new ResourceLocation(ProjectEX.MOD_ID, "textures/gui/stone_table.png");
	private static final ResourceLocation ARROW_LEFT_ACTIVE  = new ResourceLocation(ProjectEX.MOD_ID, "textures/gui/stone_arrow_left_active.png");
	private static final ResourceLocation ARROW_RIGHT_ACTIVE = new ResourceLocation(ProjectEX.MOD_ID, "textures/gui/stone_arrow_right_active.png");
	private static final ResourceLocation ARROW_LEFT_FLASH   = new ResourceLocation(ProjectEX.MOD_ID, "textures/gui/stone_arrow_left_flash.png");
	private static final ResourceLocation ARROW_RIGHT_FLASH  = new ResourceLocation(ProjectEX.MOD_ID, "textures/gui/stone_arrow_right_flash.png");

	// 8 ring button top-left positions (in container-local coords), matching the 1.12 layout
	private static final int[][] RING_POS = {
			{80, 28},   // top
			{110, 38},  // upper-right
			{120, 68},  // right
			{110, 98},  // lower-right
			{80, 108},  // bottom
			{50, 98},   // lower-left
			{40, 68},   // left
			{50, 38}    // upper-left
	};

	private EditBox searchField;
	private final List<ItemStack> validItems = new ArrayList<>();
	private int currentPage = 0;
	private String lastFilter = "";
	private int lastKnowledgeSize = -1;

	// Arrow click-flash timing (mirrors ArcaneTabletScreen behavior).
	private static final int ARROW_FLASH_TICKS = 5;
	private long screenTick = 0L;
	private long leftArrowFlashUntil = 0L;
	private long rightArrowFlashUntil = 0L;

	// Combo-style "Learned!" / "Unlearned" animation queue — each learn fires its own entry
	// so multiple learns in a tight burst stack as a rising column of text.
	private static final int TICKS_PER_LETTER = 3;
	private static final int ANIM_HOLD_TICKS = 30;
	private static final int COMBO_STAGGER_TICKS = 4;
	private static final int MAX_ACTIVE_ANIMATIONS = 12;
	private long lastAnimQueueTick = -100L;
	private final java.util.ArrayDeque<LearnAnim> animations = new java.util.ArrayDeque<>();

	private static final class LearnAnim {
		final String kind;
		final String letters;
		final long startTick;
		LearnAnim(String kind, String letters, long startTick) {
			this.kind = kind; this.letters = letters; this.startTick = startTick;
		}
	}

	public StoneTableScreen(StoneTableMenu menu, Inventory inv, Component title) {
		super(menu, inv, title);
		this.imageWidth = 176;
		this.imageHeight = 217;
		this.inventoryLabelY = -10000; // hide default labels; texture has its own visuals
		this.titleLabelY = -10000;
	}

	@Override
	protected void init() {
		super.init();
		this.searchField = new EditBox(this.font, this.leftPos + 58, this.topPos + 6, 90, 10, Component.literal(""));
		this.searchField.setMaxLength(50);
		this.searchField.setBordered(false);
		this.searchField.setVisible(true);
		this.searchField.setTextColor(0xFFFFFF);
		this.searchField.setResponder(this::onSearchChanged);
		this.addRenderableWidget(this.searchField);
		setInitialFocus(this.searchField);
		updateValidItems();
	}

	private void onSearchChanged(String s) {
		if (!s.equals(lastFilter)) {
			lastFilter = s;
			currentPage = 0;
			updateValidItems();
		}
	}

	private void updateValidItems() {
		validItems.clear();
		IKnowledgeProvider provider = menu.provider;
		String filter = searchField == null ? "" : searchField.getValue().toLowerCase().trim();
		IEMCProxy emc = ProjectEAPI.getEMCProxy();

		for (ItemInfo info : provider.getKnowledge()) {
			ItemStack stack = info.createStack();
			if (stack.isEmpty()) {
				continue;
			}
			if (!filter.isEmpty() && !stack.getHoverName().getString().toLowerCase().contains(filter)) {
				continue;
			}
			validItems.add(stack);
		}
		validItems.sort(Comparator.comparingLong(s -> -emc.getValue(s)));
		lastKnowledgeSize = provider.getKnowledge().size();

		int maxPage = Math.max(0, (validItems.size() - 1) / 8);
		if (currentPage > maxPage) {
			currentPage = maxPage;
		}
	}

	@Override
	public void containerTick() {
		super.containerTick();
		screenTick++;
		int currentSize = menu.provider.getKnowledge().size();
		if (currentSize != lastKnowledgeSize) {
			// Trigger learn/unlearn animations on subsequent observations only,
			// so opening the screen doesn't flash every existing entry.
			if (lastKnowledgeSize >= 0) {
				int delta = currentSize - lastKnowledgeSize;
				if (delta > 0) queueAnimations("learned", 8, delta);
				else if (delta < 0) queueAnimations("unlearned", 9, -delta);
			}
			updateValidItems();
		}
	}

	private void queueAnimations(String key, int letterCount, int count) {
		StringBuilder sb = new StringBuilder();
		for (int i = 1; i <= letterCount; i++) {
			sb.append(Component.translatable("transmutation.projecte." + key + "." + i).getString());
		}
		String letters = sb.toString();
		long baseTick = Math.max(screenTick, lastAnimQueueTick + COMBO_STAGGER_TICKS);
		for (int i = 0; i < count; i++) {
			animations.addLast(new LearnAnim(key, letters, baseTick + (long) i * COMBO_STAGGER_TICKS));
			while (animations.size() > MAX_ACTIVE_ANIMATIONS) animations.removeFirst();
		}
		lastAnimQueueTick = baseTick + (long) (count - 1) * COMBO_STAGGER_TICKS;
	}

	private void renderLearnAnimation(GuiGraphics graphics) {
		if (animations.isEmpty()) return;
		float scale = 1.6F;
		java.util.Iterator<LearnAnim> it = animations.iterator();
		while (it.hasNext()) {
			LearnAnim a = it.next();
			long elapsed = screenTick - a.startTick;
			if (elapsed < 0) continue;
			int totalLetters = a.letters.length();
			int revealTicks = totalLetters * TICKS_PER_LETTER;
			long lifetime = revealTicks + ANIM_HOLD_TICKS;
			if (elapsed >= lifetime) { it.remove(); continue; }
			int shown = Math.min(totalLetters, (int) (elapsed / TICKS_PER_LETTER) + 1);
			String visible = a.letters.substring(0, shown);
			float alpha = 1.0F;
			if (elapsed > revealTicks) {
				alpha = 1.0F - ((float) (elapsed - revealTicks) / ANIM_HOLD_TICKS);
				alpha = Math.max(0F, alpha);
			}
			int alphaByte = (int) (alpha * 0xFF) & 0xFF;
			int rgb = "learned".equals(a.kind) ? 0x55FF55 : 0xFF5555;
			int color = (alphaByte << 24) | rgb;
			float scaledW = font.width(visible) * scale;
			float drift = elapsed * 0.6F;
			graphics.pose().pushPose();
			graphics.pose().translate(leftPos + (imageWidth / 2.0F) - scaledW / 2.0F, topPos + 4 - drift, 300);
			graphics.pose().scale(scale, scale, 1F);
			graphics.drawString(font, visible, 0, 0, color, true);
			graphics.pose().popPose();
		}
	}

	@Override
	protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
		graphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight);
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		this.renderBackground(graphics);
		super.render(graphics, mouseX, mouseY, partialTick);

		// render ring item buttons + affordability counts (small text directly below each item)
		List<ItemStack> page = currentPageItems();
		BigInteger emcAvailable = menu.provider.getEmc();
		IEMCProxy emcProxy = ProjectEAPI.getEMCProxy();
		final float countScale = 0.5F;
		for (int i = 0; i < page.size(); i++) {
			int bx = leftPos + RING_POS[i][0];
			int by = topPos + RING_POS[i][1];
			ItemStack stack = page.get(i);
			graphics.renderItem(stack, bx, by);

			long perItem = emcProxy.getValue(stack);
			if (perItem > 0L) {
				BigInteger affordable = emcAvailable.divide(BigInteger.valueOf(perItem));
				String countStr = formatAffordableCount(affordable);
				int textW = font.width(countStr);
				graphics.pose().pushPose();
				graphics.pose().translate(bx + 8.0F - (textW * countScale) / 2.0F, by + 17.0F, 200);
				graphics.pose().scale(countScale, countScale, 1F);
				graphics.drawString(font, countStr, 0, 0, 0xFFFFFF, true);
				graphics.pose().popPose();
			}
		}

		// EMC counter — sits above the GUI, centered, gray, no "EMC" label
		BigInteger emc = menu.provider.getEmc();
		String emcStr = formatBigCount(emc);
		float emcScale = 1.3F;
		float emcScaledW = font.width(emcStr) * emcScale;
		graphics.pose().pushPose();
		graphics.pose().translate(leftPos + (imageWidth / 2.0F) - emcScaledW / 2.0F, topPos - 14, 0);
		graphics.pose().scale(emcScale, emcScale, 1F);
		graphics.drawString(font, emcStr, 0, 0, 0x555555, true);
		graphics.pose().popPose();

		// page indicator on the right (matches EMC counter size)
		int totalPages = Math.max(1, (validItems.size() + 8 - 1) / 8);
		String pageStr = (currentPage + 1) + "/" + totalPages;
		int pageRightEdge = leftPos + imageWidth - 28;
		graphics.pose().pushPose();
		graphics.pose().translate(pageRightEdge - font.width(pageStr) * 0.75F, topPos + 126, 0);
		graphics.pose().scale(0.75F, 0.75F, 1F);
		graphics.drawString(font, pageStr, 0, 0, 0xFFFFFF, true);
		graphics.pose().popPose();

		// Letter-by-letter Learned!/Unlearned text drifting up & fading over the GUI.
		renderLearnAnimation(graphics);

		// Page-nav arrow active overlays — only when navigation in that direction is possible.
		int maxPage = Math.max(0, (validItems.size() - 1) / 8);
		boolean leftActive = currentPage > 0;
		boolean rightActive = currentPage < maxPage;
		if (leftActive) {
			ResourceLocation tex = screenTick < leftArrowFlashUntil ? ARROW_LEFT_FLASH : ARROW_LEFT_ACTIVE;
			graphics.blit(tex, leftPos + 7, topPos + 20, 0, 0, 18, 18, 18, 18);
		}
		if (rightActive) {
			ResourceLocation tex = screenTick < rightArrowFlashUntil ? ARROW_RIGHT_FLASH : ARROW_RIGHT_ACTIVE;
			graphics.blit(tex, leftPos + 151, topPos + 20, 0, 0, 18, 18, 18, 18);
		}

		renderTooltip(graphics, mouseX, mouseY);

		// hover tooltips for ring items
		for (int i = 0; i < page.size(); i++) {
			int bx = leftPos + RING_POS[i][0];
			int by = topPos + RING_POS[i][1];
			if (mouseX >= bx && mouseX < bx + 16 && mouseY >= by && mouseY < by + 16) {
				ItemStack stack = page.get(i);
				List<Component> tooltip = new ArrayList<>(getTooltipFromItem(Minecraft.getInstance(), stack));
				IEMCProxy proxy = ProjectEAPI.getEMCProxy();
				tooltip.add(Component.translatable("Cost: %s EMC", TransmutationEMCFormatter.formatEMC(proxy.getValue(stack))).withStyle(ChatFormatting.GOLD));
				graphics.renderComponentTooltip(font, tooltip, mouseX, mouseY);
			}
		}

		// hover tooltips for action areas (burn click area + arrows)
		if (isOverBurn(mouseX, mouseY) && getSlotUnderMouse() == null) {
			graphics.renderTooltip(font, Component.literal("Burn held item for EMC"), mouseX, mouseY);
		} else if (isOverArrowLeft(mouseX, mouseY)) {
			graphics.renderTooltip(font, Component.literal("Previous page"), mouseX, mouseY);
		} else if (isOverArrowRight(mouseX, mouseY)) {
			graphics.renderTooltip(font, Component.literal("Next page"), mouseX, mouseY);
		}
	}

	private static final BigInteger ONE_MILLION = BigInteger.valueOf(1_000_000L);
	private static final BigInteger ONE_BILLION = BigInteger.valueOf(1_000_000_000L);
	private static final BigInteger ONE_TRILLION = BigInteger.valueOf(1_000_000_000_000L);
	private static final BigInteger ONE_QUADRILLION = BigInteger.valueOf(1_000_000_000_000_000L);
	private static final BigInteger ONE_QUINTILLION = new BigInteger("1000000000000000000");

	private static String formatAffordableCount(BigInteger count) {
		return formatBigCount(count);
	}

	private static String formatBigCount(BigInteger n) {
		if (n.compareTo(ONE_MILLION) < 0) {
			return String.format("%,d", n);
		}
		if (n.compareTo(ONE_BILLION) < 0) return n.divide(ONE_MILLION) + " M";
		if (n.compareTo(ONE_TRILLION) < 0) return n.divide(ONE_BILLION) + " B";
		if (n.compareTo(ONE_QUADRILLION) < 0) return n.divide(ONE_TRILLION) + " T";
		if (n.compareTo(ONE_QUINTILLION) < 0) return n.divide(ONE_QUADRILLION) + " Qa";
		return n.divide(ONE_QUINTILLION) + " Qi";
	}

	private List<ItemStack> currentPageItems() {
		int from = currentPage * 8;
		int to = Math.min(from + 8, validItems.size());
		return validItems.subList(from, to);
	}

	@Override
	protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
		// no default labels; texture has its own decoration
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (searchField.isFocused() && keyCode != 256 /* ESC */) {
			return searchField.keyPressed(keyCode, scanCode, modifiers) || searchField.canConsumeInput();
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean charTyped(char c, int modifiers) {
		if (searchField.isFocused()) {
			return searchField.charTyped(c, modifiers);
		}
		return super.charTyped(c, modifiers);
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		int mx = (int) mouseX;
		int my = (int) mouseY;

		// ring buttons
		List<ItemStack> page = currentPageItems();
		for (int i = 0; i < page.size(); i++) {
			int bx = leftPos + RING_POS[i][0];
			int by = topPos + RING_POS[i][1];
			if (mx >= bx && mx < bx + 16 && my >= by && my < by + 16) {
				ItemStack stack = page.get(i);
				int action;
				if (Screen.hasShiftDown()) {
					action = StoneTableMenu.ACTION_TAKE_STACK_TO_INV;
				} else if (button == 1) {
					action = StoneTableMenu.ACTION_TAKE_STACK;
				} else {
					action = StoneTableMenu.ACTION_TAKE_ONE;
				}
				ProjectEXNet.sendToServer(new StoneTableActionPacket(action, stack));
				playClickSound();
				return true;
			}
		}

		if (isOverBurn(mx, my)) {
			int action = (button == 0) ? StoneTableMenu.ACTION_BURN_ALL : StoneTableMenu.ACTION_BURN;
			ProjectEXNet.sendToServer(new StoneTableActionPacket(action, ItemStack.EMPTY));
			playClickSound();
			return true;
		}
		if (isOverArrowLeft(mx, my)) {
			if (currentPage > 0) {
				currentPage--;
				playClickSound();
				leftArrowFlashUntil = screenTick + ARROW_FLASH_TICKS;
			}
			return true;
		}
		if (isOverArrowRight(mx, my)) {
			int maxPage = Math.max(0, (validItems.size() - 1) / 8);
			if (currentPage < maxPage) {
				currentPage++;
				playClickSound();
				rightArrowFlashUntil = screenTick + ARROW_FLASH_TICKS;
			}
			return true;
		}

		return super.mouseClicked(mouseX, mouseY, button);
	}

	private void playClickSound() {
		Minecraft.getInstance().getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK, 1.0F));
	}

	// hit-boxes match the original 1.12 button positions (16x16 each)
	private boolean isOverBurn(int mx, int my) {
		return mx >= leftPos + 80 && mx < leftPos + 96 && my >= topPos + 68 && my < topPos + 84;
	}

	private boolean isOverArrowLeft(int mx, int my) {
		return mx >= leftPos + 7 && mx < leftPos + 23 && my >= topPos + 20 && my < topPos + 36;
	}

	private boolean isOverArrowRight(int mx, int my) {
		return mx >= leftPos + 151 && mx < leftPos + 167 && my >= topPos + 20 && my < topPos + 36;
	}
}
