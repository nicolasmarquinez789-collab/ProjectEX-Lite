package dev.latvian.mods.projectex.menu;

import moze_intel.projecte.api.ItemInfo;
import moze_intel.projecte.api.ProjectEAPI;
import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.capabilities.PECapabilities;
import moze_intel.projecte.api.capabilities.block_entity.IEmcStorage;
import moze_intel.projecte.api.capabilities.item.IItemEmcHolder;
import moze_intel.projecte.api.proxy.IEMCProxy;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.ItemHandlerHelper;

import java.math.BigInteger;

public class StoneTableMenu extends AbstractContainerMenu {
	public static final int ACTION_TAKE_ONE = 1;
	public static final int ACTION_TAKE_STACK = 2;
	public static final int ACTION_TAKE_STACK_TO_INV = 6;
	public static final int ACTION_BURN = 5;
	public static final int ACTION_BURN_ALL = 7;

	public final Player player;
	public final IKnowledgeProvider provider;
	public final SimpleContainer learnInv;
	public final SimpleContainer unlearnInv;

	private ItemStack lastLearnSeen = ItemStack.EMPTY;
	private ItemStack lastUnlearnSeen = ItemStack.EMPTY;

	public StoneTableMenu(int containerId, Inventory playerInv) {
		this(containerId, playerInv, playerInv.player);
	}

	public StoneTableMenu(int containerId, Inventory playerInv, Player player) {
		super(ProjectEXMenus.STONE_TABLE.get(), containerId);
		this.player = player;
		this.provider = player.getCapability(PECapabilities.KNOWLEDGE_CAPABILITY).orElseThrow(() -> new IllegalStateException("Player has no knowledge capability"));

		this.learnInv = new SimpleContainer(1) {
			@Override
			public void setChanged() {
				super.setChanged();
				onLearnSlotChanged();
			}
		};
		this.unlearnInv = new SimpleContainer(1) {
			@Override
			public void setChanged() {
				super.setChanged();
				onUnlearnSlotChanged();
			}
		};

		// learn slot (idx 0) at the green button position
		addSlot(new Slot(learnInv, 0, 8, 115));
		// unlearn slot (idx 1) at the red button position
		addSlot(new Slot(unlearnInv, 0, 152, 115));

		// player inventory rows (slots 2-28)
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				addSlot(new Slot(playerInv, col + row * 9 + 9, 8 + col * 18, 135 + row * 18));
			}
		}
		// hotbar (slots 29-37)
		for (int col = 0; col < 9; col++) {
			addSlot(new Slot(playerInv, col, 8 + col * 18, 193));
		}
	}

	public static StoneTableMenu fromNetwork(int containerId, Inventory playerInv, FriendlyByteBuf buf) {
		return new StoneTableMenu(containerId, playerInv);
	}

	@Override
	public boolean stillValid(Player player) {
		return true;
	}

	private void onLearnSlotChanged() {
		if (!(player instanceof ServerPlayer sp)) return;
		ItemStack now = learnInv.getItem(0);
		if (ItemStack.matches(now, lastLearnSeen)) return;
		lastLearnSeen = now.copy();
		if (!now.isEmpty()) {
			applyLearn(sp, now);
		}
	}

	private void onUnlearnSlotChanged() {
		if (!(player instanceof ServerPlayer sp)) return;
		ItemStack now = unlearnInv.getItem(0);
		if (ItemStack.matches(now, lastUnlearnSeen)) return;
		lastUnlearnSeen = now.copy();
		if (!now.isEmpty()) {
			applyUnlearn(sp, now);
		}
	}

	private void applyLearn(ServerPlayer sp, ItemStack stack) {
		IEMCProxy emc = ProjectEAPI.getEMCProxy();
		if (emc.getValue(stack) <= 0L) {
			return;
		}
		ItemInfo info = emc.getPersistentInfo(ItemInfo.fromStack(stack));
		if (provider.addKnowledge(info)) {
			provider.syncKnowledgeChange(sp, info, true);
			provider.sync(sp);
		}
	}

	private void applyUnlearn(ServerPlayer sp, ItemStack stack) {
		IEMCProxy emc = ProjectEAPI.getEMCProxy();
		ItemInfo info = emc.getPersistentInfo(ItemInfo.fromStack(stack));
		if (provider.removeKnowledge(info)) {
			provider.syncKnowledgeChange(sp, info, false);
			provider.sync(sp);
		}
	}

	@Override
	public void removed(Player player) {
		super.removed(player);
		if (!player.level().isClientSide()) {
			ItemStack a = learnInv.removeItemNoUpdate(0);
			if (!a.isEmpty()) ItemHandlerHelper.giveItemToPlayer(player, a);
			ItemStack b = unlearnInv.removeItemNoUpdate(0);
			if (!b.isEmpty()) ItemHandlerHelper.giveItemToPlayer(player, b);
		}
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		Slot slot = slots.get(index);
		if (!slot.hasItem()) {
			return ItemStack.EMPTY;
		}
		ItemStack source = slot.getItem();
		ItemStack copy = source.copy();

		// special slots: 0=learn, 1=unlearn; player inv: 2-37
		if (index < 2) {
			// special slot → player inventory
			if (!moveItemStackTo(source, 2, 38, true)) {
				return ItemStack.EMPTY;
			}
			if (source.isEmpty()) {
				slot.set(ItemStack.EMPTY);
			} else {
				slot.setChanged();
			}
			return copy;
		}

		// player inv → burn the whole stack for EMC
		if (player instanceof ServerPlayer sp) {
			burnStackInPlace(sp, slot);
		}
		return ItemStack.EMPTY;
	}

	private void burnStackInPlace(ServerPlayer sp, Slot slot) {
		ItemStack stack = slot.getItem();
		if (stack.isEmpty()) {
			return;
		}
		IEMCProxy emc = ProjectEAPI.getEMCProxy();
		long perItem = emc.getValue(stack);
		if (perItem <= 0L) {
			return;
		}

		ItemInfo info = emc.getPersistentInfo(ItemInfo.fromStack(stack));
		boolean wasNew = !provider.hasKnowledge(info);
		if (wasNew) {
			provider.addKnowledge(info);
		}

		// EMC holder items (Klein/Magnum/Colossal stars): drain stored EMC, OR consume if empty
		boolean isHolder = stack.getCapability(PECapabilities.EMC_HOLDER_ITEM_CAPABILITY).isPresent();
		if (isHolder) {
			IItemEmcHolder holder = stack.getCapability(PECapabilities.EMC_HOLDER_ITEM_CAPABILITY).orElseThrow(() -> new IllegalStateException("missing holder"));
			long stored = holder.getStoredEmc(stack);
			if (stored > 0L) {
				holder.extractEmc(stack, stored, IEmcStorage.EmcAction.EXECUTE);
				provider.setEmc(provider.getEmc().add(BigInteger.valueOf(stored)));
				slot.setChanged();
			} else {
				int count = stack.getCount();
				BigInteger total = BigInteger.valueOf(perItem).multiply(BigInteger.valueOf(count));
				provider.setEmc(provider.getEmc().add(total));
				slot.set(ItemStack.EMPTY);
			}
		} else {
			int count = stack.getCount();
			BigInteger total = BigInteger.valueOf(perItem).multiply(BigInteger.valueOf(count));
			provider.setEmc(provider.getEmc().add(total));
			slot.set(ItemStack.EMPTY);
		}

		provider.syncEmc(sp);
		if (wasNew) {
			provider.syncKnowledgeChange(sp, info, true);
			provider.sync(sp);
		}
	}

	public void handleAction(int action, ItemStack target) {
		if (!(player instanceof ServerPlayer sp)) {
			return;
		}
		switch (action) {
			case ACTION_TAKE_ONE -> takeFromKnowledge(target, 1, false);
			case ACTION_TAKE_STACK -> takeFromKnowledge(target, target.getMaxStackSize(), false);
			case ACTION_TAKE_STACK_TO_INV -> takeFromKnowledge(target, target.getMaxStackSize(), true);
			case ACTION_BURN -> burnCarried(sp, false);
			case ACTION_BURN_ALL -> burnCarried(sp, true);
		}
	}

	private void syncCarriedNow(ServerPlayer sp) {
		sp.connection.send(new net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket(-1, incrementStateId(), 0, getCarried()));
	}

	private void takeFromKnowledge(ItemStack template, int desiredCount, boolean toInventory) {
		if (template.isEmpty() || desiredCount <= 0) {
			return;
		}
		IEMCProxy emc = ProjectEAPI.getEMCProxy();
		long perItem = emc.getValue(template);
		if (perItem <= 0L) {
			return;
		}
		ItemInfo info = ItemInfo.fromStack(template);
		if (!provider.hasKnowledge(info)) {
			return;
		}

		BigInteger available = provider.getEmc();
		BigInteger costPer = BigInteger.valueOf(perItem);
		int maxStack = Math.min(desiredCount, template.getMaxStackSize());
		int affordable = (int) available.divide(costPer).min(BigInteger.valueOf(maxStack)).longValueExact();
		if (affordable <= 0) {
			return;
		}

		ItemStack out = template.copy();
		out.setCount(affordable);
		int actuallyTake = affordable;

		if (toInventory) {
			ItemHandlerHelper.giveItemToPlayer(player, out);
		} else {
			ItemStack carried = getCarried();
			if (!carried.isEmpty() && ItemStack.isSameItemSameTags(carried, out)) {
				int room = carried.getMaxStackSize() - carried.getCount();
				actuallyTake = Math.min(affordable, room);
				if (actuallyTake <= 0) return;
				carried.grow(actuallyTake);
				setCarried(carried);
			} else if (carried.isEmpty()) {
				setCarried(out);
			} else {
				ItemHandlerHelper.giveItemToPlayer(player, out);
			}
			syncCarriedNow((ServerPlayer) player);
		}

		BigInteger totalCost = costPer.multiply(BigInteger.valueOf(actuallyTake));
		provider.setEmc(available.subtract(totalCost));
		provider.syncEmc((ServerPlayer) player);
	}

	private void burnCarried(ServerPlayer sp, boolean entireStack) {
		ItemStack carried = getCarried();
		if (carried.isEmpty()) {
			return;
		}
		IEMCProxy emc = ProjectEAPI.getEMCProxy();
		long value = emc.getValue(carried);
		if (value <= 0L) {
			return;
		}

		ItemInfo info = emc.getPersistentInfo(ItemInfo.fromStack(carried));
		boolean wasNew = !provider.hasKnowledge(info);
		if (wasNew) {
			provider.addKnowledge(info);
		}

		boolean isHolder = carried.getCapability(PECapabilities.EMC_HOLDER_ITEM_CAPABILITY).isPresent();
		if (isHolder) {
			IItemEmcHolder holder = carried.getCapability(PECapabilities.EMC_HOLDER_ITEM_CAPABILITY).orElseThrow(() -> new IllegalStateException("missing holder"));
			long stored = holder.getStoredEmc(carried);
			if (stored > 0L) {
				holder.extractEmc(carried, stored, IEmcStorage.EmcAction.EXECUTE);
				provider.setEmc(provider.getEmc().add(BigInteger.valueOf(stored)));
				setCarried(carried);
			} else {
				int consume = entireStack ? carried.getCount() : 1;
				BigInteger total = BigInteger.valueOf(value).multiply(BigInteger.valueOf(consume));
				provider.setEmc(provider.getEmc().add(total));
				carried.shrink(consume);
				setCarried(carried);
			}
		} else {
			int consume = entireStack ? carried.getCount() : 1;
			BigInteger total = BigInteger.valueOf(value).multiply(BigInteger.valueOf(consume));
			provider.setEmc(provider.getEmc().add(total));
			carried.shrink(consume);
			setCarried(carried);
		}

		provider.syncEmc(sp);
		if (wasNew) {
			provider.syncKnowledgeChange(sp, info, true);
			provider.sync(sp);
		}
		syncCarriedNow(sp);
	}
}
