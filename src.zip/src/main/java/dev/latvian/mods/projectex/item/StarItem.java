package dev.latvian.mods.projectex.item;

import moze_intel.projecte.api.ProjectEAPI;
import moze_intel.projecte.api.capabilities.PECapabilities;
import moze_intel.projecte.api.capabilities.block_entity.IEmcStorage;
import moze_intel.projecte.api.capabilities.item.IItemEmcHolder;
import moze_intel.projecte.api.proxy.IEMCProxy;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class StarItem extends Item implements IItemEmcHolder {
	private static final String EMC_KEY = "StoredEMC";
	private static final int BAR_COLOR = 0x9D5CFF;

	private final long maxEmc;

	public StarItem(long maxEmc, Rarity rarity) {
		super(new Properties().rarity(rarity).stacksTo(1));
		this.maxEmc = maxEmc;
	}

	@Override
	public long getMaximumEmc(@NotNull ItemStack stack) {
		return maxEmc;
	}

	@Override
	public long getStoredEmc(@NotNull ItemStack stack) {
		CompoundTag tag = stack.getTag();
		return tag == null ? 0L : tag.getLong(EMC_KEY);
	}

	private void setStoredEmc(ItemStack stack, long emc) {
		stack.getOrCreateTag().putLong(EMC_KEY, emc);
	}

	@Override
	public long insertEmc(@NotNull ItemStack stack, long amount, @NotNull IEmcStorage.EmcAction action) {
		if (amount <= 0L) {
			return 0L;
		}
		long stored = getStoredEmc(stack);
		long actual = Math.min(amount, maxEmc - stored);
		if (actual > 0L && action.execute()) {
			setStoredEmc(stack, stored + actual);
		}
		return Math.max(actual, 0L);
	}

	@Override
	public long extractEmc(@NotNull ItemStack stack, long amount, @NotNull IEmcStorage.EmcAction action) {
		if (amount <= 0L) {
			return 0L;
		}
		long stored = getStoredEmc(stack);
		long actual = Math.min(amount, stored);
		if (actual > 0L && action.execute()) {
			setStoredEmc(stack, stored - actual);
		}
		return actual;
	}

	@Override
	public boolean isBarVisible(@NotNull ItemStack stack) {
		return getStoredEmc(stack) > 0L;
	}

	@Override
	public int getBarWidth(@NotNull ItemStack stack) {
		long stored = getStoredEmc(stack);
		if (stored <= 0L || maxEmc <= 0L) {
			return 0;
		}
		// integer-safe scaling for very large EMC values
		double ratio = (double) stored / (double) maxEmc;
		return Math.max(1, Math.min(13, (int) Math.round(13.0D * ratio)));
	}

	@Override
	public int getBarColor(@NotNull ItemStack stack) {
		return BAR_COLOR;
	}

	@Override
	public void appendHoverText(@NotNull ItemStack stack, @Nullable Level level, @NotNull List<Component> list, @NotNull TooltipFlag flag) {
		super.appendHoverText(stack, level, list, flag);
		long stored = getStoredEmc(stack);
		list.add(Component.literal(formatEmc(stored) + " / " + formatEmc(maxEmc) + " EMC").withStyle(ChatFormatting.GRAY));
	}

	private static String formatEmc(long emc) {
		if (emc < 1_000L) {
			return String.valueOf(emc);
		}
		if (emc < 1_000_000L) {
			return String.format("%.2fK", emc / 1_000.0);
		}
		if (emc < 1_000_000_000L) {
			return String.format("%.2fM", emc / 1_000_000.0);
		}
		if (emc < 1_000_000_000_000L) {
			return String.format("%.2fB", emc / 1_000_000_000.0);
		}
		if (emc < 1_000_000_000_000_000L) {
			return String.format("%.2fT", emc / 1_000_000_000_000.0);
		}
		return String.format("%.2fQ", emc / 1_000_000_000_000_000.0);
	}

	@Override
	@NotNull
	public InteractionResultHolder<ItemStack> use(@NotNull Level level, @NotNull Player player, @NotNull InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (level.isClientSide()) {
			return InteractionResultHolder.success(stack);
		}

		long stored = getStoredEmc(stack);
		long room = maxEmc - stored;
		if (room <= 0L) {
			return InteractionResultHolder.pass(stack);
		}

		IEMCProxy proxy = ProjectEAPI.getEMCProxy();
		long absorbed = 0L;

		for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
			ItemStack inv = player.getInventory().getItem(i);
			if (inv.isEmpty() || inv == stack) {
				continue;
			}
			long emcPer = proxy.getValue(inv);
			if (emcPer <= 0L) {
				continue;
			}

			long remainingRoom = room - absorbed;
			if (remainingRoom <= 0L) {
				break;
			}
			int toAbsorb = (int) Math.min(inv.getCount(), remainingRoom / emcPer);
			if (toAbsorb <= 0) {
				continue;
			}

			absorbed += emcPer * (long) toAbsorb;
			inv.shrink(toAbsorb);
		}

		if (absorbed > 0L) {
			setStoredEmc(stack, stored + absorbed);
			return InteractionResultHolder.success(stack);
		}
		return InteractionResultHolder.pass(stack);
	}

	@Nullable
	@Override
	public ICapabilityProvider initCapabilities(ItemStack stack, @Nullable CompoundTag nbt) {
		return new EmcCapProvider(this);
	}

	private static final class EmcCapProvider implements ICapabilityProvider {
		private final LazyOptional<IItemEmcHolder> opt;

		EmcCapProvider(IItemEmcHolder holder) {
			this.opt = LazyOptional.of(() -> holder);
		}

		@NotNull
		@Override
		public <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
			return cap == PECapabilities.EMC_HOLDER_ITEM_CAPABILITY ? opt.cast() : LazyOptional.empty();
		}
	}
}
