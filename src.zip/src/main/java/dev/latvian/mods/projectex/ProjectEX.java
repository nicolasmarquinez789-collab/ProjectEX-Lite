package dev.latvian.mods.projectex;

import dev.latvian.mods.projectex.block.ProjectEXBlocks;
import dev.latvian.mods.projectex.block.entity.ProjectEXBlockEntities;
import dev.latvian.mods.projectex.item.ProjectEXItems;
import dev.latvian.mods.projectex.menu.ProjectEXMenus;
import dev.latvian.mods.projectex.net.ProjectEXNet;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

@Mod(ProjectEX.MOD_ID)
public class ProjectEX {
	public static final String MOD_ID = "projectex";

	public static final Direction[] DIRECTIONS = Direction.values();

	public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

	public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () -> CreativeModeTab.builder()
			.title(Component.translatable("itemGroup.projectex"))
			.icon(() -> new ItemStack(ProjectEXItems.PERSONAL_LINK.get()))
			.displayItems((params, output) -> {
				ProjectEXItems.REGISTRY.getEntries().forEach(reg -> output.accept(reg.get()));
			})
			.build());

	public ProjectEX() {
		var bus = FMLJavaModLoadingContext.get().getModEventBus();
		ProjectEXBlocks.REGISTRY.register(bus);
		ProjectEXItems.REGISTRY.register(bus);
		ProjectEXBlockEntities.REGISTRY.register(bus);
		ProjectEXMenus.REGISTRY.register(bus);
		TABS.register(bus);
		bus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(ProjectEXNet::init));
	}
}
