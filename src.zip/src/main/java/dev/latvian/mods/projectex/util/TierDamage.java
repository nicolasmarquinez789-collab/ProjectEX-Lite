package dev.latvian.mods.projectex.util;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

import java.util.UUID;

// Bump the vanilla ATTACK_DAMAGE modifier (the one keyed by Item.BASE_ATTACK_DAMAGE_UUID) by a
// flat per-tier amount when the item is held in main-hand. Other modifiers, equipment slots, and
// any extra ATTACK_DAMAGE modifiers PE attaches are passed through untouched.
public final class TierDamage {
	// Same value as Item.BASE_ATTACK_DAMAGE_UUID (which is protected so we can't import it).
	// This UUID is a stable vanilla constant.
	private static final UUID BASE_ATTACK_DAMAGE_UUID = UUID.fromString("CB3F55D3-645C-4F38-A497-9C13A33DB5CF");

	private TierDamage() {}

	public static Multimap<Attribute, AttributeModifier> boost(
			Multimap<Attribute, AttributeModifier> base, EquipmentSlot slot, float bonus) {
		if (slot != EquipmentSlot.MAINHAND || bonus == 0F) return base;
		HashMultimap<Attribute, AttributeModifier> out = HashMultimap.create();
		for (var entry : base.entries()) {
			AttributeModifier mod = entry.getValue();
			if (entry.getKey() == Attributes.ATTACK_DAMAGE
					&& BASE_ATTACK_DAMAGE_UUID.equals(mod.getId())) {
				out.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(
						mod.getId(), mod.getName(), mod.getAmount() + bonus, mod.getOperation()));
			} else {
				out.put(entry.getKey(), mod);
			}
		}
		return out;
	}
}
