package dev.latvian.mods.projectex.item;

import dev.latvian.mods.projectex.menu.ArcaneTabletMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;
import org.jetbrains.annotations.NotNull;

public class ArcaneTabletItem extends Item {
	private static final Component TITLE = Component.translatable("item.projectex.arcane_tablet");

	public ArcaneTabletItem() {
		super(new Properties().rarity(Rarity.RARE).stacksTo(1));
	}

	@Override
	@NotNull
	public InteractionResultHolder<ItemStack> use(@NotNull Level level, @NotNull Player player, @NotNull InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (!level.isClientSide() && player instanceof ServerPlayer sp) {
			MenuProvider provider = new SimpleMenuProvider(
					(id, inv, p) -> new ArcaneTabletMenu(id, inv, p),
					TITLE
			);
			NetworkHooks.openScreen(sp, provider);
		}
		return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
	}
}
