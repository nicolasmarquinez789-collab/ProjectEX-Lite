package dev.latvian.mods.projectex.mixin;

import dev.latvian.mods.projectex.util.EmcAbbrev;
import moze_intel.projecte.config.ProjectEConfig;
import moze_intel.projecte.utils.EMCHelper;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.math.BigInteger;

@Mixin(EMCHelper.class)
public class EMCHelperMixin {
	@Inject(method = "getEmcTextComponent(JI)Lnet/minecraft/network/chat/Component;", at = @At("HEAD"), cancellable = true, remap = false)
	private static void projectex$abbreviate(long emc, int stackSize, CallbackInfoReturnable<Component> cir) {
		if (Screen.hasShiftDown()) {
			return;
		}
		boolean isStack = stackSize > 1;
		BigInteger total = BigInteger.valueOf(emc).multiply(BigInteger.valueOf(Math.max(stackSize, 1)));
		String formatted = EmcAbbrev.format(isStack ? total : BigInteger.valueOf(emc));

		double loss = ProjectEConfig.server.difficulty.covalenceLoss.get();
		boolean withSell = loss != 1.0;

		Component result;
		if (withSell) {
			long sell = EMCHelper.getEmcSellValue(emc);
			BigInteger sellTotal = BigInteger.valueOf(sell).multiply(BigInteger.valueOf(Math.max(stackSize, 1)));
			String sellFormatted = EmcAbbrev.format(isStack ? sellTotal : BigInteger.valueOf(sell));
			String key = isStack ? "emc.projecte.tooltip.stack.with_sell" : "emc.projecte.tooltip.with_sell";
			result = Component.translatable(key,
					Component.literal(formatted).withStyle(ChatFormatting.WHITE),
					Component.literal(sellFormatted).withStyle(ChatFormatting.WHITE))
					.withStyle(ChatFormatting.YELLOW);
		} else {
			String key = isStack ? "emc.projecte.tooltip.stack" : "emc.projecte.tooltip";
			result = Component.translatable(key,
					Component.literal(formatted).withStyle(ChatFormatting.WHITE))
					.withStyle(ChatFormatting.YELLOW);
		}
		cir.setReturnValue(result);
	}
}
