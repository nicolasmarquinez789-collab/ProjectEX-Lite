package dev.latvian.mods.projectex.item;

import net.minecraft.world.item.ItemStack;

public class FoilItem extends BasicItem {
	@Override
	public boolean isFoil(ItemStack stack) {
		return true;
	}
}
