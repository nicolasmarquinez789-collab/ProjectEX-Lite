package dev.latvian.mods.projectex.block;

import dev.latvian.mods.projectex.menu.StoneTableMenu;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.network.NetworkHooks;
import org.jetbrains.annotations.NotNull;

public class StoneTableBlock extends Block {
	public static final VoxelShape[] SHAPE = new VoxelShape[]{
			box(0, 0, 0, 16, 4, 16),
			box(0, 12, 0, 16, 16, 16),
			box(0, 0, 0, 16, 16, 4),
			box(0, 0, 12, 16, 16, 16),
			box(0, 0, 0, 4, 16, 16),
			box(12, 0, 0, 16, 16, 16)
	};

	private static final Component TITLE = Component.translatable("block.projectex.stone_table");

	public StoneTableBlock() {
		super(Properties.of().mapColor(MapColor.STONE).strength(1F).sound(SoundType.STONE).noOcclusion());
		registerDefaultState(getStateDefinition().any().setValue(BlockStateProperties.FACING, Direction.DOWN));
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(BlockStateProperties.FACING);
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
		return SHAPE[state.getValue(BlockStateProperties.FACING).ordinal()];
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext ctx) {
		return defaultBlockState().setValue(BlockStateProperties.FACING, ctx.getClickedFace().getOpposite());
	}

	@Override
	@NotNull
	public InteractionResult use(@NotNull BlockState state, @NotNull Level level, @NotNull BlockPos pos, @NotNull Player player, @NotNull InteractionHand hand, @NotNull BlockHitResult hit) {
		if (!level.isClientSide() && player instanceof ServerPlayer sp) {
			MenuProvider provider = new SimpleMenuProvider(
					(id, inv, p) -> new StoneTableMenu(id, inv, p),
					TITLE
			);
			NetworkHooks.openScreen(sp, provider);
		}
		return InteractionResult.sidedSuccess(level.isClientSide());
	}
}
