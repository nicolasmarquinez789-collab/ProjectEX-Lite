package dev.latvian.mods.projectex.block.entity;

import dev.latvian.mods.projectex.ProjectEX;
import dev.latvian.mods.projectex.block.ProjectEXBlocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public interface ProjectEXBlockEntities {
	DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, ProjectEX.MOD_ID);

	RegistryObject<BlockEntityType<EnergyLinkBlockEntity>> ENERGY_LINK = REGISTRY.register("energy_link",
			() -> BlockEntityType.Builder.of(EnergyLinkBlockEntity::new, ProjectEXBlocks.ENERGY_LINK.get()).build(null));

	RegistryObject<BlockEntityType<PersonalLinkBlockEntity>> PERSONAL_LINK = REGISTRY.register("personal_link",
			() -> BlockEntityType.Builder.of(PersonalLinkBlockEntity::new, ProjectEXBlocks.PERSONAL_LINK.get()).build(null));

	RegistryObject<BlockEntityType<RefinedLinkBlockEntity>> REFINED_LINK = REGISTRY.register("refined_link",
			() -> BlockEntityType.Builder.of(RefinedLinkBlockEntity::new, ProjectEXBlocks.REFINED_LINK.get()).build(null));

	RegistryObject<BlockEntityType<CompressedRefinedLinkBlockEntity>> COMPRESSED_REFINED_LINK = REGISTRY.register("compressed_refined_link",
			() -> BlockEntityType.Builder.of(CompressedRefinedLinkBlockEntity::new, ProjectEXBlocks.COMPRESSED_REFINED_LINK.get()).build(null));

	RegistryObject<BlockEntityType<CollectorBlockEntity>> COLLECTOR = REGISTRY.register("collector",
			() -> BlockEntityType.Builder.of(CollectorBlockEntity::new,
					ProjectEXBlocks.COLLECTOR.values().stream().map(RegistryObject::get).toArray(Block[]::new)).build(null));

	RegistryObject<BlockEntityType<RelayBlockEntity>> RELAY = REGISTRY.register("relay",
			() -> BlockEntityType.Builder.of(RelayBlockEntity::new,
					ProjectEXBlocks.RELAY.values().stream().map(RegistryObject::get).toArray(Block[]::new)).build(null));

	RegistryObject<BlockEntityType<PowerFlowerBlockEntity>> POWER_FLOWER = REGISTRY.register("power_flower",
			() -> BlockEntityType.Builder.of(PowerFlowerBlockEntity::new,
					ProjectEXBlocks.POWER_FLOWER.values().stream().map(RegistryObject::get).toArray(Block[]::new)).build(null));
}
