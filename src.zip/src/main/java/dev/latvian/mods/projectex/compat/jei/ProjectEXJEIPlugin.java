package dev.latvian.mods.projectex.compat.jei;

import dev.latvian.mods.projectex.ProjectEX;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.registration.IRecipeTransferRegistration;
import net.minecraft.resources.ResourceLocation;

@JeiPlugin
public class ProjectEXJEIPlugin implements IModPlugin {
	private static final ResourceLocation UID = new ResourceLocation(ProjectEX.MOD_ID, "main");

	@Override
	public ResourceLocation getPluginUid() {
		return UID;
	}

	@Override
	public void registerRecipeTransferHandlers(IRecipeTransferRegistration registration) {
		registration.addRecipeTransferHandler(new ArcaneTabletTransferHandler(), mezz.jei.api.constants.RecipeTypes.CRAFTING);
	}
}
