package dev.latvian.mods.projectex.util;

import dev.latvian.mods.projectex.item.weapon.BlueKatar;
import dev.latvian.mods.projectex.item.weapon.CyanKatar;
import dev.latvian.mods.projectex.item.weapon.FadingKatar;
import dev.latvian.mods.projectex.item.weapon.GreenKatar;
import dev.latvian.mods.projectex.item.weapon.LimeKatar;
import dev.latvian.mods.projectex.item.weapon.OrangeKatar;
import dev.latvian.mods.projectex.item.weapon.PinkKatar;
import dev.latvian.mods.projectex.item.weapon.PurpleKatar;
import dev.latvian.mods.projectex.item.weapon.WhiteKatar;
import dev.latvian.mods.projectex.item.weapon.YellowKatar;
import moze_intel.projecte.api.capabilities.PECapabilities;
import moze_intel.projecte.gameObjs.items.ItemPE;
import moze_intel.projecte.gameObjs.items.tools.PEKatar;
import moze_intel.projecte.gameObjs.registries.PEDamageTypes;
import moze_intel.projecte.utils.PlayerHelper;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

import java.util.List;
import java.util.function.Predicate;

// Reimplements PE's PEKatar.doExtraFunction + ToolHelper.attackAOE with per-tier damage and
// per-tier AABB-inflation multiplier. Hits every entity in range (no cap).
//
// Damage and range curves chosen by the user:
//   damage per entity:  RM 1000 → Fading 3500 (+250/tier)
//   range multiplier:   RM 2.5  → Fading 5.0  (ramped)
public final class KatarAbility {
	private KatarAbility() {}

	public static boolean swing(ServerPlayer player, ItemStack stack, InteractionHand hand) {
		Level level = player.level();
		if (level.isClientSide()) return false;
		// PE's gate: only fire when the attack cooldown is fully charged.
		if (player.getAttackStrengthScale(0F) != 1.0F) return false;

		Item itemRef = stack.getItem();
		if (!(itemRef instanceof PEKatar)) return false;

		float damage = damageFor(itemRef);
		float inflation = inflationFor(itemRef);
		int charge = stack.getCapability(PECapabilities.CHARGE_ITEM_CAPABILITY)
				.map(c -> c.getCharge(stack)).orElse(0);
		boolean slayAll = stack.getCapability(PECapabilities.MODE_CHANGER_ITEM_CAPABILITY)
				.map(m -> m.getMode(stack)).orElse((byte) 0) == 1;

		AABB box = player.getBoundingBox().inflate(inflation * (float) charge);
		Predicate<Entity> filter = slayAll
				? e -> e instanceof LivingEntity
				: e -> e instanceof Monster;
		List<Entity> targets = level.getEntities(player, box, filter);

		DamageSource source = PEDamageTypes.BYPASS_ARMOR_PLAYER_ATTACK.source(player);
		boolean hit = false;
		for (Entity target : targets) {
			// emcCost = 0 matches PE's behavior; consumeFuel still runs the bookkeeping path.
			if (ItemPE.consumeFuel(player, stack, 0L, true)) {
				target.hurt(source, damage);
				hit = true;
			}
		}

		if (hit) {
			level.playSound(null, player.getX(), player.getY(), player.getZ(),
					SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.6F, 1.6F);
			PlayerHelper.swingItem(player, hand);
			PlayerHelper.resetCooldown(player);
		}
		return hit;
	}

	private static float damageFor(Item item) {
		if (item instanceof FadingKatar) return 3500F;
		if (item instanceof WhiteKatar)  return 3250F;
		if (item instanceof OrangeKatar) return 3000F;
		if (item instanceof YellowKatar) return 2750F;
		if (item instanceof LimeKatar)   return 2500F;
		if (item instanceof GreenKatar)  return 2250F;
		if (item instanceof CyanKatar)   return 2000F;
		if (item instanceof BlueKatar)   return 1750F;
		if (item instanceof PurpleKatar) return 1500F;
		if (item instanceof PinkKatar)   return 1250F;
		// PE's plain PEKatar (Red Matter) — baseline.
		return 1000F;
	}

	private static float inflationFor(Item item) {
		if (item instanceof FadingKatar) return 5.00F;
		if (item instanceof WhiteKatar)  return 4.45F;
		if (item instanceof OrangeKatar) return 4.00F;
		if (item instanceof YellowKatar) return 3.65F;
		if (item instanceof LimeKatar)   return 3.35F;
		if (item instanceof GreenKatar)  return 3.10F;
		if (item instanceof CyanKatar)   return 2.90F;
		if (item instanceof BlueKatar)   return 2.75F;
		if (item instanceof PurpleKatar) return 2.65F;
		if (item instanceof PinkKatar)   return 2.60F;
		// PE's plain PEKatar (Red Matter) — baseline.
		return 2.50F;
	}
}
