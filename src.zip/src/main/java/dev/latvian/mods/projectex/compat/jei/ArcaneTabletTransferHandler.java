package dev.latvian.mods.projectex.compat.jei;

import dev.latvian.mods.projectex.menu.ArcaneTabletMenu;
import dev.latvian.mods.projectex.menu.ProjectEXMenus;
import dev.latvian.mods.projectex.net.ArcaneTabletTransferPacket;
import dev.latvian.mods.projectex.net.ProjectEXNet;
import mezz.jei.api.constants.RecipeTypes;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.transfer.IRecipeTransferError;
import mezz.jei.api.recipe.transfer.IRecipeTransferHandler;
import net.minecraft.core.NonNullList;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.ShapedRecipe;

import java.util.Optional;

public class ArcaneTabletTransferHandler implements IRecipeTransferHandler<ArcaneTabletMenu, CraftingRecipe> {
	@Override
	public Class<? extends ArcaneTabletMenu> getContainerClass() {
		return ArcaneTabletMenu.class;
	}

	@Override
	public Optional<MenuType<ArcaneTabletMenu>> getMenuType() {
		return Optional.of(ProjectEXMenus.ARCANE_TABLET.get());
	}

	@Override
	public RecipeType<CraftingRecipe> getRecipeType() {
		return RecipeTypes.CRAFTING;
	}

	@Override
	public IRecipeTransferError transferRecipe(ArcaneTabletMenu menu, CraftingRecipe recipe, IRecipeSlotsView recipeSlots, Player player, boolean maxTransfer, boolean doTransfer) {
		if (!doTransfer) return null;
		ProjectEXNet.sendToServer(new ArcaneTabletTransferPacket(layoutRecipe(recipe)));
		return null;
	}

	private static ItemStack[][] layoutRecipe(CraftingRecipe recipe) {
		ItemStack[][] cells = new ItemStack[9][];
		NonNullList<Ingredient> ings = recipe.getIngredients();

		if (recipe instanceof ShapedRecipe shaped) {
			int w = shaped.getWidth();
			int h = shaped.getHeight();
			for (int r = 0; r < h && r < 3; r++) {
				for (int c = 0; c < w && c < 3; c++) {
					int recipeIdx = r * w + c;
					int matrixIdx = r * 3 + c;
					if (recipeIdx < ings.size()) {
						cells[matrixIdx] = ings.get(recipeIdx).getItems();
					}
				}
			}
		} else {
			for (int i = 0; i < ings.size() && i < 9; i++) {
				cells[i] = ings.get(i).getItems();
			}
		}

		for (int i = 0; i < 9; i++) {
			if (cells[i] == null) cells[i] = new ItemStack[0];
		}
		return cells;
	}
}
