package dev.latvian.mods.projectex;

import org.jetbrains.annotations.Nullable;

public enum Star {
	EIN("ein", "Ein", 50_000_000L, 50_000_000_000_000L),
	ZWEI("zwei", "Zwei", 500_000_000L, 500_000_000_000_000L),
	DREI("drei", "Drei", 5_000_000_000L, 5_000_000_000_000_000L),
	VIER("vier", "Vier", 50_000_000_000L, 50_000_000_000_000_000L),
	SPHERE("sphere", "Sphere", 500_000_000_000L, 500_000_000_000_000_000L),
	OMEGA("omega", "Omega", 5_000_000_000_000L, 5_000_000_000_000_000_000L);

	public static final Star[] VALUES = values();

	public final String name;
	public final String displayName;
	public final long magnumCapacity;
	public final long colossalCapacity;

	Star(String n, String d, long mc, long cc) {
		name = n;
		displayName = d;
		magnumCapacity = mc;
		colossalCapacity = cc;
	}

	@Nullable
	public Star getPrev() {
		return this == EIN ? null : VALUES[ordinal() - 1];
	}
}
