package dev.latvian.mods.projectex.item.armor;

import moze_intel.projecte.utils.WorldHelper;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingEvent;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GreenGemLeggings extends GreenGemArmorBase {
	private final Map<Integer, Long> lastJumpTracker = new HashMap<>();

	public GreenGemLeggings(Item.Properties props) {
		super(ArmorItem.Type.LEGGINGS, props);
		MinecraftForge.EVENT_BUS.addListener(this::onJump);
	}

	private void onJump(LivingEvent.LivingJumpEvent evt) {
		if (evt.getEntity() instanceof Player player && player.level().isClientSide()) {
			lastJumpTracker.put(player.getId(), player.level().getGameTime());
		}
	}

	private boolean jumpedRecently(Player player) {
		Long t = lastJumpTracker.get(player.getId());
		return t != null && player.level().getGameTime() - t < 5L;
	}

	@Override
	public void onArmorTick(ItemStack stack, Level level, Player player) {
		boolean isClient = level.isClientSide();
		if (isClient && player.isShiftKeyDown() && !player.onGround()
				&& player.getDeltaMovement().y > -8.0 && !jumpedRecently(player)) {
			double slamPush = player.getAbilities().flying ? -0.10 : -0.32;
			player.setDeltaMovement(player.getDeltaMovement().add(0.0, slamPush, 0.0));
		}
		if (player.isShiftKeyDown()) {
			AABB box = new AABB(player.getX() - 3.5, player.getY() - 3.5, player.getZ() - 3.5,
					player.getX() + 3.5, player.getY() + 3.5, player.getZ() + 3.5);
			WorldHelper.repelEntitiesSWRG(level, box, player);
			if (!isClient && player.getDeltaMovement().y < -0.08) {
				AABB hitBox = player.getBoundingBox().move(player.getDeltaMovement()).inflate(2.0);
				List<Entity> entities = level.getEntities(player, hitBox, e -> e instanceof LivingEntity);
				float damage = (float) -player.getDeltaMovement().y * 6.0F;
				for (Entity e : entities) {
					if (!e.isPickable()) continue;
					e.hurt(level.damageSources().playerAttack(player), damage);
				}
			}
		}
	}
}
